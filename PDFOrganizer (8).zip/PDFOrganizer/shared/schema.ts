import { pgTable, text, serial, integer, boolean, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").unique().notNull(),
  passwordHash: text("password_hash"),
  name: text("name").notNull(),
  setor: text("setor").notNull(), // rh, logistica, almoxarifado, ti, financeiro, comercial, marketing, operacional, juridico, diretoria
  isAdmin: boolean("is_admin").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  // New permission system
  userType: text("user_type").default("pending").notNull(), // pending, employee, supervisor, external, admin
  approvedBy: uuid("approved_by").references(() => users.id), // Which admin approved this user
  approvedAt: timestamp("approved_at"),
  // Access control
  canAddFiles: boolean("can_add_files").default(false).notNull(),
  canEditFiles: boolean("can_edit_files").default(false).notNull(),
  canDeleteFiles: boolean("can_delete_files").default(false).notNull(),
  canViewAllSectorFiles: boolean("can_view_all_sector_files").default(false).notNull(),
  // Multi-sector access for supervisors
  accessibleSectors: text("accessible_sectors").array().default([]).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  lastLoginIp: text("last_login_ip"),
  provider: text("provider").default("email"), // email, google, github
  // 2FA fields
  twoFactorSecret: text("two_factor_secret"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false).notNull(),
  twoFactorBackupCodes: text("two_factor_backup_codes").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Refresh tokens table for JWT rotation
export const refreshTokens = pgTable("refresh_tokens", {
  id: serial("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  isRevoked: boolean("is_revoked").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  revokedAt: timestamp("revoked_at"),
});

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").default("#059669"),
  userId: uuid("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const pdfs = pgTable("pdfs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  originalName: text("original_name").notNull(),
  filePath: text("file_path").notNull(),
  size: integer("size").notNull(),
  pages: integer("pages").notNull(),
  thumbnailPath: text("thumbnail_path"),
  folderId: integer("folder_id").references(() => folders.id),
  userId: uuid("user_id").references(() => users.id).notNull(),
  setor: text("setor").notNull(), // rh, logistica, almoxarifado - must match user setor
  isFavorite: boolean("is_favorite").default(false),
  isDeleted: boolean("is_deleted").default(false),
  deletedAt: timestamp("deleted_at"),
  // Cloud storage fields
  cloudProvider: text("cloud_provider"), // google_drive, dropbox
  cloudFileId: text("cloud_file_id"), // ID from cloud provider
  cloudFolderId: text("cloud_folder_id"), // Folder ID in cloud (RH/LOGISTICA/ALMOXARIFADO)
  cloudSyncStatus: text("cloud_sync_status").default("pending"), // pending, synced, failed
  cloudSyncedAt: timestamp("cloud_synced_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cloud credentials table for storing user's cloud storage tokens
export const cloudCredentials = pgTable("cloud_credentials", {
  id: serial("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  provider: text("provider").notNull(), // google_drive, dropbox
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"), // Only for Google Drive
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  passwordHash: true,
  lastLoginAt: true,
  lastLoginIp: true,
  approvedBy: true,
  approvedAt: true,
}).extend({
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  setor: z.enum(["ti", "rh", "financeiro", "comercial", "marketing", "operacional", "juridico", "diretoria"]),
});

export const insertFolderSchema = createInsertSchema(folders).omit({
  id: true,
  createdAt: true,
});

export const insertPdfSchema = createInsertSchema(pdfs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCloudCredentialsSchema = createInsertSchema(cloudCredentials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// New tables for enhanced permission system

// Table for specific PDF access permissions (for external users)
export const pdfPermissions = pgTable("pdf_permissions", {
  id: serial("id").primaryKey(),
  pdfId: integer("pdf_id").references(() => pdfs.id).notNull(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  canView: boolean("can_view").default(true).notNull(),
  canDownload: boolean("can_download").default(false).notNull(),
  expiresAt: timestamp("expires_at"), // Optional expiration
  grantedBy: uuid("granted_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table for Google Drive file search index
export const cloudFileIndex = pgTable("cloud_file_index", {
  id: serial("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  provider: text("provider").notNull(), // google_drive, dropbox
  cloudFileId: text("cloud_file_id").notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size"),
  mimeType: text("mime_type"),
  setor: text("setor").notNull(),
  folderId: text("folder_id"), // Cloud folder ID
  lastIndexed: timestamp("last_indexed").defaultNow(),
  isDeleted: boolean("is_deleted").default(false),
});

// User type definitions for type safety
export const userTypeEnum = z.enum(["pending", "employee", "supervisor", "external", "admin"]);
export const setorEnum = z.enum(["ti", "rh", "financeiro", "comercial", "marketing", "operacional", "juridico", "diretoria"]);

// Schema for user approval by admin
export const approveUserSchema = z.object({
  userId: z.string().uuid(),
  userType: userTypeEnum,
  setor: setorEnum,
  canAddFiles: z.boolean().default(false),
  canEditFiles: z.boolean().default(false),
  canDeleteFiles: z.boolean().default(false),
  canViewAllSectorFiles: z.boolean().default(false),
  accessibleSectors: z.array(setorEnum).default([]),
});

// Schema for granting PDF access to external users
export const grantPdfAccessSchema = z.object({
  pdfId: z.number(),
  userId: z.string().uuid(),
  canView: z.boolean().default(true),
  canDownload: z.boolean().default(false),
  expiresAt: z.date().optional(),
});

// Access logs for audit trail
export const accessLogs = pgTable("access_logs", {
  id: serial("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  action: text("action").notNull(), // login, logout, view_pdf, download_pdf, upload_pdf, delete_pdf
  resourceType: text("resource_type"), // pdf, folder, user
  resourceId: text("resource_id"), // ID of the resource accessed
  ipAddress: text("ip_address").notNull(),
  userAgent: text("user_agent"),
  success: boolean("success").default(true).notNull(),
  errorMessage: text("error_message"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Password reset tokens table
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  token: uuid("token").defaultRandom().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAccessLogSchema = createInsertSchema(accessLogs).omit({
  id: true,
  timestamp: true,
});

export const insertPasswordResetTokenSchema = createInsertSchema(passwordResetTokens).omit({
  id: true,
  createdAt: true,
  token: true,
});

export const insertRefreshTokenSchema = createInsertSchema(refreshTokens).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertFolder = z.infer<typeof insertFolderSchema>;
export type InsertPdf = z.infer<typeof insertPdfSchema>;
export type InsertCloudCredentials = z.infer<typeof insertCloudCredentialsSchema>;
export type InsertAccessLog = z.infer<typeof insertAccessLogSchema>;
export type InsertPasswordResetToken = z.infer<typeof insertPasswordResetTokenSchema>;
export type InsertRefreshToken = z.infer<typeof insertRefreshTokenSchema>;

export type User = typeof users.$inferSelect;
export type Folder = typeof folders.$inferSelect;
export type Pdf = typeof pdfs.$inferSelect;
export type CloudCredentials = typeof cloudCredentials.$inferSelect;
export type AccessLog = typeof accessLogs.$inferSelect;
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type RefreshToken = typeof refreshTokens.$inferSelect;
