# PDF Organizer Pro

## Overview

This is a full-stack PDF management application built with React, Express, and PostgreSQL. The application allows users to upload, organize, and manage PDF files with features like folder organization, search, favorites, and soft deletion. The frontend uses React with TypeScript and the shadcn/ui component library, while the backend is an Express.js server with Drizzle ORM for database operations.

## Project Objective

**PDFOrganizerPro** é uma aplicação web completa para gerenciamento e organização de documentos PDF, desenvolvida para resolver problemas comuns de usuários que precisam lidar com grandes volumes de arquivos PDF em suas atividades pessoais ou profissionais.

### Problema Resolvido
- Dificuldade em organizar e localizar documentos PDF
- Falta de sistema centralizado para gerenciar arquivos PDF
- Necessidade de ferramentas básicas de edição e visualização
- Ausência de funcionalidades como favoritos, busca e categorização

### Solução Oferecida
Um sistema web intuitivo que permite upload, organização, busca e gerenciamento de PDFs com interface moderna e responsiva, incluindo funcionalidades como pastas personalizadas, sistema de favoritos, lixeira com recuperação e ferramentas básicas de edição.

## User Preferences

Preferred communication style: Simple, everyday language (Portuguese).

## Recent Changes (Janeiro 2025)

### Bug Crítico de Autenticação Corrigido (16 Janeiro 2025) ✅
- ✅ **Endpoint `/api/auth/me` implementado**: Endpoint estava faltando no backend causando erro 404
- ✅ **Correção método storage**: Substituído `getUserById` por `getUser` no storage-db.ts
- ✅ **Reset completo do banco**: Removidos todos os usuários de teste e dados antigos
- ✅ **Usuário admin único**: Criado apenas `hiltonpatohilton@gmail.com` como admin principal
- ✅ **Permissões completas**: Admin tem acesso total a todos os setores e funcionalidades
- ✅ **Autenticação funcional**: Sistema de login/dashboard funcionando perfeitamente
- ✅ **Teste completo**: Endpoint `/api/auth/me` retornando dados corretos do usuário

### Configuração Admin Principal (16 Janeiro 2025)
- **Email**: hiltonpatohilton@gmail.com
- **Senha**: admin123
- **Função**: Administrador da Diretoria
- **Permissões**: Pode aprovar novos usuários, gerenciar todos os setores, controle total do sistema
- **Setores acessíveis**: Todos (diretoria, ti, rh, financeiro, comercial, marketing, operacional, juridico, almoxarifado, logistica)

### Implementações Críticas - Feedback Pessoa 1 & 2
- **Migração PostgreSQL**: Drizzle ORM, schemas profissionais, transações ACID
- **Autenticação JWT**: bcrypt + tokens seguros, middleware robusto
- **Rate Limiting**: Proteção contra brute force e spam (express-rate-limit)
- **Upload Streams**: Busboy para uploads não-bloqueantes, múltiplos arquivos simultâneos
- **Logs Estruturados**: Pino com userId, timestamps, contexto completo
- **Segurança Empresarial**: Validação Zod rigorosa, headers seguros

### Implementações Críticas - Feedback Pessoa 1 (100/100)
- **Circuit Breaker**: Opossum para serviço de thumbnails (timeout 5s, 50% erro)
- **Logs com RequestId**: Todos os logs agora incluem userId + requestId único
- **Secrets Management**: docker-compose.yml + .env.example para produção
- **Health Check**: Endpoint /health para monitoramento Docker
- **Dockerfile Multi-stage**: Build otimizado com non-root user

### Melhorias de Segurança - Análise Pessoa 1 (Janeiro 2025)
- **JWT com Expiração**: Tokens agora expiram em 15 minutos para maior segurança
- **Validação Rigorosa de Setor**: Backend nunca confia no cliente, sempre valida setor no servidor
- **Logs com Contexto Completo**: userId, setor, IP, requestId em todos os logs
- **Middleware de Segurança**: Verificação de setor em todas as rotas críticas
- **Auditoria Completa**: Logs de acesso salvos no banco para compliance

### Melhorias Críticas de Segurança - Feedback Pessoa 4 (Janeiro 2025) ✅
- ✅ **Validação de Complexidade de Senhas**: Função validatePasswordComplexity() implementada
- ✅ **Rate Limiting Específico**: passwordResetLimiter com 3 tentativas por hora
- ✅ **Validação de Magic Bytes**: validatePDFFile() verifica magic bytes %PDF
- ✅ **Sanitização de Paths**: sanitizeFilePath() previne directory traversal
- ✅ **Aplicação em Endpoints**: Validação aplicada em register e reset-password
- ✅ **Documentação Completa**: .env.example detalhado + README.md atualizado
- ✅ **Instruções de Setup**: Guia completo de instalação e configuração
- ✅ **Troubleshooting**: Seção de problemas comuns e soluções

### Melhorias Avançadas - Feedback Pessoa 4 Iteração 2 (Janeiro 2025) ✅
- ✅ **Validação de Senha Nível Enterprise**: Mínimo 12 caracteres, detecção de padrões previsíveis
- ✅ **Rate Limiting Ultra-Agressivo**: 2 tentativas por 2 horas para reset de senha
- ✅ **Sistema de Auditoria Avançado**: Detecção de atividades suspeitas em tempo real
- ✅ **Monitoramento de Sistema**: Health check avançado com alertas automáticos
- ✅ **Métricas de Segurança**: Dashboard com estatísticas de auditoria e compliance
- ✅ **Relatórios de Auditoria**: Geração automática de relatórios para compliance
- ✅ **Detecção de Anomalias**: Algoritmos para identificar comportamento suspeito
- ✅ **Alertas Críticos**: Sistema de alertas para eventos de segurança críticos

### Correções Críticas - Feedback Pessoa 4 Iteração 3 (Janeiro 2025) ✅
- ✅ **Vulnerabilidade TOCTOU Corrigida**: Validação de magic bytes ANTES do armazenamento
- ✅ **Sistema de Retry Cloud Storage**: Exponential backoff com máximo 3 tentativas
- ✅ **Documentação Swagger/OpenAPI**: API documentada em /api-docs/ com schemas completos
- ✅ **Invalidação de Tokens**: Correção de tokens de reset não invalidados após uso
- ✅ **Security Checklist**: Checklist executável com 83% de cobertura implementada
- ✅ **ADR Template**: Architectural Decision Records para rastreabilidade técnica

### Melhorias Críticas de Segurança - Feedback Pessoa 2 (Janeiro 2025) ✅
- ✅ **JWT_SECRET Obrigatório**: Removido fallback inseguro, JWT_SECRET obrigatório em produção
- ✅ **Validação de Senhas Complexas**: Maiúscula + minúscula + números + especiais obrigatórios
- ✅ **Validação de Expiração**: Tokens de reset verificam expiração rigorosamente
- ✅ **Revogação de Tokens**: Todos os tokens são revogados ao resetar senha
- ✅ **Validação de Permissões**: Tokens verificam mudanças de setor/admin em tempo real
- ✅ **Validação de Arquivos**: Magic bytes para PDFs + sanitização de paths
- ✅ **Headers de Segurança**: XSS, CSRF, Content-Type protection
- ✅ **Documentação Completa**: README.md + .env.example para setup seguro

### Sistema de Recuperação de Senha (Janeiro 2025) - VALIDADO PESSOA 1 ✅
- ✅ **Endpoints Seguros**: `/api/auth/forgot-password` e `/api/auth/reset-password`
- ✅ **Tokens com Expiração**: Tokens únicos UUID com validade de 15 minutos
- ✅ **Email HTML Template**: Template responsivo com link de redefinição
- ✅ **Validação Rigorosa**: Verificação de token, unicidade e expiração
- ✅ **Interface Completa**: Formulários React com validação Zod
- ✅ **Logs Estruturados**: Todos os eventos de reset logados
- ✅ **Segurança por Design**: Não vaza informações sobre existência do email
- ✅ **Rate Limiting**: Proteção contra spam de redefinição
- ✅ **Pontuação Pessoa 1**: 10/10 (100%) - Nível empresarial aprovado

### Implementações Avançadas - Nível Google Drive/Dropbox (Janeiro 2025) ✅
- ✅ **Refresh Token com Rotação**: Sistema de revogação de tokens JWT implementado
- ✅ **Autenticação 2FA (TOTP)**: Multifator com speakeasy + QR codes para admins
- ✅ **Painel de Auditoria**: Interface completa com logs detalhados e estatísticas

### Telas Específicas de Administração e Supervisão (Janeiro 2025) - NOVO ✅
- ✅ **Tela de Administração de Usuários**: Gerenciamento completo de usuários com visualização de emails, cargos e funcionalidade de remoção
- ✅ **Tela de Monitoramento em Tempo Real**: Interface para supervisores acompanharem atividades do sistema com filtros avançados
- ✅ **Roteamento Específico**: Rotas dedicadas `/admin/users` e `/supervisor/audit` para acesso direto
- ✅ **Controles de Acesso**: Validação rigorosa de permissões baseada no tipo de usuário
- ✅ **Interface Diferenciada**: Componentes especializados para cada tipo de usuário (admin/supervisor)

### Status Google Drive/Dropbox Level (100/100) - COMPLETO ✅
- ✅ Banco PostgreSQL + ORM profissional
- ✅ Autenticação robusta com JWT + bcrypt (expiração 15min)
- ✅ **Refresh Tokens com Rotação**: Sistema seguro de renovação automática
- ✅ **Autenticação 2FA (TOTP)**: Códigos QR + backup codes para admins
- ✅ **Painel de Auditoria Completo**: Logs detalhados, estatísticas e detecção de atividades suspeitas
- ✅ **Integração Cloud Storage**: Google Drive + Dropbox OAuth2 completo
- ✅ Rate limiting em todas as rotas críticas
- ✅ Upload eficiente com streams (resolve travamentos)
- ✅ Logs auditáveis para compliance com requestId + contexto
- ✅ Circuit Breaker para resiliência de thumbnails
- ✅ Secrets management para produção
- ✅ Docker containerizado com health check
- ✅ Validação rigorosa de setor no backend
- ✅ Recuperação de senha via email completa e segura

### Funcionalidades Avançadas de Segurança (Janeiro 2025)
- ✅ **Sistema de Refresh Tokens**: Rotação automática, revogação em lote, cleanup de tokens expirados
- ✅ **Autenticação 2FA com TOTP**: Speakeasy + QR codes, códigos de backup, interface completa
- ✅ **Auditoria Avançada**: Logs estruturados, estatísticas em tempo real, detecção de atividades suspeitas
- ✅ **Gerenciamento de Sessões**: Revogação de todas as sessões, controle de tokens ativos
- ✅ **Interface de Segurança**: Painel completo para admins com controles avançados
- ✅ **Integração Cloud Segura**: OAuth2 com Google Drive e Dropbox, credenciais criptografadas

### Integração com Armazenamento em Nuvem (Janeiro 2025)
- ✅ **Google Drive**: OAuth2 + API integration completa
- ✅ **Dropbox**: OAuth2 + API integration completa
- ✅ **Sync Automático**: PDFs sincronizados automaticamente após upload
- ✅ **Interface Web**: Configuração de cloud storage via /settings
- ✅ **Credenciais Seguras**: Tokens armazenados com criptografia no banco
- ✅ **APIs Robustas**: Endpoints para auth, sync, list, disconnect
- ✅ **Logs Estruturados**: Eventos de cloud storage logados
- ✅ **Schema Atualizado**: Tabela cloud_credentials + campos sync nos PDFs

### Sistema de Permissões Avançado e Busca na Nuvem (Janeiro 2025) - NOVO ✅
- ✅ **Fila de Aprovação**: Novos usuários aguardam aprovação do administrador
- ✅ **Tipos de Usuário**: pending, employee, supervisor, external, admin
- ✅ **Permissões Granulares**: canAddFiles, canEditFiles, canDeleteFiles, canViewAllSectorFiles
- ✅ **Acesso Multi-Setor**: Supervisores podem acessar múltiplos setores
- ✅ **Acesso Específico a PDFs**: Usuários externos podem ter acesso limitado a PDFs específicos
- ✅ **Busca Integrada**: Pesquisa simultânea em arquivos locais e na nuvem
- ✅ **Indexação Automática**: PDFs do Google Drive indexados para busca
- ✅ **Controle de Acesso**: Validação de permissões por setor em tempo real
- ✅ **Interface Diferenciada**: Supervisores têm interface otimizada para visualização

### Interfaces Específicas por Setor (Janeiro 2025) - COMPLETO ✅
- ✅ **DashboardRouter**: Roteamento automático baseado no tipo de usuário
- ✅ **DirectorDashboard**: Painel executivo com estatísticas gerais e resumo por setor
- ✅ **SupervisorDashboard**: Interface otimizada para visualização de arquivos multi-setor
- ✅ **ExternalUserDashboard**: Painel limitado com acesso apenas a PDFs específicos
- ✅ **EmployeeDashboard**: Interface completa para funcionários com permissões configuráveis
- ✅ **Estados de Conta**: Tratamento para usuários pending, inativos e bloqueados
- ✅ **Validação de Permissões**: Verificação em tempo real das permissões do usuário
- ✅ **Endpoints Específicos**: APIs dedicadas para cada tipo de dashboard

**Nota**: Para ativar o armazenamento em nuvem, adicione as seguintes variáveis de ambiente:
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URL`
- `DROPBOX_CLIENT_ID`, `DROPBOX_CLIENT_SECRET`, `DROPBOX_REDIRECT_URL`

### Endpoints da API - Sistema de Permissões (Janeiro 2025)
- ✅ **GET /api/admin/users/pending**: Lista usuários aguardando aprovação
- ✅ **GET /api/admin/users/all**: Lista todos os usuários com permissões
- ✅ **POST /api/admin/users/approve**: Aprova usuário e define permissões
- ✅ **POST /api/admin/users/reject**: Rejeita usuário pendente
- ✅ **POST /api/admin/users/deactivate**: Desativa usuário (demissão)
- ✅ **PUT /api/admin/users/permissions**: Atualiza permissões de usuário
- ✅ **POST /api/admin/pdf-access/grant**: Concede acesso específico a PDF
- ✅ **POST /api/admin/pdf-access/revoke**: Revoga acesso a PDF
- ✅ **GET /api/search/cloud**: Busca integrada (local + nuvem)
- ✅ **POST /api/cloud/index**: Indexa arquivos da nuvem para busca
- ✅ **POST /api/cloud/refresh-index**: Atualiza índice da nuvem
- ✅ **GET /api/cloud/download/:provider/:fileId**: Download direto da nuvem

### Endpoints da API - Dashboards Específicos (Janeiro 2025)
- ✅ **GET /api/director/stats**: Estatísticas gerais para diretoria
- ✅ **GET /api/director/sectors**: Resumo de todos os setores
- ✅ **GET /api/director/activities**: Atividades recentes de todos os setores
- ✅ **GET /api/supervisor/files**: Arquivos dos setores acessíveis ao supervisor
- ✅ **GET /api/external/files**: Arquivos específicos liberados para usuário externo

### Endpoints da API - Telas Específicas de Admin e Supervisor (Janeiro 2025)
- ✅ **POST /api/admin/users/activate**: Ativar usuário desativado
- ✅ **GET /api/audit/logs**: Logs de auditoria para supervisores (tempo real)
- ✅ **GET /api/audit/stats**: Estatísticas de auditoria para supervisores
- ✅ **GET /api/search/cloud**: Busca integrada de PDFs para supervisores

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for development and production builds
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for client-side routing
- **Component Library**: Radix UI primitives with custom shadcn/ui components

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **File Handling**: Multer for file uploads
- **Development Setup**: Hot reload with Vite integration in development mode

### Data Storage
- **Database**: PostgreSQL hosted on Neon (serverless PostgreSQL)
- **ORM**: Drizzle ORM with migrations
- **File Storage**: Local file system with upload directory
- **Schema**: Two main entities - folders and PDFs with relationships

## Key Components

### Database Schema
- **Folders Table**: Stores folder information with name, color, and creation date
- **PDFs Table**: Stores PDF metadata including name, file path, size, pages, folder association, favorites flag, and soft deletion flag

### API Endpoints
- **Folder Management**: CRUD operations for folders
- **PDF Management**: Upload, retrieve, update, delete, and search PDFs
- **Special Operations**: Toggle favorites, soft delete/restore, search functionality

### Frontend Components
- **Header**: Search functionality and upload trigger
- **Sidebar**: Navigation between categories (all, recent, favorites, deleted) and folder management
- **PDF Grid**: Display PDFs in grid or list view with sorting options
- **Upload Zone**: Drag-and-drop file upload with progress tracking
- **Action Bar**: View mode toggle and sorting controls

## Data Flow

1. **File Upload**: Users drag/drop or select PDF files → Frontend sends to `/api/pdfs/upload` → Server processes with Multer → File saved to uploads directory → Metadata stored in database
2. **Data Fetching**: Frontend uses React Query to fetch data from API endpoints → Server queries PostgreSQL via Drizzle ORM → Returns formatted data
3. **Real-time Updates**: React Query automatically invalidates and refetches data after mutations for consistent UI state

## External Dependencies

### Frontend Dependencies
- **UI Components**: Extensive Radix UI primitives (@radix-ui/react-*)
- **State Management**: @tanstack/react-query for server state
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **File Handling**: react-dropzone for drag-and-drop uploads
- **Utilities**: clsx, tailwind-merge for className management

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: drizzle-orm with drizzle-zod for schema validation
- **File Upload**: multer for handling multipart/form-data
- **Session Management**: connect-pg-simple for PostgreSQL session storage

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with hot reload
- **Backend**: tsx for TypeScript execution with hot reload
- **Database**: Drizzle Kit for schema management and migrations

### Production
- **Build Process**: Vite builds frontend to `dist/public`, esbuild bundles backend to `dist/index.js`
- **Static Files**: Express serves built frontend files
- **Database**: Production PostgreSQL instance via DATABASE_URL environment variable
- **File Storage**: Local uploads directory (would typically be replaced with cloud storage in production)

### Configuration
- **Environment**: NODE_ENV for development/production modes
- **Database**: DATABASE_URL for PostgreSQL connection
- **File Limits**: 50MB upload limit with PDF-only restriction
- **CORS**: Development-friendly CORS setup with credentials support

The application follows a monorepo structure with shared TypeScript schemas, making it easy to maintain type safety across the full stack while keeping the frontend and backend clearly separated.