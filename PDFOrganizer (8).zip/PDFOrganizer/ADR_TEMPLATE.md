# ADR Template - Architectural Decision Records

## ADR-001: Validação de Magic Bytes Antes do Armazenamento

**Data:** 2025-01-16  
**Status:** Implementado  
**Originado por:** Pessoa 4 - Feedback de Segurança  

### Contexto
A implementação original validava magic bytes PDF após salvar o arquivo no disco, criando uma vulnerabilidade TOCTOU (Time-of-Check to Time-of-Use).

### Decisão
Mover a validação de magic bytes para antes do armazenamento, validando o buffer em memória antes de escrever no disco.

### Implementação
```typescript
// ANTES (VULNERÁVEL)
file.pipe(writeStream);
writeStream.on('finish', () => {
  if (!validatePDFFile(filePath)) {
    fs.unlinkSync(filePath); // Tarde demais!
  }
});

// DEPOIS (SEGURO)
file.on('end', () => {
  const buffer = Buffer.concat(chunks);
  if (buffer.subarray(0, 4).toString() !== '%PDF') {
    res.status(400).json({ message: "Invalid PDF file format" });
    return;
  }
  fs.writeFileSync(filePath, buffer);
});
```

### Consequências
- ✅ Elimina vulnerabilidade TOCTOU
- ✅ Arquivos maliciosos nunca tocam o disco
- ✅ Validação mais confiável
- ⚠️ Maior uso de memória (buffer completo)

### Monitoramento
- Teste: Upload de arquivo não-PDF deve falhar
- Métrica: Tempo de validação < 100ms
- Log: Tentativas de upload malicioso

---

## ADR-002: Sistema de Retry para Cloud Storage

**Data:** 2025-01-16  
**Status:** Implementado  
**Originado por:** Pessoa 4 - Feedback de Robustez  

### Contexto
Falhas de sincronização com Google Drive/Dropbox causavam perda de dados sem notificação ou retry.

### Decisão
Implementar sistema de retry com exponential backoff para falhas de sincronização.

### Implementação
```typescript
// Novo serviço: cloud-retry-service.ts
- Máximo 3 tentativas por arquivo
- Delay: 1s → 2s → 4s → max 30s
- Fila automática de processamento
- Endpoint de monitoramento para admins
```

### Consequências
- ✅ Recuperação automática de falhas temporárias
- ✅ Logs detalhados de tentativas
- ✅ Interface de monitoramento
- ⚠️ Complexidade adicional no sistema

### Monitoramento
- Endpoint: `/api/admin/cloud/retry-queue`
- Métrica: Taxa de sucesso após retry
- Alerta: Falhas após 3 tentativas

---

## ADR-003: Documentação Swagger/OpenAPI

**Data:** 2025-01-16  
**Status:** Implementado  
**Originado por:** Pessoa 4 - Feedback de Manutenibilidade  

### Contexto
Ausência de documentação formal da API dificultava integração e manutenção.

### Decisão
Implementar documentação Swagger/OpenAPI completa com schemas TypeScript.

### Implementação
```typescript
// Novo arquivo: server/swagger.ts
- Documentação em /api-docs/
- Schemas para User, PDF, AuditLog
- Exemplos de requests/responses
- Autenticação JWT documentada
```

### Consequências
- ✅ Documentação sempre atualizada
- ✅ Facilita integração externa
- ✅ Melhora onboarding de desenvolvedores
- ⚠️ Manutenção adicional da documentação

### Monitoramento
- Acesso: http://localhost:5000/api-docs/
- Métrica: Cobertura de endpoints documentados
- Validação: Schemas sincronizados com código

---

## Template para Novas Decisões

### ADR-XXX: [Título da Decisão]

**Data:** [YYYY-MM-DD]  
**Status:** [Proposto/Implementado/Rejeitado]  
**Originado por:** [Pessoa 1/Pessoa 4/Requisito interno]  

### Contexto
[Describe o problema ou situação que motivou a decisão]

### Decisão
[Describe a solução escolhida]

### Implementação
```
[Código, configuração ou steps técnicos]
```

### Consequências
- ✅ Benefícios
- ⚠️ Trade-offs
- ❌ Riscos

### Monitoramento
- [Como validar se a decisão está funcionando]
- [Métricas para acompanhar]
- [Alertas ou testes necessários]

---

## Índice de Decisões

| ADR | Título | Status | Data | Originado por |
|-----|--------|--------|------|---------------|
| 001 | Validação Magic Bytes | ✅ Implementado | 2025-01-16 | Pessoa 4 |
| 002 | Sistema Retry Cloud | ✅ Implementado | 2025-01-16 | Pessoa 4 |
| 003 | Documentação Swagger | ✅ Implementado | 2025-01-16 | Pessoa 4 |

---

## Processo de ADR

1. **Identificação:** Pessoa 1/4 identifica necessidade de decisão
2. **Proposta:** Criar ADR com status "Proposto"
3. **Discussão:** Validar com stakeholders
4. **Implementação:** Código + testes + documentação
5. **Revisão:** Atualizar status e consequências
6. **Monitoramento:** Acompanhar métricas definidas

---
*Template mantido por: Sistema de Decisões PDFOrganizerPro*
*Baseado em: https://adr.github.io/*