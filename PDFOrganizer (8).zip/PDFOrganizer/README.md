# PDFOrganizerPro

Uma aplicação web completa para gerenciamento e organização de documentos PDF com recursos avançados de segurança empresarial.

## 🚀 Recursos Principais

### 📋 Gestão de Documentos
- ✅ **Upload Múltiplo** com drag-and-drop
- ✅ **Visualização de PDFs** integrada
- ✅ **Organização por Pastas** personalizáveis
- ✅ **Sistema de Favoritos** por usuário
- ✅ **Lixeira com Recuperação** (soft delete)
- ✅ **Busca Avançada** com Fuse.js
- ✅ **Thumbnails** gerados automaticamente

### 🔐 Segurança Enterprise
- ✅ **Autenticação JWT** com bcrypt
- ✅ **Autenticação 2FA (TOTP)** com QR codes
- ✅ **Refresh Tokens** com rotação automática
- ✅ **Recuperação de Senha** via email
- ✅ **Rate Limiting** em todas as rotas
- ✅ **Isolamento por Setor** (RH, Financeiro, etc.)
- ✅ **Sistema de Auditoria** completo

### ☁️ Integração Cloud
- ✅ **Google Drive** OAuth2 completo
- ✅ **Dropbox** OAuth2 completo
- ✅ **Sincronização Automática** após upload

### 📊 Painel Administrativo
- ✅ **Auditoria Completa** de ações
- ✅ **Estatísticas em Tempo Real**
- ✅ **Gestão de Usuários** avançada
- ✅ **Monitoramento de Segurança**

## 🛠️ Tecnologias

### Frontend
- **React 18.3.1** + TypeScript
- **Vite** para build e desenvolvimento
- **Tailwind CSS** + shadcn/ui
- **React Query** para estado do servidor
- **Wouter** para roteamento

### Backend
- **Express.js** + TypeScript
- **PostgreSQL** + Drizzle ORM
- **JWT** + bcrypt para autenticação
- **Pino** para logs estruturados
- **Multer** para upload de arquivos

## 📦 Instalação

### 1. Pré-requisitos
- Node.js 18+ 
- PostgreSQL 12+
- npm ou yarn

### 2. Clone o repositório
```bash
git clone <repository-url>
cd PDFOrganizerPro
```

### 3. Instale as dependências
```bash
npm install
```

### 4. Configure as variáveis de ambiente
```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Configure as variáveis necessárias
# OBRIGATÓRIO: Configure a DATABASE_URL
DATABASE_URL=postgresql://user:password@localhost:5432/pdforganizer

# OBRIGATÓRIO: Configure o JWT_SECRET (mínimo 32 caracteres)
JWT_SECRET=your-super-secure-jwt-secret-key-minimum-32-characters-long

# OBRIGATÓRIO para reset de senha: Configure SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=your-email@gmail.com
```

### 5. Configure o banco de dados
```bash
# Execute as migrações
npm run db:push
```

### 6. Execute o projeto
```bash
# Desenvolvimento
npm run dev

# Produção
npm run build
npm start
```

## 🔧 Configuração Detalhada

### Variáveis de Ambiente Obrigatórias

| Variável | Descrição | Exemplo |
|----------|-----------|---------|
| `DATABASE_URL` | URL do PostgreSQL | `postgresql://user:pass@localhost:5432/db` |
| `JWT_SECRET` | Chave secreta do JWT (min 32 chars) | `your-super-secure-jwt-secret-key-here` |
| `SMTP_HOST` | Servidor SMTP para emails | `smtp.gmail.com` |
| `SMTP_USER` | Email para envio | `your-email@gmail.com` |
| `SMTP_PASSWORD` | Senha/App Password | `your-app-password` |

### Variáveis de Ambiente Opcionais

| Variável | Descrição | Padrão |
|----------|-----------|---------|
| `NODE_ENV` | Ambiente de execução | `development` |
| `PORT` | Porta do servidor | `5000` |
| `GOOGLE_CLIENT_ID` | ID do cliente Google Drive | - |
| `GOOGLE_CLIENT_SECRET` | Secret do Google Drive | - |
| `DROPBOX_CLIENT_ID` | ID do cliente Dropbox | - |
| `DROPBOX_CLIENT_SECRET` | Secret do Dropbox | - |

## 🚀 Deployment

### Docker
```bash
# Build da imagem
docker build -t pdforganizer .

# Execute o container
docker run -p 5000:5000 --env-file .env pdforganizer
```

### Docker Compose
```bash
# Execute com PostgreSQL incluído
docker-compose up -d
```

## 🔐 Segurança

### Política de Senhas
- Mínimo 8 caracteres
- Pelo menos 1 letra maiúscula
- Pelo menos 1 letra minúscula
- Pelo menos 1 número
- Pelo menos 1 caractere especial

### Rate Limiting
- **Login**: 10 tentativas por 15 minutos
- **Upload**: 50 uploads por 15 minutos
- **Reset de Senha**: 3 tentativas por 1 hora
- **Geral**: 100 requests por 15 minutos

### Autenticação 2FA
- Suporte a códigos TOTP (Google Authenticator)
- QR codes para configuração
- Códigos de backup para recuperação

## 📊 Monitoramento

### Logs
- Logs estruturados com Pino
- Auditoria completa de ações
- Detecção de atividades suspeitas

### Health Check
```bash
curl http://localhost:5000/health
```

## 🔄 Comandos Úteis

```bash
# Desenvolvimento
npm run dev              # Inicia servidor de desenvolvimento
npm run build            # Build para produção
npm run start            # Inicia servidor de produção

# Banco de dados
npm run db:push          # Aplica mudanças no schema
npm run db:studio        # Abre interface do banco

# Logs
npm run logs             # Visualiza logs em tempo real
```

## 📋 Endpoints da API

### Autenticação
- `POST /api/auth/login` - Login do usuário
- `POST /api/auth/register` - Registro de novo usuário
- `POST /api/auth/forgot-password` - Recuperação de senha
- `POST /api/auth/reset-password` - Reset de senha
- `POST /api/auth/refresh` - Refresh token

### PDFs
- `GET /api/pdfs` - Listar PDFs do usuário
- `POST /api/pdfs/upload` - Upload de PDF
- `GET /api/pdfs/:id/download` - Download de PDF
- `DELETE /api/pdfs/:id` - Deletar PDF
- `POST /api/pdfs/:id/favorite` - Favoritar PDF

### Administração
- `GET /api/admin/users/pending` - Usuários pendentes
- `POST /api/admin/users/approve` - Aprovar usuário
- `GET /api/audit/logs` - Logs de auditoria

## 🐛 Troubleshooting

### Problemas Comuns

1. **Erro de conexão com banco**
   - Verifique se o PostgreSQL está rodando
   - Confirme a DATABASE_URL no .env

2. **Erro de JWT**
   - Configure JWT_SECRET com mínimo 32 caracteres
   - Nunca use o valor padrão em produção

3. **Emails não funcionam**
   - Configure corretamente as variáveis SMTP
   - Para Gmail, use App Password em vez da senha normal

4. **Upload falha**
   - Verifique se o diretório uploads/ existe
   - Confirme permissões de escrita

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 🤝 Contribuições

Contribuições são bem-vindas! Por favor, leia o guia de contribuição antes de submeter PRs.

## 📞 Suporte

Para suporte técnico, abra uma issue no repositório ou entre em contato com a equipe de desenvolvimento.
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

### 5. Execute as migrações
```bash
npm run db:push
```

### 6. Inicie o servidor
```bash
npm run dev
```

## ⚙️ Configuração

### Variáveis de Ambiente Obrigatórias

```env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/pdforganizer

# JWT (CRÍTICO - Gere uma chave segura)
JWT_SECRET=your-very-secure-jwt-secret-key-here

# Session
SESSION_SECRET=your-session-secret-key-here
```

### Configuração de Email (Para recuperação de senha)

```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
EMAIL_FROM=noreply@yourapp.com
```

### Configuração Cloud Storage (Opcional)

#### Google Drive
1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Crie um novo projeto ou selecione um existente
3. Ative a Google Drive API
4. Crie credenciais OAuth2
5. Configure as variáveis:

```env
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
GOOGLE_REDIRECT_URL=http://localhost:5000/api/cloud/auth/google/callback
```

#### Dropbox
1. Acesse [Dropbox App Console](https://www.dropbox.com/developers/apps)
2. Crie um novo app
3. Configure as variáveis:

```env
DROPBOX_CLIENT_ID=your-dropbox-client-id
DROPBOX_CLIENT_SECRET=your-dropbox-client-secret
DROPBOX_REDIRECT_URL=http://localhost:5000/api/cloud/auth/dropbox/callback
```

## 🔐 Segurança

### Chaves de Segurança

⚠️ **IMPORTANTE**: Nunca use as chaves padrão em produção!

```bash
# Gere uma chave JWT segura
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# Ou use uuidgen
uuidgen
```

### Requisitos de Senha

- Mínimo 8 caracteres
- Pelo menos 1 letra maiúscula
- Pelo menos 1 letra minúscula
- Pelo menos 1 número
- Pelo menos 1 caractere especial

### Rate Limiting

- **Geral**: 100 requisições por 15 minutos
- **Autenticação**: 10 tentativas por 15 minutos
- **Reset de Senha**: 5 tentativas por 15 minutos

## 🏢 Isolamento por Setor

O sistema suporta isolamento de dados por setor:

- **RH**: Documentos de recursos humanos
- **Financeiro**: Documentos financeiros
- **Operações**: Documentos operacionais
- **Vendas**: Documentos de vendas

Cada usuário só vê documentos do seu setor.

## 👥 Usuários

### Primeiro Usuário Admin

Após a instalação, registre-se normalmente. O primeiro usuário será automaticamente admin.

### Níveis de Acesso

- **Usuário**: Acesso aos próprios documentos
- **Admin**: Acesso ao painel de auditoria e gestão de usuários

## 📊 Monitoramento

### Logs

Os logs são estruturados com Pino e incluem:
- Eventos de autenticação
- Uploads de arquivos
- Acessos a documentos
- Erros e exceções

### Auditoria

O sistema mantém logs detalhados de:
- Tentativas de login
- Uploads e downloads
- Mudanças de senha
- Ações administrativas

## 🔄 Backup

### Backup do Banco de Dados

```bash
# Backup
pg_dump -U username -h localhost pdforganizer > backup.sql

# Restore
psql -U username -h localhost pdforganizer < backup.sql
```

### Backup dos Arquivos

```bash
# Backup do diretório de uploads
tar -czf uploads-backup.tar.gz uploads/
```

## 🚀 Deploy

### Produção

1. Configure todas as variáveis de ambiente
2. Use HTTPS obrigatório
3. Configure proxy reverso (nginx)
4. Implemente backup automático
5. Configure monitoramento

### Docker

```bash
# Build
docker build -t pdforganizer .

# Run
docker-compose up -d
```

## 📝 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registro de usuário
- `POST /api/auth/login` - Login
- `POST /api/auth/forgot-password` - Recuperação de senha
- `POST /api/auth/reset-password` - Redefinição de senha
- `POST /api/auth/refresh` - Refresh token

### PDFs
- `GET /api/pdfs` - Listar PDFs
- `POST /api/pdfs/upload` - Upload de PDF
- `GET /api/pdfs/:id/download` - Download de PDF
- `PUT /api/pdfs/:id` - Atualizar PDF
- `DELETE /api/pdfs/:id` - Deletar PDF

### Administração
- `GET /api/admin/audit/logs` - Logs de auditoria
- `GET /api/admin/audit/stats` - Estatísticas
- `GET /api/admin/audit/users/:id` - Atividade do usuário

## 🐛 Troubleshooting

### Problemas Comuns

**JWT_SECRET não definido:**
```
Error: JWT_SECRET environment variable is required
```
Solução: Defina JWT_SECRET no arquivo .env

**Erro de conexão com banco:**
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
Solução: Verifique se o PostgreSQL está rodando e a DATABASE_URL está correta

**Upload falhando:**
```
Error: File too large
```
Solução: Verifique o MAX_FILE_SIZE no .env

## 📞 Suporte

Para problemas técnicos:
1. Verifique os logs no console
2. Confirme as variáveis de ambiente
3. Teste a conexão com o banco
4. Verifique as permissões de arquivo

## 📜 Licença

MIT License - veja o arquivo LICENSE para detalhes.

## 🎯 Próximos Passos

- [ ] Implementar PWA
- [ ] Adicionar busca por conteúdo PDF
- [ ] Implementar versionamento de documentos
- [ ] Adicionar assinatura digital
- [ ] Implementar workflow de aprovação