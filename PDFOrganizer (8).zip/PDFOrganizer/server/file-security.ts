import fs from 'fs';
import path from 'path';
import { logger } from './logger';

// Magic bytes for PDF files
const PDF_MAGIC_BYTES = [0x25, 0x50, 0x44, 0x46]; // %PDF

/**
 * Validates if a file is a valid PDF by checking magic bytes
 */
export function validatePDFFile(filePath: string): boolean {
  try {
    const buffer = fs.readFileSync(filePath);
    
    // Check if file starts with PDF magic bytes
    for (let i = 0; i < PDF_MAGIC_BYTES.length; i++) {
      if (buffer[i] !== PDF_MAGIC_BYTES[i]) {
        return false;
      }
    }
    
    return true;
  } catch (error) {
    logger.error('Error validating PDF file:', error);
    return false;
  }
}

/**
 * Sanitizes file path to prevent directory traversal attacks
 */
export function sanitizeFilePath(filePath: string): string {
  // Remove any path traversal attempts
  const sanitized = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, '');
  
  // Ensure the path stays within the uploads directory
  const uploadsDir = path.resolve('uploads');
  const resolvedPath = path.resolve(uploadsDir, sanitized);
  
  if (!resolvedPath.startsWith(uploadsDir)) {
    throw new Error('Invalid file path: Path traversal detected');
  }
  
  return resolvedPath;
}

/**
 * Validates file upload security
 */
export function validateFileUpload(filename: string, mimeType: string, size: number): { valid: boolean; error?: string } {
  // Check file extension
  const allowedExtensions = ['.pdf'];
  const extension = path.extname(filename).toLowerCase();
  
  if (!allowedExtensions.includes(extension)) {
    return { valid: false, error: 'Apenas arquivos PDF são permitidos' };
  }
  
  // Check MIME type
  if (mimeType !== 'application/pdf') {
    return { valid: false, error: 'Tipo de arquivo inválido' };
  }
  
  // Check file size (50MB limit)
  const maxSize = 50 * 1024 * 1024;
  if (size > maxSize) {
    return { valid: false, error: 'Arquivo muito grande. Limite: 50MB' };
  }
  
  return { valid: true };
}

/**
 * Generates a secure filename
 */
export function generateSecureFilename(originalFilename: string): string {
  const extension = path.extname(originalFilename);
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2);
  
  return `${timestamp}-${random}${extension}`;
}