import { Request, Response } from 'express';
import { google } from 'googleapis';
import { AuthenticatedRequest } from './auth';
import { storage } from './storage-db';
import { logger } from './logger';

// OAuth2 configuration
const googleOAuth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URL
);

const dropboxConfig = {
  clientId: process.env.DROPBOX_CLIENT_ID,
  clientSecret: process.env.DROPBOX_CLIENT_SECRET,
  redirectUrl: process.env.DROPBOX_REDIRECT_URL
};

// Google Drive OAuth routes
export async function initiateGoogleAuth(req: AuthenticatedRequest, res: Response) {
  try {
    // Check if Google OAuth is configured
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
      return res.status(400).json({ 
        message: 'Google Drive não está configurado. Adicione as credenciais OAuth2 nas variáveis de ambiente.' 
      });
    }

    const scopes = [
      'https://www.googleapis.com/auth/drive.file',
      'https://www.googleapis.com/auth/drive'
    ];

    const authUrl = googleOAuth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      state: req.user!.id, // Pass user ID in state
      prompt: 'consent'
    });

    res.json({ authUrl });
  } catch (error) {
    logger.error({
      event: 'google_auth_init_error',
      userId: req.user!.id,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to initiate Google Drive authentication');
    res.status(500).json({ message: 'Falha ao iniciar autenticação com Google Drive' });
  }
}

export async function handleGoogleCallback(req: Request, res: Response) {
  try {
    const { code, state } = req.query;
    const userId = state as string;

    if (!code || !userId) {
      return res.status(400).json({ message: 'Invalid callback parameters' });
    }

    // Exchange code for tokens
    const { tokens } = await googleOAuth2Client.getToken(code as string);
    
    if (!tokens.access_token) {
      return res.status(400).json({ message: 'Failed to get access token' });
    }

    // Save credentials to database
    const existingCredentials = await storage.getCloudCredentials(userId, 'google_drive');
    
    if (existingCredentials) {
      await storage.updateCloudCredentials(existingCredentials.id, {
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token || existingCredentials.refreshToken,
        expiresAt: tokens.expiry_date ? new Date(tokens.expiry_date) : null
      });
    } else {
      await storage.createCloudCredentials({
        userId,
        provider: 'google_drive',
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token || null,
        expiresAt: tokens.expiry_date ? new Date(tokens.expiry_date) : null
      });
    }

    logger.info({
      event: 'google_auth_success',
      userId
    }, 'Google Drive authentication successful');

    res.redirect(`${process.env.FRONTEND_URL}/settings?provider=google_drive&status=success`);
  } catch (error) {
    logger.error({
      event: 'google_auth_callback_error',
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to handle Google Drive callback');
    res.redirect(`${process.env.FRONTEND_URL}/settings?provider=google_drive&status=error`);
  }
}

// Dropbox OAuth routes
export async function initiateDropboxAuth(req: AuthenticatedRequest, res: Response) {
  try {
    // Check if Dropbox OAuth is configured
    if (!process.env.DROPBOX_CLIENT_ID || !process.env.DROPBOX_CLIENT_SECRET) {
      return res.status(400).json({ 
        message: 'Dropbox não está configurado. Adicione as credenciais OAuth2 nas variáveis de ambiente.' 
      });
    }

    const authUrl = `https://www.dropbox.com/oauth2/authorize?` +
      `client_id=${dropboxConfig.clientId}&` +
      `redirect_uri=${encodeURIComponent(dropboxConfig.redirectUrl!)}&` +
      `response_type=code&` +
      `state=${req.user!.id}`;

    res.json({ authUrl });
  } catch (error) {
    logger.error({
      event: 'dropbox_auth_init_error',
      userId: req.user!.id,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to initiate Dropbox authentication');
    res.status(500).json({ message: 'Falha ao iniciar autenticação com Dropbox' });
  }
}

export async function handleDropboxCallback(req: Request, res: Response) {
  try {
    const { code, state } = req.query;
    const userId = state as string;

    if (!code || !userId) {
      return res.status(400).json({ message: 'Invalid callback parameters' });
    }

    // Exchange code for access token
    const tokenResponse = await fetch('https://api.dropboxapi.com/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        code: code as string,
        grant_type: 'authorization_code',
        client_id: dropboxConfig.clientId!,
        client_secret: dropboxConfig.clientSecret!,
        redirect_uri: dropboxConfig.redirectUrl!
      })
    });

    const tokenData = await tokenResponse.json();

    if (!tokenData.access_token) {
      return res.status(400).json({ message: 'Failed to get access token' });
    }

    // Save credentials to database
    const existingCredentials = await storage.getCloudCredentials(userId, 'dropbox');
    
    if (existingCredentials) {
      await storage.updateCloudCredentials(existingCredentials.id, {
        accessToken: tokenData.access_token,
        expiresAt: tokenData.expires_in ? new Date(Date.now() + tokenData.expires_in * 1000) : null
      });
    } else {
      await storage.createCloudCredentials({
        userId,
        provider: 'dropbox',
        accessToken: tokenData.access_token,
        refreshToken: null,
        expiresAt: tokenData.expires_in ? new Date(Date.now() + tokenData.expires_in * 1000) : null
      });
    }

    logger.info({
      event: 'dropbox_auth_success',
      userId
    }, 'Dropbox authentication successful');

    res.redirect(`${process.env.FRONTEND_URL}/settings?provider=dropbox&status=success`);
  } catch (error) {
    logger.error({
      event: 'dropbox_auth_callback_error',
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to handle Dropbox callback');
    res.redirect(`${process.env.FRONTEND_URL}/settings?provider=dropbox&status=error`);
  }
}

// Disconnect cloud storage
export async function disconnectCloudStorage(req: AuthenticatedRequest, res: Response) {
  try {
    const { provider } = req.params;
    
    if (!['google_drive', 'dropbox'].includes(provider)) {
      return res.status(400).json({ message: 'Invalid provider' });
    }

    const success = await storage.deleteCloudCredentials(req.user!.id, provider);
    
    if (success) {
      logger.info({
        event: 'cloud_disconnect_success',
        provider,
        userId: req.user!.id
      }, `${provider} disconnected successfully`);
      
      res.json({ message: 'Cloud storage disconnected successfully' });
    } else {
      res.status(500).json({ message: 'Failed to disconnect cloud storage' });
    }
  } catch (error) {
    logger.error({
      event: 'cloud_disconnect_error',
      provider: req.params.provider,
      userId: req.user!.id,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to disconnect cloud storage');
    res.status(500).json({ message: 'Failed to disconnect cloud storage' });
  }
}

// Get cloud storage status
export async function getCloudStatus(req: AuthenticatedRequest, res: Response) {
  try {
    const googleCreds = await storage.getCloudCredentials(req.user!.id, 'google_drive');
    const dropboxCreds = await storage.getCloudCredentials(req.user!.id, 'dropbox');

    res.json({
      google_drive: {
        connected: !!googleCreds,
        expires_at: googleCreds?.expiresAt
      },
      dropbox: {
        connected: !!dropboxCreds,
        expires_at: dropboxCreds?.expiresAt
      }
    });
  } catch (error) {
    logger.error({
      event: 'cloud_status_error',
      userId: req.user!.id,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Failed to get cloud storage status');
    res.status(500).json({ message: 'Failed to get cloud storage status' });
  }
}