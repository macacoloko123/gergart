import pino from "pino";
import { pinoHttp } from "pino-http";

// Configuração do logger principal
export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  transport: process.env.NODE_ENV === "development" ? {
    target: "pino-pretty",
    options: {
      colorize: true,
      translateTime: "yyyy-mm-dd HH:MM:ss",
      ignore: "pid,hostname"
    }
  } : undefined,
  formatters: {
    level: (label) => {
      return { level: label };
    }
  }
});

// Middleware HTTP logger
export const httpLogger = pinoHttp({
  logger,
  customLogLevel: (req, res, err) => {
    if (res.statusCode >= 400 && res.statusCode < 500) {
      return "warn";
    } else if (res.statusCode >= 500 || err) {
      return "error";
    }
    return "info";
  },
  serializers: {
    req: (req) => ({
      method: req.method,
      url: req.url,
      headers: {
        "user-agent": req.headers["user-agent"],
        "content-type": req.headers["content-type"],
      },
    }),
    res: (res) => ({
      statusCode: res.statusCode,
    }),
  },
});

// Função para gerar requestId único
function generateRequestId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Função para logs estruturados com contexto completo
export function logUpload(filename: string, size: number, userId?: string, requestId?: string, setor?: string, ip?: string) {
  const logId = requestId || generateRequestId();
  logger.info({
    event: "file_upload",
    filename,
    size,
    userId,
    setor,
    ip,
    requestId: logId,
    timestamp: new Date().toISOString(),
    context: "pdf_upload"
  }, `Arquivo enviado: ${filename} (${Math.round(size / 1024)}KB) por usuário ${userId} setor ${setor} [${logId}]`);
}

export function logAuth(action: string, email: string, success: boolean, userId?: string, requestId?: string) {
  const logId = requestId || generateRequestId();
  logger.info({
    event: "auth_attempt",
    action,
    email,
    success,
    userId,
    requestId: logId,
    timestamp: new Date().toISOString(),
    context: "authentication"
  }, `${action}: ${email} - ${success ? 'SUCESSO' : 'FALHA'}${userId ? ` (ID: ${userId})` : ''} [${logId}]`);
}

export function logError(error: Error, context?: any, userId?: string, requestId?: string) {
  const logId = requestId || generateRequestId();
  logger.error({
    error: error.message,
    stack: error.stack,
    context,
    userId,
    requestId: logId,
    timestamp: new Date().toISOString()
  }, `Erro na aplicação [${logId}]: ${error.message}`);
}

export function logThumbnail(action: string, fileId: string, success: boolean, userId?: string, requestId?: string) {
  const logId = requestId || generateRequestId();
  logger.info({
    event: "thumbnail_generation",
    action,
    fileId,
    success,
    userId,
    requestId: logId,
    timestamp: new Date().toISOString(),
    context: "thumbnail_service"
  }, `Thumbnail ${action}: ${fileId} - ${success ? 'SUCESSO' : 'FALHA'} [${logId}]`);
}