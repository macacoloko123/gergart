/**
 * Swagger/OpenAPI Documentation Configuration
 * Auto-generates API documentation for PDFOrganizerPro
 */

import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'PDFOrganizerPro API',
      version: '1.0.0',
      description: 'Enterprise-grade PDF management system with advanced security and cloud integration',
      contact: {
        name: 'PDFOrganizerPro Team',
        email: 'support@pdforganizerpro.com'
      }
    },
    servers: [
      {
        url: process.env.NODE_ENV === 'production' ? 'https://your-domain.com' : 'http://localhost:5000',
        description: process.env.NODE_ENV === 'production' ? 'Production server' : 'Development server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      },
      schemas: {
        User: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            email: { type: 'string', format: 'email' },
            name: { type: 'string' },
            setor: { type: 'string' },
            userType: { 
              type: 'string', 
              enum: ['pending', 'employee', 'supervisor', 'external', 'admin'] 
            },
            isActive: { type: 'boolean' },
            isAdmin: { type: 'boolean' },
            canAddFiles: { type: 'boolean' },
            canEditFiles: { type: 'boolean' },
            canDeleteFiles: { type: 'boolean' },
            canViewAllSectorFiles: { type: 'boolean' },
            accessibleSectors: { 
              type: 'array', 
              items: { type: 'string' } 
            }
          }
        },
        PDF: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            name: { type: 'string' },
            filePath: { type: 'string' },
            size: { type: 'integer' },
            pages: { type: 'integer' },
            uploadedAt: { type: 'string', format: 'date-time' },
            setor: { type: 'string' },
            userId: { type: 'string', format: 'uuid' },
            isFavorite: { type: 'boolean' },
            isDeleted: { type: 'boolean' },
            folderId: { type: 'string', format: 'uuid', nullable: true },
            thumbnailPath: { type: 'string', nullable: true },
            cloudFileId: { type: 'string', nullable: true },
            cloudProvider: { type: 'string', nullable: true }
          }
        },
        AuditLog: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            userId: { type: 'string', format: 'uuid' },
            action: { type: 'string' },
            resourceType: { type: 'string' },
            resourceId: { type: 'string', nullable: true },
            ipAddress: { type: 'string' },
            userAgent: { type: 'string' },
            success: { type: 'boolean' },
            timestamp: { type: 'string', format: 'date-time' },
            metadata: { type: 'object' }
          }
        },
        Error: {
          type: 'object',
          properties: {
            message: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    },
    security: [
      {
        bearerAuth: []
      }
    ]
  },
  apis: ['./server/routes.ts'] // Path to the API routes
};

const specs = swaggerJSDoc(options);

export function setupSwagger(app: Express): void {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs, {
    explorer: true,
    customCss: '.swagger-ui .topbar { display: none }',
    customSiteTitle: 'PDFOrganizerPro API Documentation'
  }));
  
  // JSON endpoint for API spec
  app.get('/api-docs.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(specs);
  });
}

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags: [Authentication]
 *     summary: User login
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *               twoFactorCode:
 *                 type: string
 *                 description: Required if 2FA is enabled
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 accessToken:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 *                 user:
 *                   $ref: '#/components/schemas/User'
 *       400:
 *         description: Invalid credentials or missing 2FA code
 *       429:
 *         description: Rate limit exceeded
 */

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     tags: [Authentication]
 *     summary: User registration
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 minLength: 12
 *                 description: Must contain uppercase, lowercase, number, and special character
 *               name:
 *                 type: string
 *               setor:
 *                 type: string
 *     responses:
 *       201:
 *         description: User registered successfully, pending admin approval
 *       400:
 *         description: Validation error or user already exists
 *       429:
 *         description: Rate limit exceeded
 */

/**
 * @swagger
 * /api/pdfs/upload:
 *   post:
 *     tags: [PDFs]
 *     summary: Upload PDF file
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *               folderId:
 *                 type: string
 *                 format: uuid
 *                 nullable: true
 *     responses:
 *       200:
 *         description: File uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PDF'
 *       400:
 *         description: Invalid file format or validation error
 *       401:
 *         description: Authentication required
 *       403:
 *         description: Insufficient permissions
 *       413:
 *         description: File too large (max 50MB)
 */

/**
 * @swagger
 * /api/admin/audit/metrics:
 *   get:
 *     tags: [Admin - Audit]
 *     summary: Get audit metrics
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: Start date for metrics
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: End date for metrics
 *     responses:
 *       200:
 *         description: Audit metrics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 totalEvents:
 *                   type: integer
 *                 successfulEvents:
 *                   type: integer
 *                 failedEvents:
 *                   type: integer
 *                 criticalEvents:
 *                   type: integer
 *                 suspiciousActivities:
 *                   type: array
 *                   items:
 *                     type: object
 *       401:
 *         description: Authentication required
 *       403:
 *         description: Admin access required
 */

/**
 * @swagger
 * /api/admin/system/health:
 *   get:
 *     tags: [Admin - System]
 *     summary: Get system health status
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: System health status
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   enum: [healthy, degraded, critical]
 *                 timestamp:
 *                   type: string
 *                   format: date-time
 *                 services:
 *                   type: object
 *                   properties:
 *                     database:
 *                       type: string
 *                     thumbnails:
 *                       type: string
 *                     cloudStorage:
 *                       type: string
 *                 metrics:
 *                   type: object
 *                   properties:
 *                     errorRate:
 *                       type: number
 *                     responseTime:
 *                       type: number
 *                     activeUsers:
 *                       type: integer
 *       401:
 *         description: Authentication required
 *       403:
 *         description: Admin access required
 */