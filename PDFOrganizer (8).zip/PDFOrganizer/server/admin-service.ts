import { db } from "./db";
import { users, pdfPermissions, cloudFileIndex, approveUserSchema, grantPdfAccessSchema } from "@shared/schema";
import { eq, and, inArray, desc, asc } from "drizzle-orm";
import { logger } from "./logger";

export interface PendingUser {
  id: string;
  email: string;
  name: string;
  setor: string;
  createdAt: Date;
}

export interface UserPermissionUpdate {
  userId: string;
  userType: "employee" | "supervisor" | "external" | "admin";
  setor: string;
  canAddFiles: boolean;
  canEditFiles: boolean;
  canDeleteFiles: boolean;
  canViewAllSectorFiles: boolean;
  accessibleSectors: string[];
}

/**
 * Get all pending users waiting for approval
 */
export async function getPendingUsers(): Promise<PendingUser[]> {
  try {
    const pendingUsers = await db
      .select({
        id: users.id,
        email: users.email,
        name: users.name,
        setor: users.setor,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.userType, "pending"))
      .orderBy(desc(users.createdAt));

    return pendingUsers;
  } catch (error) {
    logger.error("Error fetching pending users:", error);
    throw error;
  }
}

/**
 * Approve a user and set their permissions
 */
export async function approveUser(
  adminId: string,
  userData: UserPermissionUpdate
): Promise<void> {
  try {
    const validation = approveUserSchema.safeParse(userData);
    if (!validation.success) {
      throw new Error("Invalid user data for approval");
    }

    await db
      .update(users)
      .set({
        userType: userData.userType,
        setor: userData.setor,
        canAddFiles: userData.canAddFiles,
        canEditFiles: userData.canEditFiles,
        canDeleteFiles: userData.canDeleteFiles,
        canViewAllSectorFiles: userData.canViewAllSectorFiles,
        accessibleSectors: userData.accessibleSectors,
        approvedBy: adminId,
        approvedAt: new Date(),
        isActive: true,
      })
      .where(eq(users.id, userData.userId));

    logger.info({
      event: "user_approved",
      userId: userData.userId,
      adminId,
      userType: userData.userType,
      setor: userData.setor,
    }, "User approved by admin");
  } catch (error) {
    logger.error("Error approving user:", error);
    throw error;
  }
}

/**
 * Reject a user account
 */
export async function rejectUser(adminId: string, userId: string): Promise<void> {
  try {
    await db
      .update(users)
      .set({
        isActive: false,
        approvedBy: adminId,
        approvedAt: new Date(),
      })
      .where(eq(users.id, userId));

    logger.info({
      event: "user_rejected",
      userId,
      adminId,
    }, "User rejected by admin");
  } catch (error) {
    logger.error("Error rejecting user:", error);
    throw error;
  }
}

/**
 * Deactivate a user (for dismissed employees)
 */
export async function deactivateUser(adminId: string, userId: string): Promise<void> {
  try {
    await db
      .update(users)
      .set({
        isActive: false,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    logger.info({
      event: "user_deactivated",
      userId,
      adminId,
    }, "User deactivated by admin");
  } catch (error) {
    logger.error("Error deactivating user:", error);
    throw error;
  }
}

/**
 * Grant specific PDF access to an external user
 */
export async function grantPdfAccess(
  adminId: string,
  pdfId: number,
  userId: string,
  permissions: {
    canView: boolean;
    canDownload: boolean;
    expiresAt?: Date;
  }
): Promise<void> {
  try {
    const validation = grantPdfAccessSchema.safeParse({
      pdfId,
      userId,
      ...permissions,
    });
    
    if (!validation.success) {
      throw new Error("Invalid PDF access data");
    }

    // Check if permission already exists
    const existingPermission = await db
      .select()
      .from(pdfPermissions)
      .where(
        and(
          eq(pdfPermissions.pdfId, pdfId),
          eq(pdfPermissions.userId, userId)
        )
      )
      .limit(1);

    if (existingPermission.length > 0) {
      // Update existing permission
      await db
        .update(pdfPermissions)
        .set({
          canView: permissions.canView,
          canDownload: permissions.canDownload,
          expiresAt: permissions.expiresAt,
          grantedBy: adminId,
        })
        .where(eq(pdfPermissions.id, existingPermission[0].id));
    } else {
      // Create new permission
      await db.insert(pdfPermissions).values({
        pdfId,
        userId,
        canView: permissions.canView,
        canDownload: permissions.canDownload,
        expiresAt: permissions.expiresAt,
        grantedBy: adminId,
      });
    }

    logger.info({
      event: "pdf_access_granted",
      pdfId,
      userId,
      adminId,
      permissions,
    }, "PDF access granted by admin");
  } catch (error) {
    logger.error("Error granting PDF access:", error);
    throw error;
  }
}

/**
 * Revoke PDF access from a user
 */
export async function revokePdfAccess(
  adminId: string,
  pdfId: number,
  userId: string
): Promise<void> {
  try {
    await db
      .delete(pdfPermissions)
      .where(
        and(
          eq(pdfPermissions.pdfId, pdfId),
          eq(pdfPermissions.userId, userId)
        )
      );

    logger.info({
      event: "pdf_access_revoked",
      pdfId,
      userId,
      adminId,
    }, "PDF access revoked by admin");
  } catch (error) {
    logger.error("Error revoking PDF access:", error);
    throw error;
  }
}

/**
 * Get all users with their permission details
 */
export async function getAllUsers(): Promise<any[]> {
  try {
    const allUsers = await db
      .select({
        id: users.id,
        email: users.email,
        name: users.name,
        setor: users.setor,
        userType: users.userType,
        isAdmin: users.isAdmin,
        isActive: users.isActive,
        canAddFiles: users.canAddFiles,
        canEditFiles: users.canEditFiles,
        canDeleteFiles: users.canDeleteFiles,
        canViewAllSectorFiles: users.canViewAllSectorFiles,
        accessibleSectors: users.accessibleSectors,
        approvedBy: users.approvedBy,
        approvedAt: users.approvedAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(asc(users.email));

    return allUsers;
  } catch (error) {
    logger.error("Error fetching all users:", error);
    throw error;
  }
}

/**
 * Update user permissions
 */
export async function updateUserPermissions(
  adminId: string,
  userData: UserPermissionUpdate
): Promise<void> {
  try {
    await db
      .update(users)
      .set({
        userType: userData.userType,
        setor: userData.setor,
        canAddFiles: userData.canAddFiles,
        canEditFiles: userData.canEditFiles,
        canDeleteFiles: userData.canDeleteFiles,
        canViewAllSectorFiles: userData.canViewAllSectorFiles,
        accessibleSectors: userData.accessibleSectors,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userData.userId));

    logger.info({
      event: "user_permissions_updated",
      userId: userData.userId,
      adminId,
      userType: userData.userType,
    }, "User permissions updated by admin");
  } catch (error) {
    logger.error("Error updating user permissions:", error);
    throw error;
  }
}