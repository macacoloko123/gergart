import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { storage } from './storage-db';
import { logger } from './logger';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const REFRESH_TOKEN_EXPIRY = 30 * 24 * 60 * 60 * 1000; // 30 days

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

export async function generateTokenPair(userId: string, email: string, setor: string, isAdmin: boolean): Promise<TokenPair> {
  // Generate short-lived access token (15 minutes)
  const accessToken = jwt.sign(
    { userId, email, setor, isAdmin },
    JWT_SECRET,
    { expiresIn: '15m' }
  );

  // Generate long-lived refresh token (30 days)
  const refreshTokenValue = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRY);

  // Store refresh token in database
  await storage.createRefreshToken(userId, refreshTokenValue, expiresAt);

  logger.info({
    event: 'token_pair_generated',
    userId,
    email,
    setor,
    timestamp: new Date().toISOString()
  }, `Token pair generated for user ${userId}`);

  return {
    accessToken,
    refreshToken: refreshTokenValue
  };
}

export async function refreshAccessToken(refreshToken: string): Promise<TokenPair | null> {
  try {
    const tokenRecord = await storage.getRefreshToken(refreshToken);
    
    if (!tokenRecord || tokenRecord.isRevoked || tokenRecord.expiresAt < new Date()) {
      logger.warn({
        event: 'refresh_token_invalid',
        token: refreshToken.substring(0, 8) + '...',
        reason: !tokenRecord ? 'not_found' : tokenRecord.isRevoked ? 'revoked' : 'expired',
        timestamp: new Date().toISOString()
      }, 'Invalid refresh token used');
      
      return null;
    }

    const user = await storage.getUser(tokenRecord.userId);
    
    if (!user || !user.isActive) {
      logger.warn({
        event: 'refresh_token_user_invalid',
        userId: tokenRecord.userId,
        reason: !user ? 'user_not_found' : 'user_inactive',
        timestamp: new Date().toISOString()
      }, 'Refresh token user validation failed');
      
      return null;
    }

    // Revoke old refresh token
    await storage.revokeRefreshToken(refreshToken);

    // Generate new token pair
    const newTokenPair = await generateTokenPair(user.id, user.email, user.setor, user.isAdmin);

    logger.info({
      event: 'access_token_refreshed',
      userId: user.id,
      email: user.email,
      timestamp: new Date().toISOString()
    }, `Access token refreshed for user ${user.id}`);

    return newTokenPair;
  } catch (error) {
    logger.error({
      event: 'refresh_token_error',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 'Error refreshing access token');
    
    return null;
  }
}

export async function revokeAllUserTokens(userId: string): Promise<void> {
  try {
    await storage.revokeAllUserRefreshTokens(userId);
    
    logger.info({
      event: 'all_tokens_revoked',
      userId,
      timestamp: new Date().toISOString()
    }, `All refresh tokens revoked for user ${userId}`);
  } catch (error) {
    logger.error({
      event: 'revoke_tokens_error',
      userId,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error revoking tokens for user ${userId}`);
    
    throw error;
  }
}

export async function revokeRefreshToken(refreshToken: string): Promise<void> {
  try {
    await storage.revokeRefreshToken(refreshToken);
    
    logger.info({
      event: 'refresh_token_revoked',
      token: refreshToken.substring(0, 8) + '...',
      timestamp: new Date().toISOString()
    }, 'Refresh token revoked');
  } catch (error) {
    logger.error({
      event: 'revoke_token_error',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 'Error revoking refresh token');
    
    throw error;
  }
}

export async function cleanupExpiredTokens(): Promise<void> {
  try {
    const deletedCount = await storage.cleanupExpiredRefreshTokens();
    
    logger.info({
      event: 'expired_tokens_cleaned',
      deletedCount,
      timestamp: new Date().toISOString()
    }, `Cleaned up ${deletedCount} expired refresh tokens`);
  } catch (error) {
    logger.error({
      event: 'cleanup_tokens_error',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 'Error cleaning up expired tokens');
  }
}

// Run cleanup every 24 hours
setInterval(cleanupExpiredTokens, 24 * 60 * 60 * 1000);