import { db } from "./db";
import { cloudFileIndex, cloudCredentials } from "@shared/schema";
import { eq, and, like, inArray } from "drizzle-orm";
import { logger } from "./logger";
import { cloudStorageManager } from "./cloud-storage";

export interface CloudSearchResult {
  id: string;
  fileName: string;
  fileSize: number;
  setor: string;
  provider: string;
  cloudFileId: string;
  lastIndexed: Date;
  downloadUrl?: string;
}

export interface SearchOptions {
  query: string;
  sectors?: string[];
  provider?: string;
  userId: string;
}

/**
 * Index files from Google Drive for search
 */
export async function indexCloudFiles(userId: string, provider: string): Promise<void> {
  try {
    // Get user's cloud credentials
    const credentials = await db
      .select()
      .from(cloudCredentials)
      .where(
        and(
          eq(cloudCredentials.userId, userId),
          eq(cloudCredentials.provider, provider),
          eq(cloudCredentials.isActive, true)
        )
      )
      .limit(1);

    if (!credentials.length) {
      throw new Error("Cloud credentials not found");
    }

    // Get cloud provider
    const cloudProvider = cloudStorageManager.getProvider(provider);
    if (!cloudProvider) {
      throw new Error("Cloud provider not available");
    }

    // List files from cloud storage
    const files = await cloudProvider.listFiles(userId);

    // Get user's sector
    const userResult = await db
      .select({ setor: cloudCredentials.userId })
      .from(cloudCredentials)
      .where(eq(cloudCredentials.userId, userId))
      .limit(1);

    const userSetor = userResult[0]?.setor || "ti";

    // Clear existing index for this user and provider
    await db
      .delete(cloudFileIndex)
      .where(
        and(
          eq(cloudFileIndex.userId, userId),
          eq(cloudFileIndex.provider, provider)
        )
      );

    // Index new files
    const indexEntries = files.map((file) => ({
      userId,
      provider,
      cloudFileId: file.id,
      fileName: file.name,
      fileSize: file.size,
      mimeType: file.mimeType,
      setor: userSetor,
      folderId: file.webViewLink || null,
      lastIndexed: new Date(),
      isDeleted: false,
    }));

    if (indexEntries.length > 0) {
      await db.insert(cloudFileIndex).values(indexEntries);
    }

    logger.info({
      event: "cloud_files_indexed",
      userId,
      provider,
      fileCount: files.length,
    }, "Cloud files indexed successfully");
  } catch (error) {
    logger.error("Error indexing cloud files:", error);
    throw error;
  }
}

/**
 * Search files across local storage and cloud storage
 */
export async function searchFiles(options: SearchOptions): Promise<CloudSearchResult[]> {
  try {
    const { query, sectors, provider, userId } = options;

    // Build search conditions
    const conditions = [
      eq(cloudFileIndex.isDeleted, false),
      like(cloudFileIndex.fileName, `%${query}%`),
    ];

    if (sectors && sectors.length > 0) {
      conditions.push(inArray(cloudFileIndex.setor, sectors));
    }

    if (provider) {
      conditions.push(eq(cloudFileIndex.provider, provider));
    }

    // Search in cloud file index
    const results = await db
      .select({
        id: cloudFileIndex.id,
        fileName: cloudFileIndex.fileName,
        fileSize: cloudFileIndex.fileSize,
        setor: cloudFileIndex.setor,
        provider: cloudFileIndex.provider,
        cloudFileId: cloudFileIndex.cloudFileId,
        lastIndexed: cloudFileIndex.lastIndexed,
        userId: cloudFileIndex.userId,
      })
      .from(cloudFileIndex)
      .where(and(...conditions))
      .orderBy(cloudFileIndex.lastIndexed)
      .limit(50);

    // Transform results
    const searchResults: CloudSearchResult[] = results.map((result) => ({
      id: result.id.toString(),
      fileName: result.fileName,
      fileSize: result.fileSize || 0,
      setor: result.setor,
      provider: result.provider,
      cloudFileId: result.cloudFileId,
      lastIndexed: result.lastIndexed,
    }));

    logger.info({
      event: "cloud_search_performed",
      userId,
      query,
      resultCount: searchResults.length,
    }, "Cloud search performed");

    return searchResults;
  } catch (error) {
    logger.error("Error searching cloud files:", error);
    throw error;
  }
}

/**
 * Get download URL for a cloud file
 */
export async function getCloudFileDownloadUrl(
  userId: string,
  provider: string,
  cloudFileId: string
): Promise<string> {
  try {
    // Get user's cloud credentials
    const credentials = await db
      .select()
      .from(cloudCredentials)
      .where(
        and(
          eq(cloudCredentials.userId, userId),
          eq(cloudCredentials.provider, provider),
          eq(cloudCredentials.isActive, true)
        )
      )
      .limit(1);

    if (!credentials.length) {
      throw new Error("Cloud credentials not found");
    }

    // Get cloud provider
    const cloudProvider = cloudStorageManager.getProvider(provider);
    if (!cloudProvider) {
      throw new Error("Cloud provider not available");
    }

    // Get share link
    const shareLink = await cloudProvider.getShareLink(cloudFileId, userId);

    logger.info({
      event: "cloud_file_download_url_generated",
      userId,
      provider,
      cloudFileId,
    }, "Cloud file download URL generated");

    return shareLink;
  } catch (error) {
    logger.error("Error getting cloud file download URL:", error);
    throw error;
  }
}

/**
 * Refresh cloud file index for a user
 */
export async function refreshCloudIndex(userId: string): Promise<void> {
  try {
    // Get all active cloud credentials for user
    const credentials = await db
      .select()
      .from(cloudCredentials)
      .where(
        and(
          eq(cloudCredentials.userId, userId),
          eq(cloudCredentials.isActive, true)
        )
      );

    // Index files from each connected provider
    for (const credential of credentials) {
      await indexCloudFiles(userId, credential.provider);
    }

    logger.info({
      event: "cloud_index_refreshed",
      userId,
      providerCount: credentials.length,
    }, "Cloud index refreshed for user");
  } catch (error) {
    logger.error("Error refreshing cloud index:", error);
    throw error;
  }
}

/**
 * Check if user has access to a specific sector's files
 */
export async function canAccessSector(userId: string, sector: string): Promise<boolean> {
  try {
    const user = await db
      .select({
        setor: cloudCredentials.userId,
        accessibleSectors: cloudCredentials.userId,
        canViewAllSectorFiles: cloudCredentials.userId,
      })
      .from(cloudCredentials)
      .where(eq(cloudCredentials.userId, userId))
      .limit(1);

    if (!user.length) {
      return false;
    }

    const userData = user[0];
    
    // User can access their own sector
    if (userData.setor === sector) {
      return true;
    }

    // User can access all sector files
    if (userData.canViewAllSectorFiles) {
      return true;
    }

    // User has specific access to this sector
    if (userData.accessibleSectors.includes(sector)) {
      return true;
    }

    return false;
  } catch (error) {
    logger.error("Error checking sector access:", error);
    return false;
  }
}