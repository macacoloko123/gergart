import { Request, Response, NextFunction } from 'express';
import { AuthenticatedRequest } from './auth';
import { storage } from './storage-db';
import { logger } from './logger';

// Setor validation middleware
export function validateSetor(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const { setor } = req.body;
  
  if (!setor || !['rh', 'logistica', 'almoxarifado'].includes(setor)) {
    return res.status(400).json({ message: 'Setor inválido' });
  }
  
  // User can only access their own setor (unless admin)
  if (!req.user?.isAdmin && req.user?.setor !== setor) {
    logAccessAttempt(req, 'setor_violation', false, 'Tentativa de acesso a setor não autorizado');
    return res.status(403).json({ message: 'Acesso negado: você não tem permissão para este setor' });
  }
  
  next();
}

// PDF access control middleware
export async function validatePdfAccess(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const pdfId = parseInt(req.params.id);
  
  if (!pdfId || isNaN(pdfId)) {
    return res.status(400).json({ message: 'ID do PDF inválido' });
  }
  
  try {
    const pdf = await storage.getPdf(pdfId);
    
    if (!pdf) {
      return res.status(404).json({ message: 'PDF não encontrado' });
    }
    
    // CRITICAL: Check setor access - users can only access PDFs from their setor
    if (!req.user?.isAdmin && pdf.setor !== req.user?.setor) {
      logAccessAttempt(req, 'pdf_access_denied', false, `Tentativa de acesso ao PDF ${pdfId} do setor ${pdf.setor} por usuário do setor ${req.user?.setor}`);
      return res.status(403).json({ message: 'Acesso negado: setor incompatível' });
    }
    
    // Check if user can access this PDF
    const canAccess = req.user?.isAdmin || pdf.userId === req.user?.id;
    
    if (!canAccess) {
      logAccessAttempt(req, 'pdf_access_denied', false, `Tentativa de acesso ao PDF ${pdfId} não autorizada`);
      return res.status(403).json({ message: 'Acesso negado: você não tem permissão para este PDF' });
    }
    
    // Store PDF in request for later use
    req.pdf = pdf;
    next();
  } catch (error) {
    logger.error({
      event: 'pdf_access_check_error',
      userId: req.user?.id,
      pdfId,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Erro ao verificar acesso ao PDF');
    
    return res.status(500).json({ message: 'Erro interno do servidor' });
  }
}

// Search with setor filtering
export function filterSearchBySetor(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const { setor } = req.query;
  
  // If setor is provided in query, validate it
  if (setor && typeof setor === 'string') {
    if (!['rh', 'logistica', 'almoxarifado'].includes(setor)) {
      return res.status(400).json({ message: 'Setor inválido na busca' });
    }
    
    // Non-admin users can only search their own setor
    if (!req.user?.isAdmin && req.user?.setor !== setor) {
      logAccessAttempt(req, 'search_setor_violation', false, `Tentativa de busca no setor ${setor}`);
      return res.status(403).json({ message: 'Acesso negado: você só pode buscar no seu setor' });
    }
  } else {
    // If no setor provided, force user's setor (unless admin)
    if (!req.user?.isAdmin) {
      req.query.setor = req.user?.setor;
    }
  }
  
  next();
}

// Log access attempts for audit
export async function logAccessAttempt(
  req: AuthenticatedRequest,
  action: string,
  success: boolean = true,
  errorMessage?: string
) {
  try {
    await storage.createAccessLog({
      userId: req.user?.id || 'anonymous',
      action,
      resourceType: getResourceTypeFromPath(req.path),
      resourceId: req.params.id || req.query.id as string,
      ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
      userAgent: req.get('User-Agent') || 'unknown',
      success,
      errorMessage,
    });
  } catch (error) {
    logger.error({
      event: 'access_log_error',
      userId: req.user?.id,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, 'Erro ao registrar log de acesso');
  }
}

// Helper to determine resource type from path
function getResourceTypeFromPath(path: string): string {
  if (path.includes('/pdfs')) return 'pdf';
  if (path.includes('/folders')) return 'folder';
  if (path.includes('/users')) return 'user';
  if (path.includes('/auth')) return 'auth';
  if (path.includes('/cloud')) return 'cloud';
  return 'unknown';
}

// Admin-only middleware
export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user?.isAdmin) {
    logAccessAttempt(req, 'admin_access_denied', false, 'Tentativa de acesso admin sem permissão');
    return res.status(403).json({ message: 'Acesso negado: apenas administradores' });
  }
  next();
}

// Active user middleware
export function requireActiveUser(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user?.isActive) {
    logAccessAttempt(req, 'inactive_user_access', false, 'Tentativa de acesso com usuário inativo');
    return res.status(403).json({ message: 'Acesso negado: usuário inativo' });
  }
  next();
}

// Declare pdf property on AuthenticatedRequest
declare global {
  namespace Express {
    interface Request {
      pdf?: any;
    }
  }
}