import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { Request, Response, NextFunction } from "express";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET || (() => {
  const devSecret = "dev-jwt-secret-7f3a8b9c2d1e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5";
  
  if (process.env.NODE_ENV === 'production') {
    throw new Error("JWT_SECRET environment variable is required for production. Please set it in your environment variables.");
  }
  
  console.warn("⚠️  WARNING: Using default JWT_SECRET for development. Configure JWT_SECRET in production!");
  return devSecret;
})();

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    setor: string;
    isAdmin: boolean;
    isActive: boolean;
    userType: string;
    canAddFiles: boolean;
    canEditFiles: boolean;
    canDeleteFiles: boolean;
    canViewAllSectorFiles: boolean;
    accessibleSectors: string[];
  };
}

/**
 * Validates password complexity according to enterprise security requirements
 * Based on NIST 800-63B and industry best practices
 */
export function validatePasswordComplexity(password: string): { valid: boolean; error?: string } {
  // Minimum 12 characters (enterprise standard)
  if (password.length < 12) {
    return { valid: false, error: 'A senha deve ter pelo menos 12 caracteres' };
  }
  
  // Maximum 128 characters to prevent DoS attacks
  if (password.length > 128) {
    return { valid: false, error: 'A senha não pode exceder 128 caracteres' };
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return { valid: false, error: 'A senha deve conter pelo menos uma letra maiúscula' };
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(password)) {
    return { valid: false, error: 'A senha deve conter pelo menos uma letra minúscula' };
  }
  
  // At least one number
  if (!/[0-9]/.test(password)) {
    return { valid: false, error: 'A senha deve conter pelo menos um número' };
  }
  
  // At least one special character (expanded set)
  if (!/[!@#$%^&*(),.?":{}|<>[\]\\;'~`+=_-]/.test(password)) {
    return { valid: false, error: 'A senha deve conter pelo menos um caractere especial (!@#$%^&*(),.?":{}|<>[\]\\;\'~`+=_-)' };
  }
  
  // Check for common weak patterns
  const commonPatterns = [
    /(.)\1{2,}/,  // Three or more consecutive identical characters
    /123|abc|qwe|password|admin|user|test/i,  // Common sequences
    /(.)(.)(.)\1\2\3/,  // Repeating patterns like abcabc
  ];
  
  for (const pattern of commonPatterns) {
    if (pattern.test(password)) {
      return { valid: false, error: 'A senha contém padrões previsíveis. Use uma combinação mais complexa' };
    }
  }
  
  return { valid: true };
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(userId: string, email: string, setor: string, isAdmin: boolean): string {
  return jwt.sign({ userId, email, setor, isAdmin }, JWT_SECRET, { expiresIn: "15m" });
}

export function verifyToken(token: string): { userId: string; email: string; setor: string; isAdmin: boolean } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; email: string; setor: string; isAdmin: boolean };
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function authenticate(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Token não fornecido" });
    }

    const token = authHeader.substring(7);
    const decoded = verifyToken(token);
    
    if (!decoded) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const user = await db.select().from(users).where(eq(users.id, decoded.userId)).limit(1);
    
    if (!user.length) {
      return res.status(401).json({ message: "Usuário não encontrado" });
    }

    // Check if user is active
    if (!user[0].isActive) {
      return res.status(403).json({ message: "Usuário inativo" });
    }

    // Additional security: Verify that user data hasn't changed since token was issued
    // This prevents using tokens with outdated permissions
    if (user[0].setor !== decoded.setor || user[0].isAdmin !== decoded.isAdmin) {
      return res.status(401).json({ message: "Token expired - permissions changed" });
    }
    
    req.user = {
      id: user[0].id,
      email: user[0].email,
      name: user[0].name,
      setor: user[0].setor, // Always use fresh data from database
      isAdmin: user[0].isAdmin, // Always use fresh data from database
      isActive: user[0].isActive,
    };

    next();
  } catch (error) {
    console.error("Erro de autenticação:", error);
    res.status(401).json({ message: "Erro de autenticação" });
  }
}

export function optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next();
  }

  const token = authHeader.substring(7);
  const decoded = verifyToken(token);
  
  if (decoded) {
    db.select().from(users).where(eq(users.id, decoded.userId)).limit(1)
      .then(user => {
        if (user.length) {
          req.user = {
            id: user[0].id,
            email: user[0].email,
            name: user[0].name,
          };
        }
        next();
      })
      .catch(() => next());
  } else {
    next();
  }
}