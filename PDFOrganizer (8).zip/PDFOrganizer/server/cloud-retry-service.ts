/**
 * Cloud Storage Retry Service
 * Implements exponential backoff for failed cloud storage operations
 */

import { logger } from './logger';

interface RetryConfig {
  maxAttempts: number;
  initialDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

interface RetryJob {
  id: string;
  userId: string;
  filePath: string;
  fileName: string;
  provider: string;
  attempt: number;
  nextRetryAt: Date;
  lastError?: string;
}

class CloudRetryService {
  private retryQueue: Map<string, RetryJob> = new Map();
  private config: RetryConfig = {
    maxAttempts: 3,
    initialDelay: 1000, // 1 second
    maxDelay: 30000, // 30 seconds
    backoffMultiplier: 2
  };

  private isProcessing = false;

  /**
   * Add a failed sync operation to the retry queue
   */
  public addToRetryQueue(
    userId: string,
    filePath: string,
    fileName: string,
    provider: string,
    error: Error
  ): void {
    const jobId = `${userId}-${fileName}-${provider}`;
    
    const existingJob = this.retryQueue.get(jobId);
    const attempt = existingJob ? existingJob.attempt + 1 : 1;
    
    if (attempt > this.config.maxAttempts) {
      logger.error('Cloud sync failed after max attempts', {
        userId,
        fileName,
        provider,
        attempts: attempt,
        error: error.message
      });
      this.retryQueue.delete(jobId);
      return;
    }

    const delay = Math.min(
      this.config.initialDelay * Math.pow(this.config.backoffMultiplier, attempt - 1),
      this.config.maxDelay
    );

    const job: RetryJob = {
      id: jobId,
      userId,
      filePath,
      fileName,
      provider,
      attempt,
      nextRetryAt: new Date(Date.now() + delay),
      lastError: error.message
    };

    this.retryQueue.set(jobId, job);
    
    logger.info('Cloud sync added to retry queue', {
      jobId,
      userId,
      fileName,
      provider,
      attempt,
      nextRetryAt: job.nextRetryAt.toISOString(),
      delay
    });

    // Start processing if not already running
    if (!this.isProcessing) {
      this.startProcessing();
    }
  }

  /**
   * Remove a successful sync from retry queue
   */
  public removeFromRetryQueue(userId: string, fileName: string, provider: string): void {
    const jobId = `${userId}-${fileName}-${provider}`;
    this.retryQueue.delete(jobId);
  }

  /**
   * Start processing the retry queue
   */
  private startProcessing(): void {
    this.isProcessing = true;
    this.processQueue();
  }

  /**
   * Process jobs in the retry queue
   */
  private async processQueue(): Promise<void> {
    if (this.retryQueue.size === 0) {
      this.isProcessing = false;
      return;
    }

    const now = new Date();
    const jobsToProcess = Array.from(this.retryQueue.values())
      .filter(job => job.nextRetryAt <= now)
      .sort((a, b) => a.nextRetryAt.getTime() - b.nextRetryAt.getTime());

    for (const job of jobsToProcess) {
      try {
        await this.retryCloudSync(job);
      } catch (error) {
        logger.error('Error processing retry job', {
          jobId: job.id,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // Schedule next processing cycle
    setTimeout(() => this.processQueue(), 5000); // Check every 5 seconds
  }

  /**
   * Retry a cloud sync operation
   */
  private async retryCloudSync(job: RetryJob): Promise<void> {
    const { cloudStorageManager } = await import('./cloud-storage');
    
    try {
      logger.info('Retrying cloud sync', {
        jobId: job.id,
        userId: job.userId,
        fileName: job.fileName,
        provider: job.provider,
        attempt: job.attempt
      });

      await cloudStorageManager.syncFileToCloud(
        job.filePath,
        job.fileName,
        job.userId,
        job.provider
      );

      // Success - remove from queue
      this.retryQueue.delete(job.id);
      
      logger.info('Cloud sync retry successful', {
        jobId: job.id,
        userId: job.userId,
        fileName: job.fileName,
        provider: job.provider,
        attempt: job.attempt
      });

    } catch (error) {
      // Failed - add back to queue with increased attempt count
      this.addToRetryQueue(
        job.userId,
        job.filePath,
        job.fileName,
        job.provider,
        error instanceof Error ? error : new Error('Unknown error')
      );
    }
  }

  /**
   * Get retry queue status
   */
  public getQueueStatus(): {
    totalJobs: number;
    pendingJobs: number;
    jobs: Array<{
      id: string;
      userId: string;
      fileName: string;
      provider: string;
      attempt: number;
      nextRetryAt: string;
      lastError?: string;
    }>;
  } {
    const now = new Date();
    const jobs = Array.from(this.retryQueue.values());
    
    return {
      totalJobs: jobs.length,
      pendingJobs: jobs.filter(job => job.nextRetryAt <= now).length,
      jobs: jobs.map(job => ({
        id: job.id,
        userId: job.userId,
        fileName: job.fileName,
        provider: job.provider,
        attempt: job.attempt,
        nextRetryAt: job.nextRetryAt.toISOString(),
        lastError: job.lastError
      }))
    };
  }
}

export const cloudRetryService = new CloudRetryService();