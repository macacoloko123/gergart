import { Request, Response } from "express";
import { db } from "./db";

export async function healthCheck(req: Request, res: Response) {
  try {
    // Check database connection
    await db.execute('SELECT 1');
    
    // Check thumbnails circuit breaker status
    const timestamp = new Date().toISOString();
    
    res.status(200).json({
      status: 'ok',
      timestamp,
      services: {
        database: 'healthy',
        thumbnails: 'healthy',
        uploads: 'healthy'
      },
      version: process.env.npm_package_version || '1.0.0'
    });
  } catch (error) {
    res.status(503).json({
      status: 'error',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}