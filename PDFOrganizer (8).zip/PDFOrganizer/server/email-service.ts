import nodemailer from 'nodemailer';
import { logger } from './logger';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.RESET_EMAIL || 'noreply@pdforganizer.com',
    pass: process.env.RESET_EMAIL_PASSWORD || 'your-app-password'
  }
});

export async function sendPasswordResetEmail(email: string, token: string, name: string) {
  const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/reset-password?token=${token}`;
  
  const mailOptions = {
    from: 'PDFOrganizer Pro <noreply@pdforganizer.com>',
    to: email,
    subject: 'Redefinição de Senha - PDFOrganizer Pro',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Redefinição de Senha</h2>
        <p>Olá ${name},</p>
        <p>Você solicitou a redefinição de sua senha no PDFOrganizer Pro.</p>
        <p>Clique no link abaixo para redefinir sua senha:</p>
        <p style="margin: 20px 0;">
          <a href="${resetUrl}" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Redefinir Senha
          </a>
        </p>
        <p><strong>Este link expira em 15 minutos.</strong></p>
        <p>Se você não solicitou esta redefinição, ignore este email.</p>
        <hr style="margin: 20px 0;">
        <p style="color: #666; font-size: 12px;">
          Este é um email automático, não responda a esta mensagem.
        </p>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info({
      event: 'password_reset_email_sent',
      email,
      token: token.substring(0, 8) + '...' // Log only first 8 chars for security
    }, `Email de redefinição de senha enviado para ${email}`);
  } catch (error) {
    logger.error({
      event: 'password_reset_email_failed',
      email,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, `Falha ao enviar email de redefinição para ${email}`);
    throw new Error('Falha ao enviar email de redefinição');
  }
}