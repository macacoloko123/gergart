import { db } from "./db";
import { users, folders, pdfs, cloudCredentials, accessLogs, passwordResetTokens } from "@shared/schema";
import { eq, and, desc, like, or, ilike, gt, gte, lte, sql } from "drizzle-orm";
import type { InsertUser, InsertFolder, InsertPdf, InsertCloudCredentials, InsertAccessLog, InsertPasswordResetToken, User, Folder, Pdf, CloudCredentials, AccessLog, PasswordResetToken } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Folder operations
  getFolders(userId: string): Promise<Folder[]>;
  createFolder(folder: InsertFolder): Promise<Folder>;
  updateFolder(id: number, folder: Partial<InsertFolder>): Promise<Folder | undefined>;
  deleteFolder(id: number): Promise<boolean>;
  
  // PDF operations
  getPdfs(userId: string, folderId?: number, showDeleted?: boolean): Promise<Pdf[]>;
  getPdf(id: number): Promise<Pdf | undefined>;
  createPdf(pdf: InsertPdf): Promise<Pdf>;
  updatePdf(id: number, pdf: Partial<InsertPdf>): Promise<Pdf | undefined>;
  deletePdf(id: number): Promise<boolean>;
  toggleFavorite(id: number): Promise<Pdf | undefined>;
  searchPdfs(query: string, userId: string): Promise<Pdf[]>;
  getRecentPdfs(userId: string): Promise<Pdf[]>;
  getFavoritePdfs(userId: string): Promise<Pdf[]>;
  getDeletedPdfs(userId: string): Promise<Pdf[]>;
  restorePdf(id: number): Promise<Pdf | undefined>;
  permanentlyDeletePdf(id: number): Promise<boolean>;
  
  // Cloud storage operations
  getCloudCredentials(userId: string, provider: string): Promise<CloudCredentials | undefined>;
  createCloudCredentials(credentials: InsertCloudCredentials): Promise<CloudCredentials>;
  updateCloudCredentials(id: number, credentials: Partial<InsertCloudCredentials>): Promise<CloudCredentials | undefined>;
  deleteCloudCredentials(userId: string, provider: string): Promise<boolean>;
  updatePdfCloudSync(id: number, cloudProvider: string, cloudFileId: string, syncStatus: string): Promise<Pdf | undefined>;
  
  // Access logs for audit trail
  createAccessLog(log: InsertAccessLog): Promise<AccessLog>;
  getAccessLogs(userId?: string, limit?: number): Promise<AccessLog[]>;
  
  // PDF operations with setor filtering
  getPdfsBySetor(userId: string, setor: string, folderId?: number, showDeleted?: boolean): Promise<Pdf[]>;
  searchPdfsBySetor(query: string, userId: string, setor: string): Promise<Pdf[]>;
  
  // Password reset operations
  createPasswordResetToken(userId: string): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenAsUsed(token: string): Promise<boolean>;
  updateUserPassword(userId: string, passwordHash: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: Omit<InsertUser, "password"> & { passwordHash: string }): Promise<User> {
    const result = await db.insert(users).values({
      email: user.email,
      passwordHash: user.passwordHash,
      name: user.name,
      setor: user.setor,
      isAdmin: user.isAdmin || false,
      isActive: user.isActive !== false,
      userType: user.userType || "pending",
      canAddFiles: user.canAddFiles || false,
      canEditFiles: user.canEditFiles || false,
      canDeleteFiles: user.canDeleteFiles || false,
      canViewAllSectorFiles: user.canViewAllSectorFiles || false,
      accessibleSectors: user.accessibleSectors || [],
      provider: user.provider || "email",
      twoFactorEnabled: user.twoFactorEnabled || false,
    }).returning();
    return result[0];
  }

  async getFolders(userId: string): Promise<Folder[]> {
    return await db.select().from(folders).where(eq(folders.userId, userId));
  }

  async createFolder(folder: InsertFolder): Promise<Folder> {
    const result = await db.insert(folders).values(folder).returning();
    return result[0];
  }

  async updateFolder(id: number, updateData: Partial<InsertFolder>): Promise<Folder | undefined> {
    const result = await db.update(folders).set(updateData).where(eq(folders.id, id)).returning();
    return result[0];
  }

  async deleteFolder(id: number): Promise<boolean> {
    const result = await db.delete(folders).where(eq(folders.id, id));
    return result.count > 0;
  }

  async getPdfs(userId: string, folderId?: number, showDeleted = false): Promise<Pdf[]> {
    let query = db.select().from(pdfs).where(eq(pdfs.userId, userId));
    
    if (folderId) {
      query = query.where(eq(pdfs.folderId, folderId));
    }
    
    if (!showDeleted) {
      query = query.where(eq(pdfs.isDeleted, false));
    }
    
    return await query.orderBy(desc(pdfs.updatedAt));
  }

  async getPdf(id: number): Promise<Pdf | undefined> {
    const result = await db.select().from(pdfs).where(eq(pdfs.id, id)).limit(1);
    return result[0];
  }

  async createPdf(pdf: InsertPdf): Promise<Pdf> {
    const result = await db.insert(pdfs).values(pdf).returning();
    return result[0];
  }

  async updatePdf(id: number, updateData: Partial<InsertPdf>): Promise<Pdf | undefined> {
    const result = await db.update(pdfs).set({
      ...updateData,
      updatedAt: new Date()
    }).where(eq(pdfs.id, id)).returning();
    return result[0];
  }

  async deletePdf(id: number): Promise<boolean> {
    const result = await db.update(pdfs).set({
      isDeleted: true,
      deletedAt: new Date(),
      updatedAt: new Date()
    }).where(eq(pdfs.id, id)).returning();
    return result.length > 0;
  }

  async toggleFavorite(id: number): Promise<Pdf | undefined> {
    const pdf = await this.getPdf(id);
    if (!pdf) return undefined;
    
    return await this.updatePdf(id, { isFavorite: !pdf.isFavorite });
  }

  async searchPdfs(query: string, userId: string): Promise<Pdf[]> {
    const lowercaseQuery = `%${query.toLowerCase()}%`;
    
    return await db.select().from(pdfs).where(
      and(
        eq(pdfs.userId, userId),
        eq(pdfs.isDeleted, false),
        or(
          like(pdfs.name, lowercaseQuery),
          like(pdfs.originalName, lowercaseQuery)
        )
      )
    ).orderBy(desc(pdfs.updatedAt));
  }

  async getRecentPdfs(userId: string): Promise<Pdf[]> {
    return await db.select().from(pdfs)
      .where(and(eq(pdfs.userId, userId), eq(pdfs.isDeleted, false)))
      .orderBy(desc(pdfs.updatedAt))
      .limit(10);
  }

  async getFavoritePdfs(userId: string): Promise<Pdf[]> {
    return await db.select().from(pdfs)
      .where(and(eq(pdfs.userId, userId), eq(pdfs.isFavorite, true), eq(pdfs.isDeleted, false)))
      .orderBy(desc(pdfs.updatedAt));
  }

  async getDeletedPdfs(userId: string): Promise<Pdf[]> {
    return await db.select().from(pdfs)
      .where(and(eq(pdfs.userId, userId), eq(pdfs.isDeleted, true)))
      .orderBy(desc(pdfs.deletedAt));
  }

  async restorePdf(id: number): Promise<Pdf | undefined> {
    const result = await db.update(pdfs).set({
      isDeleted: false,
      deletedAt: null,
      updatedAt: new Date()
    }).where(eq(pdfs.id, id)).returning();
    return result[0];
  }

  async permanentlyDeletePdf(id: number): Promise<boolean> {
    const result = await db.delete(pdfs).where(eq(pdfs.id, id));
    return result.count > 0;
  }

  // Cloud storage operations
  async getCloudCredentials(userId: string, provider: string): Promise<CloudCredentials | undefined> {
    const result = await db.select().from(cloudCredentials)
      .where(and(
        eq(cloudCredentials.userId, userId),
        eq(cloudCredentials.provider, provider),
        eq(cloudCredentials.isActive, true)
      ))
      .limit(1);
    return result[0];
  }

  async createCloudCredentials(credentials: InsertCloudCredentials): Promise<CloudCredentials> {
    const result = await db.insert(cloudCredentials).values(credentials).returning();
    return result[0];
  }

  async updateCloudCredentials(id: number, credentials: Partial<InsertCloudCredentials>): Promise<CloudCredentials | undefined> {
    const result = await db.update(cloudCredentials)
      .set({ ...credentials, updatedAt: new Date() })
      .where(eq(cloudCredentials.id, id))
      .returning();
    return result[0];
  }

  async deleteCloudCredentials(userId: string, provider: string): Promise<boolean> {
    try {
      await db.update(cloudCredentials)
        .set({ isActive: false, updatedAt: new Date() })
        .where(and(
          eq(cloudCredentials.userId, userId),
          eq(cloudCredentials.provider, provider)
        ));
      return true;
    } catch (error) {
      console.error("Error deleting cloud credentials:", error);
      return false;
    }
  }

  async updatePdfCloudSync(id: number, cloudProvider: string, cloudFileId: string, syncStatus: string): Promise<Pdf | undefined> {
    const result = await db.update(pdfs)
      .set({
        cloudProvider,
        cloudFileId,
        cloudSyncStatus: syncStatus,
        cloudSyncedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(pdfs.id, id))
      .returning();
    return result[0];
  }

  // Access logs for audit trail
  async createAccessLog(log: InsertAccessLog): Promise<AccessLog> {
    const result = await db.insert(accessLogs).values(log).returning();
    return result[0];
  }

  async getAccessLogs(userId?: string, limit = 100): Promise<AccessLog[]> {
    let query = db.select().from(accessLogs);
    
    if (userId) {
      query = query.where(eq(accessLogs.userId, userId));
    }
    
    return await query.orderBy(desc(accessLogs.timestamp)).limit(limit);
  }

  // PDF operations with setor filtering
  async getPdfsBySetor(userId: string, setor: string, folderId?: number, showDeleted = false): Promise<Pdf[]> {
    let query = db.select().from(pdfs)
      .where(and(eq(pdfs.userId, userId), eq(pdfs.setor, setor)));
    
    if (folderId) {
      query = query.where(eq(pdfs.folderId, folderId));
    }
    
    if (!showDeleted) {
      query = query.where(eq(pdfs.isDeleted, false));
    }
    
    return await query.orderBy(desc(pdfs.updatedAt));
  }

  async searchPdfsBySetor(query: string, userId: string, setor: string): Promise<Pdf[]> {
    const searchTerm = `%${query}%`;
    return await db.select().from(pdfs)
      .where(
        and(
          eq(pdfs.userId, userId),
          eq(pdfs.setor, setor),
          eq(pdfs.isDeleted, false),
          or(
            ilike(pdfs.name, searchTerm),
            ilike(pdfs.originalName, searchTerm)
          )
        )
      )
      .orderBy(desc(pdfs.updatedAt))
      .limit(50);
  }
  
  // Password reset operations
  async createPasswordResetToken(userId: string): Promise<PasswordResetToken> {
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    const token = crypto.randomUUID();
    
    const result = await db.insert(passwordResetTokens).values({
      userId,
      token,
      expiresAt,
      used: false
    }).returning();
    
    return result[0];
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const result = await db.select().from(passwordResetTokens).where(
      and(
        eq(passwordResetTokens.token, token),
        eq(passwordResetTokens.used, false),
        gt(passwordResetTokens.expiresAt, new Date())
      )
    ).limit(1);
    
    return result[0];
  }

  async markPasswordResetTokenAsUsed(token: string): Promise<boolean> {
    const result = await db.update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.token, token))
      .returning();
    
    return result.length > 0;
  }

  async updateUserPassword(userId: string, passwordHash: string): Promise<boolean> {
    const result = await db.update(users)
      .set({ passwordHash })
      .where(eq(users.id, userId))
      .returning();
    
    return result.length > 0;
  }

  // 2FA Methods
  async enableTwoFactorAuth(userId: string, secret: string, backupCodes: string[]): Promise<void> {
    await db.update(users)
      .set({ 
        twoFactorSecret: secret,
        twoFactorEnabled: true,
        twoFactorBackupCodes: backupCodes
      })
      .where(eq(users.id, userId));
  }

  async disableTwoFactorAuth(userId: string): Promise<void> {
    await db.update(users)
      .set({ 
        twoFactorSecret: null,
        twoFactorEnabled: false,
        twoFactorBackupCodes: null
      })
      .where(eq(users.id, userId));
  }

  async updateUserBackupCodes(userId: string, backupCodes: string[]): Promise<void> {
    await db.update(users)
      .set({ twoFactorBackupCodes: backupCodes })
      .where(eq(users.id, userId));
  }

  // Refresh Token Methods
  async createRefreshToken(userId: string, token: string, expiresAt: Date): Promise<RefreshToken> {
    const [refreshToken] = await db.insert(refreshTokens)
      .values({
        userId,
        token,
        expiresAt,
        isRevoked: false
      })
      .returning();
    
    return refreshToken;
  }

  async getRefreshToken(token: string): Promise<RefreshToken | null> {
    const [refreshToken] = await db.select()
      .from(refreshTokens)
      .where(eq(refreshTokens.token, token))
      .limit(1);
    
    return refreshToken || null;
  }

  async revokeRefreshToken(token: string): Promise<void> {
    await db.update(refreshTokens)
      .set({ 
        isRevoked: true,
        revokedAt: new Date()
      })
      .where(eq(refreshTokens.token, token));
  }

  async revokeAllUserRefreshTokens(userId: string): Promise<void> {
    await db.update(refreshTokens)
      .set({ 
        isRevoked: true,
        revokedAt: new Date()
      })
      .where(eq(refreshTokens.userId, userId));
  }

  async cleanupExpiredRefreshTokens(): Promise<number> {
    const result = await db.delete(refreshTokens)
      .where(
        or(
          lt(refreshTokens.expiresAt, new Date()),
          eq(refreshTokens.isRevoked, true)
        )
      );
    
    return result.rowCount || 0;
  }

  // Audit Methods
  async getAuditLogs(query: {
    userId?: string;
    action?: string;
    resourceType?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<AccessLog[]> {
    let queryBuilder = db.select()
      .from(accessLogs)
      .orderBy(desc(accessLogs.timestamp));

    const conditions = [];
    
    if (query.userId) {
      conditions.push(eq(accessLogs.userId, query.userId));
    }
    
    if (query.action) {
      conditions.push(eq(accessLogs.action, query.action));
    }
    
    if (query.resourceType) {
      conditions.push(eq(accessLogs.resourceType, query.resourceType));
    }
    
    if (query.startDate) {
      conditions.push(gte(accessLogs.timestamp, query.startDate));
    }
    
    if (query.endDate) {
      conditions.push(lte(accessLogs.timestamp, query.endDate));
    }

    if (conditions.length > 0) {
      queryBuilder = queryBuilder.where(and(...conditions));
    }

    if (query.limit) {
      queryBuilder = queryBuilder.limit(query.limit);
    }

    if (query.offset) {
      queryBuilder = queryBuilder.offset(query.offset);
    }

    return await queryBuilder;
  }

  async getAuditStats(startDate?: Date, endDate?: Date): Promise<{
    totalLogs: number;
    loginAttempts: number;
    successfulLogins: number;
    failedLogins: number;
    passwordResets: number;
    fileUploads: number;
    fileDownloads: number;
    fileDeletions: number;
    twoFactorEvents: number;
  }> {
    const conditions = [];
    
    if (startDate) {
      conditions.push(gte(accessLogs.timestamp, startDate));
    }
    
    if (endDate) {
      conditions.push(lte(accessLogs.timestamp, endDate));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const totalLogs = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(whereClause);

    const loginAttempts = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'login'),
        whereClause
      ).filter(Boolean));

    const successfulLogins = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'login'),
        eq(accessLogs.success, true),
        whereClause
      ).filter(Boolean));

    const failedLogins = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'login'),
        eq(accessLogs.success, false),
        whereClause
      ).filter(Boolean));

    const passwordResets = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'password_reset'),
        whereClause
      ).filter(Boolean));

    const fileUploads = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'upload_pdf'),
        whereClause
      ).filter(Boolean));

    const fileDownloads = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'download_pdf'),
        whereClause
      ).filter(Boolean));

    const fileDeletions = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.action, 'delete_pdf'),
        whereClause
      ).filter(Boolean));

    const twoFactorEvents = await db.select({ count: sql<number>`count(*)` })
      .from(accessLogs)
      .where(and(
        eq(accessLogs.resourceType, 'security'),
        whereClause
      ).filter(Boolean));

    return {
      totalLogs: totalLogs[0].count,
      loginAttempts: loginAttempts[0].count,
      successfulLogins: successfulLogins[0].count,
      failedLogins: failedLogins[0].count,
      passwordResets: passwordResets[0].count,
      fileUploads: fileUploads[0].count,
      fileDownloads: fileDownloads[0].count,
      fileDeletions: fileDeletions[0].count,
      twoFactorEvents: twoFactorEvents[0].count
    };
  }

  // Dashboard-specific methods
  async getDirectorStats(): Promise<{
    totalFiles: number;
    totalUsers: number;
    pendingApprovals: number;
    storageUsed: string;
    recentActivity: number;
  }> {
    const totalFiles = await db.select().from(pdfs).where(eq(pdfs.isDeleted, false));
    const totalUsers = await db.select().from(users).where(eq(users.isActive, true));
    const pendingApprovals = await db.select().from(users).where(eq(users.userType, 'pending'));
    const recentActivity = await db.select().from(accessLogs);

    return {
      totalFiles: totalFiles.length,
      totalUsers: totalUsers.length,
      pendingApprovals: pendingApprovals.length,
      storageUsed: "2.5 GB",
      recentActivity: recentActivity.length
    };
  }

  async getSectorSummaries(): Promise<{
    sector: string;
    fileCount: number;
    userCount: number;
    recentUploads: number;
    status: "active" | "warning" | "inactive";
  }[]> {
    try {
      const sectors = ["ti", "rh", "financeiro", "comercial", "marketing", "operacional", "juridico", "diretoria"];
      const summaries = [];

      for (const sector of sectors) {
        try {
          const sectorUsers = await db.select().from(users).where(and(
            eq(users.setor, sector),
            eq(users.isActive, true)
          ));

          const sectorFiles = await db.select().from(pdfs).where(and(
            eq(pdfs.setor, sector),
            eq(pdfs.isDeleted, false)
          ));

          const recentFiles = await db.select().from(pdfs).where(and(
            eq(pdfs.setor, sector),
            eq(pdfs.isDeleted, false),
            gt(pdfs.createdAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
          ));

          summaries.push({
            sector,
            fileCount: sectorFiles.length,
            userCount: sectorUsers.length,
            recentUploads: recentFiles.length,
            status: (sectorFiles.length > 0 && sectorUsers.length > 0) ? "active" : "warning"
          });
        } catch (sectorError) {
          console.error(`Error processing sector ${sector}:`, sectorError);
          summaries.push({
            sector,
            fileCount: 0,
            userCount: 0,
            recentUploads: 0,
            status: "inactive"
          });
        }
      }

      return summaries;
    } catch (error) {
      console.error('Error in getSectorSummaries:', error);
      throw error;
    }
  }

  async getRecentActivities(): Promise<{
    id: string;
    action: string;
    user: string;
    sector: string;
    timestamp: Date;
    file?: string;
  }[]> {
    try {
      const activities = await db.select({
        id: accessLogs.id,
        action: accessLogs.action,
        userId: accessLogs.userId,
        timestamp: accessLogs.timestamp,
        resourceId: accessLogs.resourceId
      }).from(accessLogs)
        .orderBy(desc(accessLogs.timestamp))
        .limit(20);

      const result = [];
      for (const activity of activities) {
        try {
          const user = await db.select().from(users).where(eq(users.id, activity.userId)).limit(1);
          if (user.length > 0) {
            result.push({
              id: activity.id.toString(),
              action: activity.action,
              user: user[0].name,
              sector: user[0].setor,
              timestamp: activity.timestamp,
              file: activity.resourceId || undefined
            });
          }
        } catch (userError) {
          console.error(`Error fetching user for activity ${activity.id}:`, userError);
        }
      }

      return result;
    } catch (error) {
      console.error('Error in getRecentActivities:', error);
      throw error;
    }
  }

  async getFilesBySector(userId: string, sector?: string): Promise<{
    id: number;
    name: string;
    setor: string;
    uploadedBy: string;
    uploadedAt: Date;
    fileSize: number;
    provider?: string;
    downloadUrl?: string;
  }[]> {
    const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user.length) return [];

    const userData = user[0];
    const accessibleSectors = userData.accessibleSectors || [userData.setor];

    let query = db.select({
      id: pdfs.id,
      name: pdfs.name,
      setor: pdfs.setor,
      uploadedBy: pdfs.userId,
      uploadedAt: pdfs.createdAt,
      fileSize: pdfs.size
    }).from(pdfs)
      .where(eq(pdfs.isDeleted, false));

    if (sector && sector !== "all") {
      query = query.where(eq(pdfs.setor, sector));
    }

    const files = await query.orderBy(desc(pdfs.createdAt));

    const result = [];
    for (const file of files) {
      const uploader = await db.select().from(users).where(eq(users.id, file.uploadedBy)).limit(1);
      result.push({
        id: file.id,
        name: file.name,
        setor: file.setor,
        uploadedBy: uploader.length > 0 ? uploader[0].name : "Unknown",
        uploadedAt: file.uploadedAt,
        fileSize: file.fileSize || 0
      });
    }

    return result;
  }

  async getAccessibleFilesForExternal(userId: string): Promise<{
    id: number;
    name: string;
    setor: string;
    fileSize: number;
    uploadedBy: string;
    uploadedAt: Date;
    canView: boolean;
    canDownload: boolean;
    expiresAt?: Date;
    grantedBy: string;
  }[]> {
    return [];
  }

  async updateUser(userId: string, updates: Partial<User>): Promise<boolean> {
    try {
      const result = await db.update(users)
        .set(updates)
        .where(eq(users.id, userId))
        .returning();
      return result.length > 0;
    } catch (error) {
      console.error('Error updating user:', error);
      return false;
    }
  }
}

export const storage = new DatabaseStorage();