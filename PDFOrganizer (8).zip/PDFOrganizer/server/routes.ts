import { Request, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage-db";
import { authenticate, AuthenticatedRequest, hashPassword, verifyPassword, generateToken, validatePasswordComplexity } from "./auth";
import { requireActiveUser, validatePdfAccess, filterSearchBySetor, logAccessAttempt } from "./security-middleware";
import { logger, logUpload, logAuth, logError, logThumbnail, httpLogger } from "./logger";
import { insertFolderSchema, insertPdfSchema, insertUserSchema } from "@shared/schema";
import { healthCheck } from "./health";
import { validatePDFFile, sanitizeFilePath, validateFileUpload, generateSecureFilename } from "./file-security";
import { cloudStorageManager } from "./cloud-storage";
import { initiateGoogleAuth, handleGoogleCallback, initiateDropboxAuth, handleDropboxCallback, disconnectCloudStorage, getCloudStatus } from "./cloud-auth";
import { sendPasswordResetEmail } from "./email-service";
import { generateTwoFactorSecret, enableTwoFactor, disableTwoFactor, verifyTwoFactor } from './two-factor-auth';
import { refreshAccessToken, revokeAllUserTokens } from './refresh-token';
import { getAuditLogs, getAuditStats, getUserActivitySummary, detectSuspiciousActivity } from './audit-service';
import { logSecurityEvent, detectSuspiciousActivities, getAuditMetrics, generateAuditReport, monitorSystemHealth } from './enhanced-audit-service';
import type { AuditQuery } from './audit-service';
import { requireAdmin } from './security-middleware';
import { cloudRetryService } from './cloud-retry-service';
import { setupSwagger } from './swagger';
import { 
  getPendingUsers, 
  approveUser, 
  rejectUser, 
  deactivateUser, 
  grantPdfAccess, 
  revokePdfAccess, 
  getAllUsers, 
  updateUserPermissions 
} from './admin-service';
import { 
  indexCloudFiles, 
  searchFiles, 
  getCloudFileDownloadUrl, 
  refreshCloudIndex, 
  canAccessSector 
} from './cloud-search-service';
import multer from "multer";
import path from "path";
import fs from "fs";
import { z } from "zod";
import rateLimit from "express-rate-limit";
import busboy from "busboy";
import { PDFDocument } from "pdf-lib";
import CircuitBreaker from "opossum";
// import sharp from "sharp"; // Not needed for basic implementation

// Validation schema for PDF upload
const pdfUploadSchema = z.object({
  mimetype: z.literal("application/pdf"),
  size: z.number().max(50 * 1024 * 1024), // 50MB max
  originalname: z.string().min(1),
});

const upload = multer({ 
  dest: "uploads/",
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req: any, file: any, cb: any) => {
    try {
      pdfUploadSchema.parse({
        mimetype: file.mimetype,
        size: file.size,
        originalname: file.originalname,
      });
      cb(null, true);
    } catch (error) {
      cb(new Error("Invalid file: Only PDF files under 50MB are allowed"));
    }
  }
});

// Rate limiting middleware
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 requests per windowMs
  message: "Muitas tentativas de login. Tente novamente em 15 minutos.",
  standardHeaders: true,
  legacyHeaders: false,
});

const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // limit each IP to 50 uploads per windowMs
  message: "Muitos uploads. Tente novamente em 15 minutos.",
});

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: "Muitas requisições. Tente novamente em 15 minutos.",
});

// Enhanced rate limiting for password reset (more aggressive)
const passwordResetLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // limit each IP to 3 password reset requests per hour
  message: "Muitas tentativas de reset de senha. Tente novamente em 1 hora.",
  standardHeaders: true,
  legacyHeaders: false,
});

// Ultra-aggressive rate limiting for actual password reset execution
const passwordResetExecutionLimiter = rateLimit({
  windowMs: 2 * 60 * 60 * 1000, // 2 hours
  max: 2, // limit each IP to 2 password reset executions per 2 hours
  message: "Muitas tentativas de redefinição de senha. Tente novamente em 2 horas.",
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // Only count failed attempts
});

// PDF thumbnail generation com Circuit Breaker
async function generateThumbnailInternal(pdfBuffer: Buffer, fileId: string, userId?: string, requestId?: string): Promise<Buffer> {
  try {
    logThumbnail("start", fileId, true, userId, requestId);
    
    const pdf = await PDFDocument.load(pdfBuffer);
    const pages = pdf.getPages();
    if (pages.length === 0) {
      logThumbnail("empty_pdf", fileId, false, userId, requestId);
      return Buffer.alloc(0);
    }
    
    const firstPage = pages[0];
    const { width, height } = firstPage.getSize();
    
    // Create a simple thumbnail using sharp
    // Note: This is a basic implementation - for production use pdf2pic or similar
    const thumbnailWidth = 200;
    const thumbnailHeight = (height * thumbnailWidth) / width;
    
    // Simulated thumbnail generation (in production, use pdf2pic or similar)
    const thumbnailBuffer = Buffer.alloc(thumbnailWidth * thumbnailHeight * 4);
    
    logThumbnail("success", fileId, true, userId, requestId);
    return thumbnailBuffer;
  } catch (error) {
    logThumbnail("error", fileId, false, userId, requestId);
    logError(error as Error, { fileId, service: "thumbnail" }, userId, requestId);
    throw error;
  }
}

// Circuit Breaker para thumbnails
const thumbnailCircuitBreaker = new CircuitBreaker(generateThumbnailInternal, {
  timeout: 5000, // 5 segundos timeout
  errorThresholdPercentage: 50, // 50% de erro para abrir
  resetTimeout: 30000, // 30 segundos para tentar novamente
  rollingCountTimeout: 60000, // Janela de 1 minuto
  rollingCountBuckets: 10 // 10 buckets
});

// Event handlers para o Circuit Breaker
thumbnailCircuitBreaker.on('open', () => {
  logger.warn({ service: "thumbnail", circuit: "open" }, "Circuit breaker ABERTO - Thumbnails desabilitados temporariamente");
});

thumbnailCircuitBreaker.on('halfOpen', () => {
  logger.info({ service: "thumbnail", circuit: "half-open" }, "Circuit breaker MEIO-ABERTO - Testando thumbnails");
});

thumbnailCircuitBreaker.on('close', () => {
  logger.info({ service: "thumbnail", circuit: "closed" }, "Circuit breaker FECHADO - Thumbnails funcionando normalmente");
});

// Função pública para gerar thumbnails
async function generateThumbnail(pdfBuffer: Buffer, fileId: string, userId?: string, requestId?: string): Promise<Buffer> {
  try {
    return await thumbnailCircuitBreaker.fire(pdfBuffer, fileId, userId, requestId);
  } catch (error) {
    // Fallback: retorna buffer vazio se circuit breaker estiver aberto
    logger.warn({ 
      service: "thumbnail", 
      fileId, 
      userId, 
      requestId,
      circuitOpen: thumbnailCircuitBreaker.opened
    }, "Thumbnail falhou - usando fallback");
    return Buffer.alloc(0);
  }
}

// Helper function to sync to cloud storage if enabled
async function syncToCloudStorageIfEnabled(pdf: any, userId: string, filePath: string) {
  // Check if user has any cloud storage configured
  const googleCreds = await storage.getCloudCredentials(userId, 'google_drive');
  const dropboxCreds = await storage.getCloudCredentials(userId, 'dropbox');
  
  // Try to sync to all configured providers
  if (googleCreds) {
    try {
      const cloudFileId = await cloudStorageManager.syncFileToCloud(
        filePath,
        pdf.originalName,
        userId,
        'google_drive',
        {
          accessToken: googleCreds.accessToken,
          refreshToken: googleCreds.refreshToken
        }
      );
      await storage.updatePdfCloudSync(pdf.id, 'google_drive', cloudFileId, 'synced');
    } catch (error) {
      logger.warn({
        event: 'google_drive_sync_failed',
        pdfId: pdf.id,
        userId
      }, 'Failed to sync to Google Drive');
    }
  }
  
  if (dropboxCreds) {
    try {
      const cloudFileId = await cloudStorageManager.syncFileToCloud(
        filePath,
        pdf.originalName,
        userId,
        'dropbox',
        {
          accessToken: dropboxCreds.accessToken
        }
      );
      await storage.updatePdfCloudSync(pdf.id, 'dropbox', cloudFileId, 'synced');
    } catch (error) {
      logger.warn({
        event: 'dropbox_sync_failed',
        pdfId: pdf.id,
        userId
      }, 'Failed to sync to Dropbox');
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Trust proxy for rate limiting
  app.set('trust proxy', 1);
  // Add HTTP logger
  app.use(httpLogger);
  
  // Setup Swagger documentation
  setupSwagger(app);
  
  // Apply rate limiting to all API routes
  app.use('/api/', generalLimiter);
  
  // Ensure uploads directory exists
  if (!fs.existsSync("uploads")) {
    fs.mkdirSync("uploads");
  }

  // Health check endpoint
  app.get("/health", healthCheck);

  // Authentication routes with rate limiting
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      const { email, name, password } = insertUserSchema.parse(req.body);
      
      // Validate password complexity
      const passwordValidation = validatePasswordComplexity(password);
      if (!passwordValidation.valid) {
        return res.status(400).json({ message: passwordValidation.error });
      }
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        const requestId = `req-${Date.now()}`;
        logAuth("register", email, false, undefined, requestId);
        return res.status(400).json({ message: "Usuário já existe" });
      }
      
      // Create user in pending state - requires admin approval
      const passwordHash = await hashPassword(password);
      const user = await storage.createUser({
        email,
        passwordHash,
        name,
        setor: req.body.setor,
        provider: "email",
        userType: "pending", // New users start as pending
        isActive: false, // Not active until approved
        canAddFiles: false,
        canEditFiles: false,
        canDeleteFiles: false,
        canViewAllSectorFiles: false,
        accessibleSectors: []
      });
      
      const requestId = `req-${Date.now()}`;
      logAuth("register", email, true, user.id, requestId);
      
      res.json({
        message: "Conta criada com sucesso. Aguardando aprovação do administrador.",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          setor: user.setor,
          userType: user.userType,
          isActive: user.isActive
        }
      });
    } catch (error) {
      logError(error as Error, { action: "register" });
      res.status(400).json({ message: "Dados inválidos" });
    }
  });

  app.post("/api/auth/login", authLimiter, async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      const requestId = `req-${Date.now()}`;
      if (!user || !user.passwordHash) {
        logAuth("login", email, false, undefined, requestId);
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      const validPassword = await verifyPassword(password, user.passwordHash);
      if (!validPassword) {
        logAuth("login", email, false, user.id, requestId);
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      const token = generateToken(user.id, user.email, user.setor, user.isAdmin);
      logAuth("login", email, true, user.id, requestId);
      
      res.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          setor: user.setor,
          isAdmin: user.isAdmin
        }
      });
    } catch (error) {
      logError(error as Error, { action: "login" });
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Get current user info (middleware já valida o token)
  app.get("/api/auth/me", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Usuário não autenticado" });
      }

      // Buscar dados completos do usuário no banco
      const user = await storage.getUser(req.user.id);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Retornar todos os dados necessários para o dashboard
      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        setor: user.setor,
        isAdmin: user.isAdmin,
        isActive: user.isActive,
        userType: user.userType,
        canAddFiles: user.canAddFiles,
        canEditFiles: user.canEditFiles,
        canDeleteFiles: user.canDeleteFiles,
        canViewAllSectorFiles: user.canViewAllSectorFiles,
        accessibleSectors: user.accessibleSectors
      });
    } catch (error) {
      logError(error as Error, { action: "get_user_info", userId: req.user?.id });
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Folder routes
  app.get("/api/folders", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const folders = await storage.getFolders(req.user!.id);
      res.json(folders);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to fetch folders" });
    }
  });

  app.post("/api/folders", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const validatedData = insertFolderSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      const folder = await storage.createFolder(validatedData);
      res.status(201).json(folder);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(400).json({ message: "Invalid folder data" });
    }
  });

  app.put("/api/folders/:id", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertFolderSchema.partial().parse(req.body);
      const folder = await storage.updateFolder(id, validatedData);
      
      if (!folder) {
        return res.status(404).json({ message: "Folder not found" });
      }
      
      res.json(folder);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(400).json({ message: "Invalid folder data" });
    }
  });

  app.delete("/api/folders/:id", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFolder(id);
      
      if (!success) {
        return res.status(404).json({ message: "Folder not found" });
      }
      
      res.json({ message: "Folder deleted successfully" });
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to delete folder" });
    }
  });

  // PDF routes
  app.get("/api/pdfs", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const folderId = req.query.folderId ? parseInt(req.query.folderId as string) : undefined;
      const showDeleted = req.query.showDeleted === "true";
      const pdfs = await storage.getPdfsBySetor(req.user!.id, req.user!.setor, folderId, showDeleted);
      res.json(pdfs);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to fetch PDFs" });
    }
  });

  app.get("/api/pdfs/recent", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const pdfs = await storage.getRecentPdfs(req.user!.id);
      res.json(pdfs);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to fetch recent PDFs" });
    }
  });

  app.get("/api/pdfs/favorites", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const pdfs = await storage.getFavoritePdfs(req.user!.id);
      res.json(pdfs);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to fetch favorite PDFs" });
    }
  });

  app.get("/api/pdfs/deleted", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const pdfs = await storage.getDeletedPdfs(req.user!.id);
      res.json(pdfs);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to fetch deleted PDFs" });
    }
  });

  app.get("/api/pdfs/search", authenticate, requireActiveUser, filterSearchBySetor, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.json([]);
      }
      const pdfs = await storage.searchPdfsBySetor(query, req.user!.id, req.user!.setor);
      res.json(pdfs);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to search PDFs" });
    }
  });

  app.post("/api/pdfs/upload", authenticate, uploadLimiter, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const bb = busboy({ 
        headers: req.headers,
        limits: {
          fileSize: 50 * 1024 * 1024, // 50MB
          files: 1
        }
      });

      let uploadedFile: {
        filename: string;
        originalName: string;
        filePath: string;
        size: number;
        buffer: Buffer;
      } | null = null;

      let formFields: { [key: string]: string } = {};

      bb.on('field', (name: string, val: any) => {
        formFields[name] = val;
      });

      bb.on('file', (name: string, file: any, info: any) => {
        const { filename, encoding, mimeType } = info;
        
        // Enhanced file validation
        const validation = validateFileUpload(filename, mimeType, 0); // Size will be checked during upload
        if (!validation.valid) {
          file.resume(); // drain the file stream
          res.status(400).json({ message: validation.error });
          return;
        }

        // Generate secure unique filename
        const uniqueFilename = generateSecureFilename(filename);
        const filePath = path.join("uploads", uniqueFilename);
        
        // Create write stream for efficient file handling
        const writeStream = fs.createWriteStream(filePath);
        let fileSize = 0;
        const chunks: Buffer[] = [];

        file.on('data', (data: Buffer) => {
          fileSize += data.length;
          chunks.push(data);
          
          // Check size limit during upload
          if (fileSize > 50 * 1024 * 1024) {
            writeStream.destroy();
            if (fs.existsSync(filePath)) {
              fs.unlinkSync(filePath);
            }
            res.status(400).json({ message: "File too large. Maximum size is 50MB" });
            return;
          }
        });

        file.on('end', () => {
          const buffer = Buffer.concat(chunks);
          
          // CRITICAL FIX: Validate PDF magic bytes BEFORE saving to disk
          if (buffer.subarray(0, 4).toString() !== '%PDF') {
            res.status(400).json({ message: "Invalid PDF file format" });
            return;
          }
          
          uploadedFile = {
            filename: uniqueFilename,
            originalName: filename,
            filePath,
            size: fileSize,
            buffer
          };
          
          // Only save to disk after validation
          fs.writeFileSync(filePath, buffer);
        });

        // Remove pipe to disk - we'll write after validation
        // file.pipe(writeStream);
        
        writeStream.on('finish', () => {
          // Magic bytes validation moved to before file save
        });
        
        writeStream.on('error', (error: Error) => {
          logError(error, { userId: req.user!.id, action: 'file_write' });
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
          }
          res.status(500).json({ message: "Failed to save file" });
        });
      });

      bb.on('finish', async () => {
        try {
          if (!uploadedFile) {
            return res.status(400).json({ message: "No file uploaded" });
          }

          // Extract PDF page count using pdf-lib
          let pageCount = 1;
          try {
            const pdf = await PDFDocument.load(uploadedFile.buffer);
            pageCount = pdf.getPageCount();
          } catch (error) {
            logger.warn("Could not extract page count from PDF", { error });
          }

          // Generate thumbnail
          let thumbnailPath: string | null = null;
          try {
            const fileId = `${Date.now()}-${uploadedFile.originalName}`;
            const requestId = `req-${Date.now()}`;
            const thumbnailBuffer = await generateThumbnail(uploadedFile.buffer, fileId, req.user!.id, requestId);
            if (thumbnailBuffer.length > 0) {
              thumbnailPath = path.join("uploads", "thumbnails", `${uploadedFile.filename}.jpg`);
              
              // Ensure thumbnails directory exists
              const thumbnailDir = path.dirname(thumbnailPath);
              if (!fs.existsSync(thumbnailDir)) {
                fs.mkdirSync(thumbnailDir, { recursive: true });
              }
              
              fs.writeFileSync(thumbnailPath, thumbnailBuffer);
            }
          } catch (error) {
            logger.warn("Could not generate thumbnail", { error });
          }

          // SECURITY: Always use server-side setor validation
          const userSetor = req.user!.setor;
          const folderId = formFields.folderId ? parseInt(formFields.folderId) : null;
          
          const pdfData = {
            name: formFields.name || uploadedFile.originalName.replace('.pdf', ''),
            originalName: uploadedFile.originalName,
            filePath: uploadedFile.filePath,
            size: uploadedFile.size,
            pages: pageCount,
            folderId: folderId,
            userId: req.user!.id,
            setor: userSetor, // Never trust client input for setor
            isFavorite: false,
            isDeleted: false,
            thumbnailPath,
          };

          const pdf = await storage.createPdf(pdfData);
          const requestId = `req-${Date.now()}`;
          logUpload(uploadedFile.originalName, uploadedFile.size, req.user!.id, requestId, userSetor, req.ip);
          
          // Sync to cloud storage if configured (with retry mechanism)
          try {
            await syncToCloudStorageIfEnabled(pdf, req.user!.id, uploadedFile.filePath);
          } catch (error) {
            // Add to retry queue if sync fails
            cloudRetryService.addToRetryQueue(
              req.user!.id,
              uploadedFile.filePath,
              uploadedFile.originalName,
              'google_drive', // Default provider, could be dynamic
              error instanceof Error ? error : new Error('Cloud sync failed')
            );
            
            logger.warn({
              event: 'cloud_sync_failed_queued_retry',
              pdfId: pdf.id,
              userId: req.user!.id,
              error: error instanceof Error ? error.message : 'Unknown error'
            }, 'Failed to sync file to cloud storage - added to retry queue');
          }
          
          res.status(201).json(pdf);
        } catch (error) {
          logError(error as Error, { userId: req.user!.id, action: 'pdf_save' });
          res.status(500).json({ message: "Failed to process PDF" });
        }
      });

      bb.on('error', (error: Error) => {
        logError(error, { userId: req.user!.id, action: 'upload_parse' });
        res.status(500).json({ message: "Upload failed" });
      });

      req.pipe(bb);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to upload PDF" });
    }
  });

  app.put("/api/pdfs/:id", authenticate, requireActiveUser, validatePdfAccess, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPdfSchema.partial().parse(req.body);
      const pdf = await storage.updatePdf(id, validatedData);
      
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      res.json(pdf);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(400).json({ message: "Invalid PDF data" });
    }
  });

  app.post("/api/pdfs/:id/favorite", authenticate, requireActiveUser, validatePdfAccess, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const pdf = await storage.toggleFavorite(id);
      
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      res.json(pdf);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to toggle favorite" });
    }
  });

  app.delete("/api/pdfs/:id", authenticate, requireActiveUser, validatePdfAccess, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePdf(id);
      
      if (!success) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      res.json({ message: "PDF moved to trash" });
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to delete PDF" });
    }
  });

  app.post("/api/pdfs/:id/restore", authenticate, requireActiveUser, validatePdfAccess, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const pdf = await storage.restorePdf(id);
      
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      res.json(pdf);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to restore PDF" });
    }
  });

  app.delete("/api/pdfs/:id/permanent", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const pdf = await storage.getPdf(id);
      
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      // Remove file from filesystem
      if (fs.existsSync(pdf.filePath)) {
        fs.unlinkSync(pdf.filePath);
      }
      
      const success = await storage.permanentlyDeletePdf(id);
      
      if (!success) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      res.json({ message: "PDF permanently deleted" });
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to permanently delete PDF" });
    }
  });

  // Download endpoint with enhanced security
  app.get("/api/pdfs/:id/download", authenticate, requireActiveUser, validatePdfAccess, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const pdf = await storage.getPdf(id);
      
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      // Security: Check if user has access to this PDF
      if (pdf.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Security: Sanitize file path to prevent directory traversal
      const safeFilePath = sanitizeFilePath(pdf.filePath);

      if (!fs.existsSync(safeFilePath)) {
        return res.status(404).json({ message: "File not found" });
      }

      // Additional security: Validate it's still a PDF
      if (!validatePDFFile(safeFilePath)) {
        return res.status(400).json({ message: "Invalid PDF file" });
      }

      const stat = fs.statSync(safeFilePath);
      
      // Security headers
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Content-Disposition', `attachment; filename="${pdf.originalName}"`);
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-XSS-Protection', '1; mode=block');
      
      const fileStream = fs.createReadStream(safeFilePath);
      fileStream.pipe(res);
    } catch (error) {
      logError(error as Error, { userId: req.user!.id });
      res.status(500).json({ message: "Failed to download PDF" });
    }
  });

  // Cloud storage authentication routes
  app.get("/api/cloud/auth/google", authenticate, initiateGoogleAuth);
  app.get("/api/cloud/callback/google", handleGoogleCallback);
  app.get("/api/cloud/auth/dropbox", authenticate, initiateDropboxAuth);
  app.get("/api/cloud/callback/dropbox", handleDropboxCallback);
  app.delete("/api/cloud/disconnect/:provider", authenticate, disconnectCloudStorage);
  app.get("/api/cloud/status", authenticate, getCloudStatus);

  // Cloud storage file operations
  app.post("/api/cloud/sync/:id", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const pdfId = parseInt(req.params.id);
      const { provider } = req.body;
      
      if (!['google_drive', 'dropbox'].includes(provider)) {
        return res.status(400).json({ message: 'Invalid provider' });
      }
      
      const pdf = await storage.getPdf(pdfId);
      if (!pdf || pdf.userId !== req.user!.id) {
        return res.status(404).json({ message: "PDF not found" });
      }
      
      const credentials = await storage.getCloudCredentials(req.user!.id, provider);
      if (!credentials) {
        return res.status(400).json({ message: 'Cloud storage not configured' });
      }
      
      const cloudFileId = await cloudStorageManager.syncFileToCloud(
        pdf.filePath,
        pdf.originalName,
        req.user!.id,
        provider,
        credentials
      );
      
      await storage.updatePdfCloudSync(pdfId, provider, cloudFileId, 'synced');
      
      res.json({ message: 'File synced to cloud storage successfully', cloudFileId });
    } catch (error) {
      logger.error({
        event: 'cloud_sync_error',
        pdfId: req.params.id,
        userId: req.user!.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'Failed to sync file to cloud storage');
      res.status(500).json({ message: 'Failed to sync file to cloud storage' });
    }
  });

  app.get("/api/cloud/files/:provider", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { provider } = req.params;
      
      if (!['google_drive', 'dropbox'].includes(provider)) {
        return res.status(400).json({ message: 'Invalid provider' });
      }
      
      const credentials = await storage.getCloudCredentials(req.user!.id, provider);
      if (!credentials) {
        return res.status(400).json({ message: 'Cloud storage not configured' });
      }
      
      const cloudProvider = cloudStorageManager.getProvider(provider);
      if (!cloudProvider) {
        return res.status(500).json({ message: 'Provider not available' });
      }
      
      // Set credentials and list files
      const files = await cloudProvider.listFiles(req.user!.id);
      res.json(files);
    } catch (error) {
      logger.error({
        event: 'cloud_list_error',
        provider: req.params.provider,
        userId: req.user!.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'Failed to list cloud files');
      res.status(500).json({ message: 'Failed to list cloud files' });
    }
  });

  // Password reset routes
  app.post("/api/auth/forgot-password", passwordResetLimiter, async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email é obrigatório" });
      }
      
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Return success even if user doesn't exist (security best practice)
        return res.json({ message: "Se o email existir, um link de redefinição foi enviado" });
      }
      
      const resetToken = await storage.createPasswordResetToken(user.id);
      
      await sendPasswordResetEmail(user.email, resetToken.token, user.name);
      
      res.json({ message: "Link de redefinição de senha enviado para seu email" });
    } catch (error) {
      logger.error("Error in forgot password:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });
  
  app.post("/api/auth/reset-password", passwordResetExecutionLimiter, async (req: Request, res: Response) => {
    try {
      const { token, newPassword } = req.body;
      
      if (!token || !newPassword) {
        return res.status(400).json({ error: "Token e nova senha são obrigatórios" });
      }
      
      // Enhanced password validation
      const passwordValidation = validatePasswordComplexity(newPassword);
      if (!passwordValidation.valid) {
        return res.status(400).json({ error: passwordValidation.error });
      }
      
      const resetToken = await storage.getPasswordResetToken(token);
      
      if (!resetToken || resetToken.used) {
        return res.status(400).json({ error: "Token inválido ou já utilizado" });
      }

      // Check if token has expired
      if (resetToken.expiresAt < new Date()) {
        return res.status(400).json({ error: "Token expirado. Solicite uma nova redefinição de senha." });
      }
      
      // CRITICAL FIX: Check if token was already used
      if (resetToken.used) {
        return res.status(400).json({ error: "Token já foi utilizado. Solicite uma nova redefinição de senha." });
      }
      
      const passwordHash = await hashPassword(newPassword);
      
      await storage.updateUserPassword(resetToken.userId, passwordHash);
      await storage.markPasswordResetTokenAsUsed(token);

      // Revoke all existing tokens for this user to force re-login
      const user = await storage.getUser(resetToken.userId);
      if (user) {
        await revokeAllUserTokens(user.id);
      }

      logger.info({
        event: 'password_reset_success',
        userId: resetToken.userId
      }, 'Password reset successful');
      
      res.json({ message: "Senha redefinida com sucesso" });
    } catch (error) {
      logger.error("Error in reset password:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // Health check endpoint
  app.get("/health", healthCheck);

  // Enhanced monitoring and audit endpoints
  app.get("/api/admin/system/health", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const healthStatus = await monitorSystemHealth();
      res.json(healthStatus);
    } catch (error) {
      logger.error("Error checking system health:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/metrics", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : new Date(Date.now() - 24 * 60 * 60 * 1000);
      const end = endDate ? new Date(endDate as string) : new Date();
      
      const metrics = await getAuditMetrics(start, end);
      res.json(metrics);
    } catch (error) {
      logger.error("Error fetching audit metrics:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/report", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const end = endDate ? new Date(endDate as string) : new Date();
      
      const report = await generateAuditReport(start, end);
      res.json(report);
    } catch (error) {
      logger.error("Error generating audit report:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/suspicious-activities/:userId", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId } = req.params;
      const { timeWindow } = req.query;
      
      const activities = await detectSuspiciousActivities(userId, timeWindow ? parseInt(timeWindow as string) : 30);
      res.json(activities);
    } catch (error) {
      logger.error("Error detecting suspicious activities:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // Cloud retry queue status endpoint
  app.get("/api/admin/cloud/retry-queue", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const queueStatus = cloudRetryService.getQueueStatus();
      res.json(queueStatus);
    } catch (error) {
      logger.error("Error getting retry queue status:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // Cloud authentication routes
  app.get("/api/cloud/auth/google", authenticate, initiateGoogleAuth);
  app.get("/api/cloud/auth/google/callback", handleGoogleCallback);
  app.get("/api/cloud/auth/dropbox", authenticate, initiateDropboxAuth);
  app.get("/api/cloud/auth/dropbox/callback", handleDropboxCallback);
  app.post("/api/cloud/auth/disconnect", authenticate, disconnectCloudStorage);
  app.get("/api/cloud/status", authenticate, getCloudStatus);

  // Auth refresh token route
  app.post("/api/auth/refresh", async (req: Request, res: Response) => {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return res.status(401).json({ error: "Refresh token não fornecido" });
    }
    
    try {
      const newTokens = await refreshAccessToken(refreshToken);
      
      if (!newTokens) {
        return res.status(401).json({ error: "Refresh token inválido" });
      }
      
      res.json(newTokens);
    } catch (error) {
      logger.error("Error refreshing token:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // 2FA Routes
  app.post("/api/auth/2fa/setup", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { secret, qrCodeUrl, backupCodes } = await generateTwoFactorSecret(req.user!.id, req.user!.email);
      
      res.json({
        secret,
        qrCodeUrl,
        backupCodes
      });
    } catch (error) {
      logger.error("Error setting up 2FA:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.post("/api/auth/2fa/enable", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { token, secret, backupCodes } = req.body;
      
      if (!token || !secret || !backupCodes) {
        return res.status(400).json({ error: "Token, secret e códigos de backup são obrigatórios" });
      }
      
      const success = await enableTwoFactor(req.user!.id, token, secret, backupCodes);
      
      if (!success) {
        return res.status(400).json({ error: "Token inválido" });
      }
      
      res.json({ message: "2FA ativado com sucesso" });
    } catch (error) {
      logger.error("Error enabling 2FA:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.post("/api/auth/2fa/disable", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: "Token é obrigatório" });
      }
      
      const success = await disableTwoFactor(req.user!.id, token);
      
      if (!success) {
        return res.status(400).json({ error: "Token inválido" });
      }
      
      res.json({ message: "2FA desativado com sucesso" });
    } catch (error) {
      logger.error("Error disabling 2FA:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.post("/api/auth/2fa/verify", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: "Token é obrigatório" });
      }
      
      const success = await verifyTwoFactor(req.user!.id, token);
      
      res.json({ valid: success });
    } catch (error) {
      logger.error("Error verifying 2FA:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // Admin Audit Routes
  app.get("/api/admin/audit/logs", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId, action, resourceType, startDate, endDate, limit, offset } = req.query;
      
      const query: AuditQuery = {
        userId: userId as string,
        action: action as string,
        resourceType: resourceType as string,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0
      };
      
      const logs = await getAuditLogs(query);
      
      res.json(logs);
    } catch (error) {
      logger.error("Error fetching audit logs:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/stats", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      const stats = await getAuditStats(
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      
      res.json(stats);
    } catch (error) {
      logger.error("Error fetching audit stats:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/users/:userId", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId } = req.params;
      const { days } = req.query;
      
      const summary = await getUserActivitySummary(userId, days ? parseInt(days as string) : 30);
      
      res.json(summary);
    } catch (error) {
      logger.error("Error fetching user activity:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.get("/api/admin/audit/suspicious/:userId", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId } = req.params;
      
      const activity = await detectSuspiciousActivity(userId);
      
      res.json(activity);
    } catch (error) {
      logger.error("Error detecting suspicious activity:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  app.post("/api/admin/audit/revoke-tokens/:userId", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId } = req.params;
      
      await revokeAllUserTokens(userId);
      
      res.json({ message: "Todos os tokens foram revogados" });
    } catch (error) {
      logger.error("Error revoking tokens:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  // Enhanced Admin Routes for User Management
  app.get("/api/admin/users/pending", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const pendingUsers = await getPendingUsers();
      res.json(pendingUsers);
    } catch (error) {
      logger.error("Error fetching pending users:", error);
      res.status(500).json({ message: "Failed to fetch pending users" });
    }
  });

  app.get("/api/admin/users/all", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const allUsers = await getAllUsers();
      res.json(allUsers);
    } catch (error) {
      logger.error("Error fetching all users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/admin/users/approve", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const userData = req.body;
      
      await approveUser(adminId, userData);
      
      res.json({ message: "User approved successfully" });
    } catch (error) {
      logger.error("Error approving user:", error);
      res.status(500).json({ message: "Failed to approve user" });
    }
  });

  app.post("/api/admin/users/reject", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const { userId } = req.body;
      
      await rejectUser(adminId, userId);
      
      res.json({ message: "User rejected successfully" });
    } catch (error) {
      logger.error("Error rejecting user:", error);
      res.status(500).json({ message: "Failed to reject user" });
    }
  });

  app.post("/api/admin/users/deactivate", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const { userId } = req.body;
      
      await deactivateUser(adminId, userId);
      
      res.json({ message: "User deactivated successfully" });
    } catch (error) {
      logger.error("Error deactivating user:", error);
      res.status(500).json({ message: "Failed to deactivate user" });
    }
  });

  app.put("/api/admin/users/permissions", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const userData = req.body;
      
      await updateUserPermissions(adminId, userData);
      
      res.json({ message: "User permissions updated successfully" });
    } catch (error) {
      logger.error("Error updating user permissions:", error);
      res.status(500).json({ message: "Failed to update permissions" });
    }
  });

  app.post("/api/admin/pdf-access/grant", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const { pdfId, userId, canView, canDownload, expiresAt } = req.body;
      
      await grantPdfAccess(adminId, pdfId, userId, {
        canView,
        canDownload,
        expiresAt: expiresAt ? new Date(expiresAt) : undefined,
      });
      
      res.json({ message: "PDF access granted successfully" });
    } catch (error) {
      logger.error("Error granting PDF access:", error);
      res.status(500).json({ message: "Failed to grant PDF access" });
    }
  });

  app.post("/api/admin/pdf-access/revoke", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const adminId = req.user!.id;
      const { pdfId, userId } = req.body;
      
      await revokePdfAccess(adminId, pdfId, userId);
      
      res.json({ message: "PDF access revoked successfully" });
    } catch (error) {
      logger.error("Error revoking PDF access:", error);
      res.status(500).json({ message: "Failed to revoke PDF access" });
    }
  });

  // Enhanced Search Routes (Cloud + Local)
  app.get("/api/search/cloud", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { query, sectors, provider } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const searchOptions = {
        query: query as string,
        sectors: sectors ? (sectors as string).split(',') : undefined,
        provider: provider as string,
        userId: req.user!.id,
      };
      
      const results = await searchFiles(searchOptions);
      
      res.json(results);
    } catch (error) {
      logger.error("Error searching cloud files:", error);
      res.status(500).json({ message: "Failed to search cloud files" });
    }
  });

  app.post("/api/cloud/index", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { provider } = req.body;
      
      if (!provider || !['google_drive', 'dropbox'].includes(provider)) {
        return res.status(400).json({ message: "Invalid provider" });
      }
      
      await indexCloudFiles(req.user!.id, provider);
      
      res.json({ message: "Cloud files indexed successfully" });
    } catch (error) {
      logger.error("Error indexing cloud files:", error);
      res.status(500).json({ message: "Failed to index cloud files" });
    }
  });

  app.post("/api/cloud/refresh-index", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      await refreshCloudIndex(req.user!.id);
      
      res.json({ message: "Cloud index refreshed successfully" });
    } catch (error) {
      logger.error("Error refreshing cloud index:", error);
      res.status(500).json({ message: "Failed to refresh cloud index" });
    }
  });

  app.get("/api/cloud/download/:provider/:fileId", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { provider, fileId } = req.params;
      
      if (!['google_drive', 'dropbox'].includes(provider)) {
        return res.status(400).json({ message: "Invalid provider" });
      }
      
      const downloadUrl = await getCloudFileDownloadUrl(req.user!.id, provider, fileId);
      
      res.json({ downloadUrl });
    } catch (error) {
      logger.error("Error getting cloud file download URL:", error);
      res.status(500).json({ message: "Failed to get download URL" });
    }
  });

  // Director Dashboard Routes
  app.get("/api/director/stats", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const stats = await storage.getDirectorStats();
      res.json(stats);
    } catch (error) {
      logger.error("Error fetching director stats:", error);
      res.status(500).json({ message: "Failed to fetch director stats" });
    }
  });

  app.get("/api/director/sectors", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const sectors = await storage.getSectorSummaries();
      res.json(sectors);
    } catch (error) {
      logger.error("Error fetching sector summaries:", error);
      res.status(500).json({ message: "Failed to fetch sector summaries" });
    }
  });

  app.get("/api/director/activities", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const activities = await storage.getRecentActivities();
      res.json(activities);
    } catch (error) {
      logger.error("Error fetching recent activities:", error);
      res.status(500).json({ message: "Failed to fetch recent activities" });
    }
  });

  // Supervisor Dashboard Routes
  app.get("/api/supervisor/files", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { sector } = req.query;
      const user = req.user!;
      
      // Check if user is supervisor
      if (user.userType !== 'supervisor') {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const files = await storage.getFilesBySector(user.id, sector as string);
      res.json(files);
    } catch (error) {
      logger.error("Error fetching supervisor files:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  // External User Dashboard Routes
  app.get("/api/external/files", authenticate, requireActiveUser, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = req.user!;
      
      // Check if user is external
      if (user.userType !== 'external') {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const files = await storage.getAccessibleFilesForExternal(user.id);
      res.json(files);
    } catch (error) {
      logger.error("Error fetching external user files:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  // Additional routes for admin user activation
  app.post("/api/admin/users/activate", authenticate, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userId } = req.body;
      if (!userId) {
        return res.status(400).json({ error: "ID do usuário é obrigatório" });
      }
      const success = await storage.updateUser(userId, { isActive: true });
      res.json({ message: success ? "Usuário ativado com sucesso" : "Erro ao ativar usuário" });
    } catch (error) {
      logger.error("Error activating user:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  });

  const server = createServer(app);
  return server;
}