import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import { logger } from './logger';
import { storage } from './storage-db';
import crypto from 'crypto';

export interface TwoFactorSetup {
  secret: string;
  qrCodeUrl: string;
  backupCodes: string[];
}

export async function generateTwoFactorSecret(userId: string, userEmail: string): Promise<TwoFactorSetup> {
  const secret = speakeasy.generateSecret({
    name: `PDFOrganizer Pro (${userEmail})`,
    issuer: 'PDFOrganizer Pro',
    length: 32,
  });

  // Generate 10 backup codes
  const backupCodes = Array.from({ length: 10 }, () => 
    crypto.randomBytes(4).toString('hex').toUpperCase()
  );

  const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url || '');

  logger.info({
    event: '2fa_setup_initiated',
    userId,
    email: userEmail,
    timestamp: new Date().toISOString()
  }, `2FA setup initiated for user ${userId}`);

  return {
    secret: secret.base32,
    qrCodeUrl,
    backupCodes
  };
}

export async function enableTwoFactor(userId: string, token: string, secret: string, backupCodes: string[]): Promise<boolean> {
  const isValid = speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token,
    window: 2
  });

  if (!isValid) {
    logger.warn({
      event: '2fa_enable_failed',
      userId,
      reason: 'invalid_token',
      timestamp: new Date().toISOString()
    }, `Failed to enable 2FA for user ${userId} - invalid token`);
    return false;
  }

  try {
    await storage.enableTwoFactorAuth(userId, secret, backupCodes);
    
    logger.info({
      event: '2fa_enabled',
      userId,
      timestamp: new Date().toISOString()
    }, `2FA successfully enabled for user ${userId}`);
    
    return true;
  } catch (error) {
    logger.error({
      event: '2fa_enable_error',
      userId,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error enabling 2FA for user ${userId}`);
    
    return false;
  }
}

export async function verifyTwoFactor(userId: string, token: string): Promise<boolean> {
  try {
    const user = await storage.getUser(userId);
    
    if (!user || !user.twoFactorEnabled || !user.twoFactorSecret) {
      return false;
    }

    // Check if it's a backup code
    if (user.twoFactorBackupCodes && user.twoFactorBackupCodes.includes(token.toUpperCase())) {
      // Remove used backup code
      const remainingCodes = user.twoFactorBackupCodes.filter(code => code !== token.toUpperCase());
      await storage.updateUserBackupCodes(userId, remainingCodes);
      
      logger.info({
        event: '2fa_backup_code_used',
        userId,
        remainingCodes: remainingCodes.length,
        timestamp: new Date().toISOString()
      }, `Backup code used for user ${userId}`);
      
      return true;
    }

    // Verify TOTP token
    const isValid = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token,
      window: 2
    });

    logger.info({
      event: '2fa_verification',
      userId,
      success: isValid,
      timestamp: new Date().toISOString()
    }, `2FA verification for user ${userId}: ${isValid ? 'success' : 'failed'}`);

    return isValid;
  } catch (error) {
    logger.error({
      event: '2fa_verification_error',
      userId,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error verifying 2FA for user ${userId}`);
    
    return false;
  }
}

export async function disableTwoFactor(userId: string, token: string): Promise<boolean> {
  const isValid = await verifyTwoFactor(userId, token);
  
  if (!isValid) {
    logger.warn({
      event: '2fa_disable_failed',
      userId,
      reason: 'invalid_token',
      timestamp: new Date().toISOString()
    }, `Failed to disable 2FA for user ${userId} - invalid token`);
    return false;
  }

  try {
    await storage.disableTwoFactorAuth(userId);
    
    logger.info({
      event: '2fa_disabled',
      userId,
      timestamp: new Date().toISOString()
    }, `2FA successfully disabled for user ${userId}`);
    
    return true;
  } catch (error) {
    logger.error({
      event: '2fa_disable_error',
      userId,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error disabling 2FA for user ${userId}`);
    
    return false;
  }
}