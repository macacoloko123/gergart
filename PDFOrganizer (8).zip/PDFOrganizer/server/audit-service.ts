import { storage } from './storage-db';
import { logger } from './logger';
import type { AccessLog, User } from '@shared/schema';

export interface AuditQuery {
  userId?: string;
  action?: string;
  resourceType?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}

export interface AuditStats {
  totalLogs: number;
  loginAttempts: number;
  successfulLogins: number;
  failedLogins: number;
  passwordResets: number;
  fileUploads: number;
  fileDownloads: number;
  fileDeletions: number;
  twoFactorEvents: number;
}

export async function getAuditLogs(query: AuditQuery): Promise<AccessLog[]> {
  try {
    const logs = await storage.getAuditLogs(query);
    
    logger.info({
      event: 'audit_logs_retrieved',
      query,
      resultCount: logs.length,
      timestamp: new Date().toISOString()
    }, `Retrieved ${logs.length} audit logs`);
    
    return logs;
  } catch (error) {
    logger.error({
      event: 'audit_logs_error',
      query,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 'Error retrieving audit logs');
    
    throw error;
  }
}

export async function getAuditStats(startDate?: Date, endDate?: Date): Promise<AuditStats> {
  try {
    const stats = await storage.getAuditStats(startDate, endDate);
    
    logger.info({
      event: 'audit_stats_retrieved',
      startDate,
      endDate,
      stats,
      timestamp: new Date().toISOString()
    }, 'Retrieved audit statistics');
    
    return stats;
  } catch (error) {
    logger.error({
      event: 'audit_stats_error',
      startDate,
      endDate,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 'Error retrieving audit statistics');
    
    throw error;
  }
}

export async function getUserActivitySummary(userId: string, days: number = 30): Promise<{
  user: User;
  recentActivity: AccessLog[];
  stats: {
    totalActions: number;
    loginCount: number;
    uploadCount: number;
    downloadCount: number;
    lastActivity: Date | null;
  };
}> {
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      throw new Error('User not found');
    }

    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const recentActivity = await storage.getAuditLogs({
      userId,
      startDate,
      limit: 50
    });

    const stats = {
      totalActions: recentActivity.length,
      loginCount: recentActivity.filter(log => log.action === 'login').length,
      uploadCount: recentActivity.filter(log => log.action === 'upload_pdf').length,
      downloadCount: recentActivity.filter(log => log.action === 'download_pdf').length,
      lastActivity: recentActivity.length > 0 ? recentActivity[0].timestamp : null
    };

    logger.info({
      event: 'user_activity_summary_retrieved',
      userId,
      days,
      stats,
      timestamp: new Date().toISOString()
    }, `Retrieved activity summary for user ${userId}`);

    return {
      user,
      recentActivity,
      stats
    };
  } catch (error) {
    logger.error({
      event: 'user_activity_summary_error',
      userId,
      days,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error retrieving activity summary for user ${userId}`);
    
    throw error;
  }
}

export async function logSecurityEvent(
  userId: string,
  action: string,
  details: Record<string, any>,
  ipAddress?: string,
  userAgent?: string
): Promise<void> {
  try {
    await storage.createAccessLog({
      userId,
      action,
      resourceType: 'security',
      resourceId: null,
      ipAddress: ipAddress || 'unknown',
      userAgent: userAgent || 'unknown',
      success: true,
      errorMessage: null,
      timestamp: new Date()
    });

    logger.warn({
      event: 'security_event_logged',
      userId,
      action,
      details,
      ipAddress,
      userAgent,
      timestamp: new Date().toISOString()
    }, `Security event logged: ${action} for user ${userId}`);
  } catch (error) {
    logger.error({
      event: 'security_event_log_error',
      userId,
      action,
      details,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error logging security event for user ${userId}`);
  }
}

export async function detectSuspiciousActivity(userId: string): Promise<{
  isSuspicious: boolean;
  reasons: string[];
  recommendations: string[];
}> {
  try {
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentActivity = await storage.getAuditLogs({
      userId,
      startDate: last24Hours,
      limit: 100
    });

    const reasons: string[] = [];
    const recommendations: string[] = [];

    // Check for multiple failed login attempts
    const failedLogins = recentActivity.filter(log => 
      log.action === 'login' && !log.success
    );
    
    if (failedLogins.length > 5) {
      reasons.push(`${failedLogins.length} failed login attempts in 24 hours`);
      recommendations.push('Consider enabling 2FA and reviewing password strength');
    }

    // Check for unusual IP addresses
    const ipAddresses = new Set(recentActivity.map(log => log.ipAddress));
    if (ipAddresses.size > 3) {
      reasons.push(`Access from ${ipAddresses.size} different IP addresses`);
      recommendations.push('Review recent login locations and revoke suspicious sessions');
    }

    // Check for bulk file operations
    const fileOperations = recentActivity.filter(log => 
      ['upload_pdf', 'download_pdf', 'delete_pdf'].includes(log.action)
    );
    
    if (fileOperations.length > 50) {
      reasons.push(`${fileOperations.length} file operations in 24 hours`);
      recommendations.push('Review file access patterns and verify legitimate usage');
    }

    const isSuspicious = reasons.length > 0;

    logger.info({
      event: 'suspicious_activity_check',
      userId,
      isSuspicious,
      reasons,
      recommendations,
      timestamp: new Date().toISOString()
    }, `Suspicious activity check for user ${userId}: ${isSuspicious ? 'detected' : 'clean'}`);

    return {
      isSuspicious,
      reasons,
      recommendations
    };
  } catch (error) {
    logger.error({
      event: 'suspicious_activity_check_error',
      userId,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, `Error checking suspicious activity for user ${userId}`);
    
    return {
      isSuspicious: false,
      reasons: [],
      recommendations: []
    };
  }
}