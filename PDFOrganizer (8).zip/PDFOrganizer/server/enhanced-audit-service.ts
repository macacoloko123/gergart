import { db } from './db';
import { accessLogs, users } from '@shared/schema';
import { eq, and, desc, gte, lte, count, sql } from 'drizzle-orm';
import { logger } from './logger';

/**
 * Enhanced audit service with comprehensive logging and monitoring
 * Based on feedback from Pessoa 4 - enterprise-level audit capabilities
 */

export interface SecurityEvent {
  userId: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  ipAddress: string;
  userAgent: string;
  success: boolean;
  errorMessage?: string;
  metadata?: Record<string, any>;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
}

export interface SuspiciousActivity {
  userId: string;
  type: 'multiple_failed_logins' | 'rapid_requests' | 'unusual_access_pattern' | 'permission_escalation' | 'suspicious_file_access';
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  metadata: Record<string, any>;
  timestamp: Date;
}

export interface AuditMetrics {
  totalEvents: number;
  successfulEvents: number;
  failedEvents: number;
  criticalEvents: number;
  topUsers: Array<{ userId: string; eventCount: number; userName: string }>;
  topActions: Array<{ action: string; count: number }>;
  suspiciousActivities: SuspiciousActivity[];
  hourlyActivity: Array<{ hour: number; count: number }>;
}

/**
 * Log a comprehensive security event with enhanced metadata
 */
export async function logSecurityEvent(event: SecurityEvent): Promise<void> {
  try {
    await db.insert(accessLogs).values({
      userId: event.userId,
      action: event.action,
      resourceType: event.resourceType,
      resourceId: event.resourceId,
      ipAddress: event.ipAddress,
      userAgent: event.userAgent,
      success: event.success,
      errorMessage: event.errorMessage,
      metadata: event.metadata,
      timestamp: event.timestamp
    });

    // Log to structured logs for external monitoring
    logger.info({
      event: 'security_event_logged',
      userId: event.userId,
      action: event.action,
      resourceType: event.resourceType,
      success: event.success,
      severity: event.severity,
      timestamp: event.timestamp,
      metadata: event.metadata
    }, `Security event: ${event.action} by user ${event.userId}`);

    // Alert on critical events
    if (event.severity === 'critical') {
      logger.error({
        event: 'critical_security_event',
        userId: event.userId,
        action: event.action,
        resourceType: event.resourceType,
        errorMessage: event.errorMessage,
        metadata: event.metadata
      }, `CRITICAL SECURITY EVENT: ${event.action} by user ${event.userId}`);
    }
  } catch (error) {
    logger.error('Failed to log security event:', error);
  }
}

/**
 * Detect suspicious activities based on user behavior patterns
 */
export async function detectSuspiciousActivities(userId: string, timeWindow: number = 30): Promise<SuspiciousActivity[]> {
  const suspiciousActivities: SuspiciousActivity[] = [];
  const cutoffTime = new Date(Date.now() - timeWindow * 60 * 1000);

  try {
    // 1. Multiple failed login attempts
    const failedLogins = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.userId, userId),
          eq(accessLogs.action, 'login'),
          eq(accessLogs.success, false),
          gte(accessLogs.timestamp, cutoffTime)
        )
      );

    if (failedLogins[0]?.count >= 5) {
      suspiciousActivities.push({
        userId,
        type: 'multiple_failed_logins',
        description: `${failedLogins[0].count} failed login attempts in ${timeWindow} minutes`,
        severity: 'high',
        metadata: { count: failedLogins[0].count, timeWindow },
        timestamp: new Date()
      });
    }

    // 2. Rapid requests (more than 100 requests in 5 minutes)
    const rapidRequests = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.userId, userId),
          gte(accessLogs.timestamp, new Date(Date.now() - 5 * 60 * 1000))
        )
      );

    if (rapidRequests[0]?.count >= 100) {
      suspiciousActivities.push({
        userId,
        type: 'rapid_requests',
        description: `${rapidRequests[0].count} requests in 5 minutes`,
        severity: 'medium',
        metadata: { count: rapidRequests[0].count },
        timestamp: new Date()
      });
    }

    // 3. Unusual access patterns (accessing multiple sectors in short time)
    const sectorAccess = await db
      .select({ 
        resourceId: accessLogs.resourceId,
        count: count()
      })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.userId, userId),
          eq(accessLogs.resourceType, 'pdf'),
          gte(accessLogs.timestamp, cutoffTime)
        )
      )
      .groupBy(accessLogs.resourceId);

    if (sectorAccess.length >= 10) {
      suspiciousActivities.push({
        userId,
        type: 'unusual_access_pattern',
        description: `Accessed ${sectorAccess.length} different resources in ${timeWindow} minutes`,
        severity: 'medium',
        metadata: { resourceCount: sectorAccess.length },
        timestamp: new Date()
      });
    }

    // Log suspicious activities
    for (const activity of suspiciousActivities) {
      await logSecurityEvent({
        userId,
        action: 'suspicious_activity_detected',
        resourceType: 'security',
        ipAddress: 'system',
        userAgent: 'system',
        success: false,
        errorMessage: activity.description,
        metadata: { suspiciousActivityType: activity.type, ...activity.metadata },
        severity: activity.severity,
        timestamp: activity.timestamp
      });
    }

    return suspiciousActivities;
  } catch (error) {
    logger.error('Error detecting suspicious activities:', error);
    return [];
  }
}

/**
 * Get comprehensive audit metrics for monitoring dashboard
 */
export async function getAuditMetrics(startDate: Date, endDate: Date): Promise<AuditMetrics> {
  try {
    // Total events
    const totalEvents = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      );

    // Successful events
    const successfulEvents = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.success, true),
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      );

    // Failed events
    const failedEvents = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.success, false),
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      );

    // Critical events (based on metadata or error patterns)
    const criticalEvents = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.success, false),
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      );

    // Top users by activity
    const topUsers = await db
      .select({
        userId: accessLogs.userId,
        eventCount: count(),
        userName: users.name
      })
      .from(accessLogs)
      .leftJoin(users, eq(accessLogs.userId, users.id))
      .where(
        and(
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      )
      .groupBy(accessLogs.userId, users.name)
      .orderBy(desc(count()))
      .limit(10);

    // Top actions
    const topActions = await db
      .select({
        action: accessLogs.action,
        count: count()
      })
      .from(accessLogs)
      .where(
        and(
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      )
      .groupBy(accessLogs.action)
      .orderBy(desc(count()))
      .limit(10);

    // Hourly activity pattern
    const hourlyActivity = await db
      .select({
        hour: sql<number>`EXTRACT(HOUR FROM ${accessLogs.timestamp})`,
        count: count()
      })
      .from(accessLogs)
      .where(
        and(
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      )
      .groupBy(sql`EXTRACT(HOUR FROM ${accessLogs.timestamp})`)
      .orderBy(sql`EXTRACT(HOUR FROM ${accessLogs.timestamp})`);

    return {
      totalEvents: totalEvents[0]?.count || 0,
      successfulEvents: successfulEvents[0]?.count || 0,
      failedEvents: failedEvents[0]?.count || 0,
      criticalEvents: criticalEvents[0]?.count || 0,
      topUsers: topUsers.map(u => ({
        userId: u.userId,
        eventCount: u.eventCount,
        userName: u.userName || 'Unknown'
      })),
      topActions: topActions.map(a => ({
        action: a.action,
        count: a.count
      })),
      suspiciousActivities: [], // Would be populated by a separate call
      hourlyActivity: hourlyActivity.map(h => ({
        hour: h.hour,
        count: h.count
      }))
    };
  } catch (error) {
    logger.error('Error getting audit metrics:', error);
    throw error;
  }
}

/**
 * Generate audit report for compliance
 */
export async function generateAuditReport(startDate: Date, endDate: Date): Promise<{
  summary: AuditMetrics;
  criticalEvents: any[];
  userSummaries: any[];
}> {
  try {
    const summary = await getAuditMetrics(startDate, endDate);
    
    // Critical events details
    const criticalEvents = await db
      .select()
      .from(accessLogs)
      .where(
        and(
          eq(accessLogs.success, false),
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      )
      .orderBy(desc(accessLogs.timestamp));

    // User activity summaries
    const userSummaries = await db
      .select({
        userId: accessLogs.userId,
        userName: users.name,
        totalActions: count(),
        lastActivity: sql<Date>`MAX(${accessLogs.timestamp})`
      })
      .from(accessLogs)
      .leftJoin(users, eq(accessLogs.userId, users.id))
      .where(
        and(
          gte(accessLogs.timestamp, startDate),
          lte(accessLogs.timestamp, endDate)
        )
      )
      .groupBy(accessLogs.userId, users.name)
      .orderBy(desc(count()));

    return {
      summary,
      criticalEvents,
      userSummaries
    };
  } catch (error) {
    logger.error('Error generating audit report:', error);
    throw error;
  }
}

/**
 * Monitor system health and alert on anomalies
 */
export async function monitorSystemHealth(): Promise<{
  healthy: boolean;
  alerts: string[];
  metrics: Record<string, any>;
}> {
  const alerts: string[] = [];
  const metrics: Record<string, any> = {};

  try {
    // Check for high failure rates in last hour
    const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recentActivity = await db
      .select({
        total: count(),
        failures: sql<number>`COUNT(CASE WHEN ${accessLogs.success} = false THEN 1 END)`
      })
      .from(accessLogs)
      .where(gte(accessLogs.timestamp, hourAgo));

    const activity = recentActivity[0];
    if (activity) {
      const failureRate = activity.total > 0 ? (activity.failures / activity.total) * 100 : 0;
      metrics.failureRate = failureRate;
      metrics.totalRequests = activity.total;
      metrics.failures = activity.failures;

      if (failureRate > 20) {
        alerts.push(`High failure rate detected: ${failureRate.toFixed(1)}%`);
      }
    }

    // Check for unusual activity spikes
    const avgHourlyActivity = await db
      .select({
        avgCount: sql<number>`AVG(hourly_count)`
      })
      .from(
        db
          .select({
            hourlyCount: count()
          })
          .from(accessLogs)
          .where(gte(accessLogs.timestamp, new Date(Date.now() - 24 * 60 * 60 * 1000)))
          .groupBy(sql`EXTRACT(HOUR FROM ${accessLogs.timestamp})`)
          .as('hourly_count')
      );

    const currentHourActivity = await db
      .select({ count: count() })
      .from(accessLogs)
      .where(gte(accessLogs.timestamp, new Date(Date.now() - 60 * 60 * 1000)));

    const currentCount = currentHourActivity[0]?.count || 0;
    const avgCount = avgHourlyActivity[0]?.avgCount || 0;

    if (currentCount > avgCount * 3) {
      alerts.push(`Unusual activity spike: ${currentCount} requests vs ${avgCount.toFixed(0)} average`);
    }

    return {
      healthy: alerts.length === 0,
      alerts,
      metrics
    };
  } catch (error) {
    logger.error('Error monitoring system health:', error);
    return {
      healthy: false,
      alerts: ['System health check failed'],
      metrics: {}
    };
  }
}