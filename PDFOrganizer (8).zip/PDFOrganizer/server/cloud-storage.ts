import { google } from 'googleapis';
import { Dropbox } from 'dropbox';
import fs from 'fs';
import path from 'path';
import { logger } from './logger';

// Cloud storage interface
export interface CloudStorageProvider {
  uploadFile(filePath: string, fileName: string, userId: string): Promise<string>;
  downloadFile(fileId: string, userId: string): Promise<Buffer>;
  deleteFile(fileId: string, userId: string): Promise<boolean>;
  listFiles(userId: string): Promise<CloudFile[]>;
  getShareLink(fileId: string, userId: string): Promise<string>;
}

export interface CloudFile {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  createdAt: Date;
  modifiedAt: Date;
  webViewLink?: string;
}

// Google Drive implementation
export class GoogleDriveProvider implements CloudStorageProvider {
  private drive: any;
  private oauth2Client: any;

  constructor() {
    this.oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URL
    );
    
    this.drive = google.drive({ version: 'v3', auth: this.oauth2Client });
  }

  setUserCredentials(accessToken: string, refreshToken: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken
    });
  }

  async uploadFile(filePath: string, fileName: string, userId: string): Promise<string> {
    try {
      const fileMetadata = {
        name: fileName,
        parents: [await this.getOrCreateFolder(userId)]
      };

      const media = {
        mimeType: 'application/pdf',
        body: fs.createReadStream(filePath)
      };

      const response = await this.drive.files.create({
        resource: fileMetadata,
        media: media,
        fields: 'id'
      });

      logger.info({
        event: 'cloud_upload',
        provider: 'google_drive',
        fileId: response.data.id,
        fileName,
        userId
      }, `File uploaded to Google Drive: ${fileName}`);

      return response.data.id;
    } catch (error) {
      logger.error({
        event: 'cloud_upload_error',
        provider: 'google_drive',
        error: error instanceof Error ? error.message : 'Unknown error',
        userId
      }, `Failed to upload to Google Drive: ${fileName}`);
      throw error;
    }
  }

  async downloadFile(fileId: string, userId: string): Promise<Buffer> {
    try {
      const response = await this.drive.files.get({
        fileId,
        alt: 'media'
      });

      return Buffer.from(response.data);
    } catch (error) {
      logger.error({
        event: 'cloud_download_error',
        provider: 'google_drive',
        fileId,
        userId
      }, 'Failed to download from Google Drive');
      throw error;
    }
  }

  async deleteFile(fileId: string, userId: string): Promise<boolean> {
    try {
      await this.drive.files.delete({ fileId });
      
      logger.info({
        event: 'cloud_delete',
        provider: 'google_drive',
        fileId,
        userId
      }, 'File deleted from Google Drive');
      
      return true;
    } catch (error) {
      logger.error({
        event: 'cloud_delete_error',
        provider: 'google_drive',
        fileId,
        userId
      }, 'Failed to delete from Google Drive');
      return false;
    }
  }

  async listFiles(userId: string): Promise<CloudFile[]> {
    try {
      const folderId = await this.getOrCreateFolder(userId);
      const response = await this.drive.files.list({
        q: `'${folderId}' in parents and mimeType='application/pdf'`,
        fields: 'files(id, name, size, mimeType, createdTime, modifiedTime, webViewLink)',
        orderBy: 'modifiedTime desc'
      });

      return response.data.files.map((file: any) => ({
        id: file.id,
        name: file.name,
        size: parseInt(file.size) || 0,
        mimeType: file.mimeType,
        createdAt: new Date(file.createdTime),
        modifiedAt: new Date(file.modifiedTime),
        webViewLink: file.webViewLink
      }));
    } catch (error) {
      logger.error({
        event: 'cloud_list_error',
        provider: 'google_drive',
        userId
      }, 'Failed to list files from Google Drive');
      throw error;
    }
  }

  async getShareLink(fileId: string, userId: string): Promise<string> {
    try {
      // Make file publicly viewable
      await this.drive.permissions.create({
        fileId,
        resource: {
          role: 'reader',
          type: 'anyone'
        }
      });

      const response = await this.drive.files.get({
        fileId,
        fields: 'webViewLink'
      });

      return response.data.webViewLink;
    } catch (error) {
      logger.error({
        event: 'cloud_share_error',
        provider: 'google_drive',
        fileId,
        userId
      }, 'Failed to get share link from Google Drive');
      throw error;
    }
  }

  private async getOrCreateFolder(userId: string): Promise<string> {
    const folderName = `PDFOrganizer_${userId}`;
    
    // Check if folder exists
    const searchResponse = await this.drive.files.list({
      q: `name='${folderName}' and mimeType='application/vnd.google-apps.folder'`,
      fields: 'files(id, name)'
    });

    if (searchResponse.data.files.length > 0) {
      return searchResponse.data.files[0].id;
    }

    // Create folder
    const folderMetadata = {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder'
    };

    const response = await this.drive.files.create({
      resource: folderMetadata,
      fields: 'id'
    });

    return response.data.id;
  }
}

// Dropbox implementation
export class DropboxProvider implements CloudStorageProvider {
  private dbx: Dropbox;

  constructor() {
    this.dbx = new Dropbox({
      clientId: process.env.DROPBOX_CLIENT_ID,
      clientSecret: process.env.DROPBOX_CLIENT_SECRET
    });
  }

  setUserCredentials(accessToken: string) {
    this.dbx.setAccessToken(accessToken);
  }

  async uploadFile(filePath: string, fileName: string, userId: string): Promise<string> {
    try {
      const fileBuffer = fs.readFileSync(filePath);
      const folderPath = `/PDFOrganizer_${userId}`;
      const fullPath = `${folderPath}/${fileName}`;

      // Create folder if it doesn't exist
      try {
        await this.dbx.filesCreateFolderV2({ path: folderPath });
      } catch (error) {
        // Folder might already exist, ignore error
      }

      const response = await this.dbx.filesUpload({
        path: fullPath,
        contents: fileBuffer,
        mode: 'overwrite',
        autorename: true
      });

      logger.info({
        event: 'cloud_upload',
        provider: 'dropbox',
        fileId: response.result.id,
        fileName,
        userId
      }, `File uploaded to Dropbox: ${fileName}`);

      return response.result.id;
    } catch (error) {
      logger.error({
        event: 'cloud_upload_error',
        provider: 'dropbox',
        error: error instanceof Error ? error.message : 'Unknown error',
        userId
      }, `Failed to upload to Dropbox: ${fileName}`);
      throw error;
    }
  }

  async downloadFile(fileId: string, userId: string): Promise<Buffer> {
    try {
      const response = await this.dbx.filesDownload({ path: fileId });
      return (response.result as any).fileBinary;
    } catch (error) {
      logger.error({
        event: 'cloud_download_error',
        provider: 'dropbox',
        fileId,
        userId
      }, 'Failed to download from Dropbox');
      throw error;
    }
  }

  async deleteFile(fileId: string, userId: string): Promise<boolean> {
    try {
      await this.dbx.filesDeleteV2({ path: fileId });
      
      logger.info({
        event: 'cloud_delete',
        provider: 'dropbox',
        fileId,
        userId
      }, 'File deleted from Dropbox');
      
      return true;
    } catch (error) {
      logger.error({
        event: 'cloud_delete_error',
        provider: 'dropbox',
        fileId,
        userId
      }, 'Failed to delete from Dropbox');
      return false;
    }
  }

  async listFiles(userId: string): Promise<CloudFile[]> {
    try {
      const folderPath = `/PDFOrganizer_${userId}`;
      const response = await this.dbx.filesListFolder({ path: folderPath });

      return response.result.entries
        .filter((entry: any) => entry['.tag'] === 'file' && entry.name.endsWith('.pdf'))
        .map((file: any) => ({
          id: file.id,
          name: file.name,
          size: file.size,
          mimeType: 'application/pdf',
          createdAt: new Date(file.client_modified),
          modifiedAt: new Date(file.server_modified)
        }));
    } catch (error) {
      logger.error({
        event: 'cloud_list_error',
        provider: 'dropbox',
        userId
      }, 'Failed to list files from Dropbox');
      throw error;
    }
  }

  async getShareLink(fileId: string, userId: string): Promise<string> {
    try {
      const response = await this.dbx.sharingCreateSharedLinkWithSettings({
        path: fileId,
        settings: {
          requested_visibility: 'public'
        }
      });

      return response.result.url;
    } catch (error) {
      logger.error({
        event: 'cloud_share_error',
        provider: 'dropbox',
        fileId,
        userId
      }, 'Failed to get share link from Dropbox');
      throw error;
    }
  }
}

// Cloud storage manager
export class CloudStorageManager {
  private providers: Map<string, CloudStorageProvider> = new Map();

  constructor() {
    this.providers.set('google_drive', new GoogleDriveProvider());
    this.providers.set('dropbox', new DropboxProvider());
  }

  getProvider(providerName: string): CloudStorageProvider | undefined {
    return this.providers.get(providerName);
  }

  async syncFileToCloud(
    filePath: string,
    fileName: string,
    userId: string,
    providerName: string,
    credentials: any
  ): Promise<string> {
    const provider = this.getProvider(providerName);
    if (!provider) {
      throw new Error(`Provider ${providerName} not found`);
    }

    // Set user credentials
    if (providerName === 'google_drive') {
      (provider as GoogleDriveProvider).setUserCredentials(
        credentials.accessToken,
        credentials.refreshToken
      );
    } else if (providerName === 'dropbox') {
      (provider as DropboxProvider).setUserCredentials(credentials.accessToken);
    }

    return await provider.uploadFile(filePath, fileName, userId);
  }

  async downloadFromCloud(
    fileId: string,
    userId: string,
    providerName: string,
    credentials: any
  ): Promise<Buffer> {
    const provider = this.getProvider(providerName);
    if (!provider) {
      throw new Error(`Provider ${providerName} not found`);
    }

    // Set user credentials
    if (providerName === 'google_drive') {
      (provider as GoogleDriveProvider).setUserCredentials(
        credentials.accessToken,
        credentials.refreshToken
      );
    } else if (providerName === 'dropbox') {
      (provider as DropboxProvider).setUserCredentials(credentials.accessToken);
    }

    return await provider.downloadFile(fileId, userId);
  }
}

export const cloudStorageManager = new CloudStorageManager();