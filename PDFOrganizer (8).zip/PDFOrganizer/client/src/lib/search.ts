import Fuse from 'fuse.js';
import type { Pdf } from '@shared/schema';

export class PdfSearchEngine {
  private fuse: Fuse<Pdf>;

  constructor(pdfs: Pdf[]) {
    this.fuse = new Fuse(pdfs, {
      keys: [
        { name: 'name', weight: 0.5 },
        { name: 'originalName', weight: 0.3 },
        { name: 'filePath', weight: 0.2 },
      ],
      threshold: 0.3, // More flexible matching
      includeScore: true,
      minMatchCharLength: 2,
    });
  }

  search(query: string): Pdf[] {
    if (!query.trim()) return [];
    
    const results = this.fuse.search(query);
    return results.map(result => result.item);
  }

  updateData(pdfs: Pdf[]) {
    this.fuse = new Fuse(pdfs, {
      keys: [
        { name: 'name', weight: 0.5 },
        { name: 'originalName', weight: 0.3 },
        { name: 'filePath', weight: 0.2 },
      ],
      threshold: 0.3,
      includeScore: true,
      minMatchCharLength: 2,
    });
  }
}