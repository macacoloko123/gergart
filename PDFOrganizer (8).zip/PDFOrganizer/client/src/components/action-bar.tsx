import { useState } from "react";
import { Grid3X3, List, CornerLeftUp, RotateCw, Split } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

interface ActionBarProps {
  viewMode: "grid" | "list";
  onViewModeChange: (mode: "grid" | "list") => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
}

export function ActionBar({ viewMode, onViewModeChange, sortBy, onSortChange }: ActionBarProps) {
  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Select value={sortBy} onValueChange={onSortChange}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Ordenar por Nome</SelectItem>
                <SelectItem value="date">Ordenar por Data</SelectItem>
                <SelectItem value="size">Ordenar por Tamanho</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="sm"
                onClick={() => onViewModeChange("grid")}
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="sm"
                onClick={() => onViewModeChange("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <CornerLeftUp className="h-4 w-4 mr-2" />
              Juntar
            </Button>
            <Button variant="outline" size="sm">
              <Split className="h-4 w-4 mr-2" />
              Dividir
            </Button>
            <Button variant="outline" size="sm">
              <RotateCw className="h-4 w-4 mr-2" />
              Rotacionar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
