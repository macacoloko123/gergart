import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Plus, 
  FileText, 
  Upload,
  Users,
  Building,
  Download,
  Eye,
  Edit,
  Trash2,
  Star,
  Clock
} from "lucide-react";

interface Employee {
  id: string;
  name: string;
  email: string;
  setor: string;
  userType: string;
  canAddFiles: boolean;
  canEditFiles: boolean;
  canDeleteFiles: boolean;
  canViewAllSectorFiles: boolean;
}

interface FileItem {
  id: number;
  name: string;
  setor: string;
  uploadedBy: string;
  uploadedAt: Date;
  fileSize: number;
  isFavorite: boolean;
  isDeleted: boolean;
}

export default function EmployeeDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  // Buscar informações do funcionário
  const { data: currentUser } = useQuery<Employee>({
    queryKey: ["/api/auth/me"],
  });

  // Buscar arquivos do setor
  const { data: files } = useQuery<FileItem[]>({
    queryKey: ["/api/pdfs", activeCategory],
    enabled: !!currentUser,
  });

  const filteredFiles = files?.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    !file.isDeleted
  );

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getUserTypeColor = (userType: string) => {
    switch (userType) {
      case "admin": return "bg-red-100 text-red-800";
      case "supervisor": return "bg-green-100 text-green-800";
      case "employee": return "bg-blue-100 text-blue-800";
      case "external": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const categories = [
    { id: "all", label: "Todos", icon: FileText },
    { id: "recent", label: "Recentes", icon: Clock },
    { id: "favorites", label: "Favoritos", icon: Star },
    { id: "deleted", label: "Lixeira", icon: Trash2 },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Painel do Funcionário</h1>
          <p className="text-gray-600">
            Setor: {currentUser?.setor} • Gerenciar arquivos PDF
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className={getUserTypeColor(currentUser?.userType || "employee")}>
            <Users className="w-4 h-4 mr-1" />
            {currentUser?.userType || "employee"}
          </Badge>
          {currentUser?.canAddFiles && (
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar PDF
            </Button>
          )}
        </div>
      </div>

      {/* Barra de Busca */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar arquivos..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Meus Arquivos</p>
                <p className="text-2xl font-bold">{filteredFiles?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Favoritos</p>
                <p className="text-2xl font-bold">
                  {filteredFiles?.filter(f => f.isFavorite).length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Building className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Setor</p>
                <p className="text-2xl font-bold capitalize">{currentUser?.setor}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Upload className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Permissões</p>
                <p className="text-xl font-bold">
                  {currentUser?.canAddFiles ? "Completas" : "Limitadas"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Categorias */}
      <div className="flex space-x-2">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(category.id)}
            >
              <Icon className="w-4 h-4 mr-2" />
              {category.label}
            </Button>
          );
        })}
      </div>

      {/* Lista de Arquivos */}
      <Card>
        <CardHeader>
          <CardTitle>Arquivos do Setor</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredFiles?.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum arquivo encontrado
                </h3>
                <p className="text-gray-500">
                  {currentUser?.canAddFiles 
                    ? "Adicione seu primeiro arquivo PDF clicando no botão 'Adicionar PDF'"
                    : "Não há arquivos disponíveis no momento"
                  }
                </p>
              </div>
            ) : (
              filteredFiles?.map((file) => (
                <div key={file.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{file.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Por: {file.uploadedBy}</span>
                          <span>{formatDate(file.uploadedAt)}</span>
                          <span>{formatFileSize(file.fileSize)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {file.isFavorite && (
                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                          <Star className="w-3 h-3 mr-1" />
                          Favorito
                        </Badge>
                      )}
                      
                      <div className="flex space-x-1">
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          Ver
                        </Button>
                        <Button size="sm" variant="outline">
                          <Download className="w-4 h-4 mr-1" />
                          Baixar
                        </Button>
                        {currentUser?.canEditFiles && (
                          <Button size="sm" variant="outline">
                            <Edit className="w-4 h-4 mr-1" />
                            Editar
                          </Button>
                        )}
                        {currentUser?.canDeleteFiles && (
                          <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4 mr-1" />
                            Excluir
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Informações de Permissão */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium text-blue-800">Suas Permissões</p>
              <div className="flex items-center space-x-4 text-sm text-blue-600 mt-1">
                <span>Adicionar: {currentUser?.canAddFiles ? "✓" : "✗"}</span>
                <span>Editar: {currentUser?.canEditFiles ? "✓" : "✗"}</span>
                <span>Excluir: {currentUser?.canDeleteFiles ? "✓" : "✗"}</span>
                <span>Ver Todos: {currentUser?.canViewAllSectorFiles ? "✓" : "✗"}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}