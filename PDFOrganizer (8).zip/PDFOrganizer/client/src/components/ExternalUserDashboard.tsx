import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  FileText, 
  Download,
  Eye,
  Clock,
  Lock,
  ExternalLink
} from "lucide-react";

interface ExternalUser {
  id: string;
  name: string;
  email: string;
  setor: string;
  userType: "external";
}

interface AccessibleFile {
  id: number;
  name: string;
  setor: string;
  fileSize: number;
  uploadedBy: string;
  uploadedAt: Date;
  canView: boolean;
  canDownload: boolean;
  expiresAt?: Date;
  grantedBy: string;
}

export default function ExternalUserDashboard() {
  const [searchQuery, setSearchQuery] = useState("");

  // Buscar informações do usuário externo
  const { data: currentUser } = useQuery<ExternalUser>({
    queryKey: ["/api/auth/me"],
  });

  // Buscar arquivos acessíveis para o usuário externo
  const { data: accessibleFiles } = useQuery<AccessibleFile[]>({
    queryKey: ["/api/external/files"],
    enabled: !!currentUser,
  });

  const filteredFiles = accessibleFiles?.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isExpired = (expiresAt?: Date) => {
    if (!expiresAt) return false;
    return new Date() > new Date(expiresAt);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Painel do Usuário Externo</h1>
          <p className="text-gray-600">
            Arquivos disponibilizados especificamente para você
          </p>
        </div>
        <Badge variant="outline" className="bg-orange-50 text-orange-700">
          <ExternalLink className="w-4 h-4 mr-1" />
          Usuário Externo
        </Badge>
      </div>

      {/* Barra de Busca */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar arquivos disponíveis..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Arquivos Disponíveis</p>
                <p className="text-2xl font-bold">{filteredFiles?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Download className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Downloads Permitidos</p>
                <p className="text-2xl font-bold">
                  {filteredFiles?.filter(f => f.canDownload).length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Com Expiração</p>
                <p className="text-2xl font-bold">
                  {filteredFiles?.filter(f => f.expiresAt).length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Arquivos */}
      <Card>
        <CardHeader>
          <CardTitle>Arquivos Disponíveis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredFiles?.length === 0 ? (
              <div className="text-center py-12">
                <Lock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum arquivo disponível
                </h3>
                <p className="text-gray-500">
                  Não há arquivos compartilhados com você no momento.
                </p>
              </div>
            ) : (
              filteredFiles?.map((file) => (
                <div key={file.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{file.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Setor: {file.setor}</span>
                          <span>Por: {file.uploadedBy}</span>
                          <span>{formatDate(file.uploadedAt)}</span>
                          <span>{formatFileSize(file.fileSize)}</span>
                        </div>
                        {file.expiresAt && (
                          <div className="flex items-center space-x-1 text-sm mt-1">
                            <Clock className="w-3 h-3" />
                            <span className={isExpired(file.expiresAt) ? "text-red-500" : "text-yellow-600"}>
                              {isExpired(file.expiresAt) ? "Expirado em" : "Expira em"}: {formatDate(file.expiresAt)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex space-x-1">
                        {file.canView && (
                          <Badge variant="secondary" className="text-xs">
                            <Eye className="w-3 h-3 mr-1" />
                            Visualizar
                          </Badge>
                        )}
                        {file.canDownload && (
                          <Badge variant="secondary" className="text-xs">
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Badge>
                        )}
                      </div>
                      <div className="flex space-x-1">
                        {file.canView && !isExpired(file.expiresAt) && (
                          <Button size="sm" variant="outline">
                            <Eye className="w-4 h-4 mr-1" />
                            Ver
                          </Button>
                        )}
                        {file.canDownload && !isExpired(file.expiresAt) && (
                          <Button size="sm" variant="outline">
                            <Download className="w-4 h-4 mr-1" />
                            Baixar
                          </Button>
                        )}
                        {isExpired(file.expiresAt) && (
                          <Button size="sm" variant="outline" disabled>
                            <Lock className="w-4 h-4 mr-1" />
                            Expirado
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t text-xs text-gray-500">
                    <p>
                      Acesso concedido por: <span className="font-medium">{file.grantedBy}</span>
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Aviso de Limitações */}
      <Card className="bg-orange-50 border-orange-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Lock className="w-5 h-5 text-orange-600" />
            <div>
              <p className="text-sm font-medium text-orange-800">Acesso Limitado</p>
              <p className="text-sm text-orange-600">
                Você tem acesso apenas aos arquivos específicos compartilhados com você. 
                Não é possível visualizar outros arquivos ou realizar uploads.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}