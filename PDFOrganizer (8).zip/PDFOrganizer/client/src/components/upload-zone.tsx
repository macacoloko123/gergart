import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CloudUpload, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface UploadZoneProps {
  folderId?: number;
  onUploadComplete?: () => void;
}

export function UploadZone({ folderId, onUploadComplete }: UploadZoneProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      if (folderId) {
        formData.append("folderId", folderId.toString());
      }

      const response = await fetch("/api/pdfs/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs/recent"] });
      setUploadProgress(0);
      onUploadComplete?.();
      toast({
        title: "Upload concluído",
        description: "O PDF foi enviado com sucesso.",
      });
    },
    onError: () => {
      setUploadProgress(0);
      toast({
        title: "Erro no upload",
        description: "Não foi possível enviar o PDF.",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach((file) => {
      if (file.type === "application/pdf") {
        uploadMutation.mutate(file);
      } else {
        toast({
          title: "Arquivo inválido",
          description: "Apenas arquivos PDF são permitidos.",
          variant: "destructive",
        });
      }
    });
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
    },
    maxSize: 50 * 1024 * 1024, // 50MB
  });

  return (
    <Card className={`border-2 border-dashed transition-colors cursor-pointer mb-6 ${
      isDragActive ? "border-primary bg-primary/5" : "border-gray-300 hover:border-primary"
    }`}>
      <CardContent className="p-8 text-center" {...getRootProps()}>
        <input {...getInputProps()} />
        
        <CloudUpload className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        
        <h3 className="text-lg font-semibold text-gray-700 mb-2">
          {isDragActive ? "Solte os arquivos aqui" : "Arraste e solte seus PDFs aqui"}
        </h3>
        
        <p className="text-gray-500 mb-4">ou clique para selecionar arquivos</p>
        
        <Button className="bg-primary hover:bg-blue-700">
          <Upload className="h-4 w-4 mr-2" />
          Selecionar Arquivos
        </Button>
        
        <p className="text-sm text-gray-400 mt-2">Máximo 50MB por arquivo</p>
        
        {uploadMutation.isPending && (
          <div className="mt-4">
            <Progress value={uploadProgress} className="w-full" />
            <p className="text-sm text-gray-500 mt-2">Enviando...</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
