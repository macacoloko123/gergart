import { useState, useEffect } from "react";
import { TwoFactorAuth } from "../two-factor-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Shield, 
  Key, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  XCircle
} from "lucide-react";

interface SecuritySettings {
  twoFactorEnabled: boolean;
  lastPasswordChange?: string;
  activeSessions: number;
  lastLogin?: string;
  lastLoginIp?: string;
}

export function SecuritySettings() {
  const [settings, setSettings] = useState<SecuritySettings>({
    twoFactorEnabled: false,
    activeSessions: 0
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadSecuritySettings = async () => {
    try {
      const response = await fetch("/api/user/security", {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSettings(data);
      }
    } catch (error) {
      console.error("Error loading security settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const revokeAllSessions = async () => {
    try {
      const response = await fetch("/api/auth/revoke-all-sessions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`
        }
      });

      if (response.ok) {
        toast({
          title: "Sucesso",
          description: "Todas as sessões foram revogadas. Você será redirecionado para o login.",
        });
        
        // Redirect to login after 2 seconds
        setTimeout(() => {
          localStorage.removeItem("auth-token");
          window.location.href = "/login";
        }, 2000);
      } else {
        toast({
          title: "Erro",
          description: "Falha ao revogar sessões",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro de conexão",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    loadSecuritySettings();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Carregando configurações de segurança...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Configurações de Segurança</h1>
        <Button onClick={loadSecuritySettings} variant="outline">
          Atualizar
        </Button>
      </div>

      {/* Security Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Status de Segurança
          </CardTitle>
          <CardDescription>
            Visão geral do estado de segurança da sua conta
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                <span className="font-medium">Autenticação 2FA</span>
              </div>
              <Badge variant={settings.twoFactorEnabled ? "default" : "destructive"}>
                {settings.twoFactorEnabled ? (
                  <CheckCircle className="h-3 w-3 mr-1" />
                ) : (
                  <XCircle className="h-3 w-3 mr-1" />
                )}
                {settings.twoFactorEnabled ? "Ativada" : "Desativada"}
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                <span className="font-medium">Sessões Ativas</span>
              </div>
              <Badge variant="outline">
                {settings.activeSessions} sessões
              </Badge>
            </div>

            {settings.lastLogin && (
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-medium">Último Login</span>
                </div>
                <div className="text-sm text-right">
                  <div>{new Date(settings.lastLogin).toLocaleString("pt-BR")}</div>
                  {settings.lastLoginIp && (
                    <div className="text-gray-500 font-mono">{settings.lastLoginIp}</div>
                  )}
                </div>
              </div>
            )}
          </div>

          {!settings.twoFactorEnabled && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Sua conta não está protegida com autenticação de dois fatores. 
                Recomendamos ativá-la para maior segurança.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Two-Factor Authentication */}
      <TwoFactorAuth 
        isEnabled={settings.twoFactorEnabled}
        onStatusChange={(enabled) => setSettings({...settings, twoFactorEnabled: enabled})}
      />

      {/* Session Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Gerenciamento de Sessões
          </CardTitle>
          <CardDescription>
            Controle suas sessões ativas em diferentes dispositivos
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium">Sessões Ativas</h4>
              <p className="text-sm text-gray-600">
                Você tem {settings.activeSessions} sessões ativas no momento
              </p>
            </div>
            <Button 
              variant="destructive" 
              onClick={revokeAllSessions}
              disabled={settings.activeSessions === 0}
            >
              Revogar Todas
            </Button>
          </div>

          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Ao revogar todas as sessões, você será desconectado de todos os dispositivos 
              e precisará fazer login novamente.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Password Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Segurança da Senha
          </CardTitle>
          <CardDescription>
            Gerencie a segurança da sua senha
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium">Alterar Senha</h4>
              <p className="text-sm text-gray-600">
                {settings.lastPasswordChange 
                  ? `Última alteração: ${new Date(settings.lastPasswordChange).toLocaleDateString("pt-BR")}`
                  : "Recomendamos alterar sua senha periodicamente"
                }
              </p>
            </div>
            <Button 
              variant="outline"
              onClick={() => window.location.href = "/change-password"}
            >
              Alterar Senha
            </Button>
          </div>

          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Use uma senha forte com pelo menos 8 caracteres, incluindo letras, números e símbolos.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}