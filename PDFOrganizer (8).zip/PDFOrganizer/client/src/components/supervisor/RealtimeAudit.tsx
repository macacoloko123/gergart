import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Search, 
  Eye,
  Clock,
  Activity,
  FileText,
  Upload,
  Download,
  Trash2,
  Edit,
  Play,
  Pause,
  RefreshCw,
  Filter,
  User,
  Calendar
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AuditLog {
  id: string;
  action: string;
  user: string;
  sector: string;
  timestamp: Date;
  file?: string;
  details?: string;
  success?: boolean;
}

interface SearchResult {
  id: number;
  name: string;
  setor: string;
  uploadedBy: string;
  uploadedAt: Date;
  fileSize: number;
}

export default function RealtimeAudit() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isRealtime, setIsRealtime] = useState(true);
  const [filterAction, setFilterAction] = useState<string>("");
  const [filterSector, setFilterSector] = useState<string>("");
  const { toast } = useToast();

  // Buscar logs de auditoria
  const { data: auditLogs, isLoading: logsLoading, refetch: refetchLogs } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit/logs", { limit: 50 }],
    refetchInterval: isRealtime ? 5000 : false, // Atualizar a cada 5 segundos se em tempo real
  });

  // Buscar PDFs por nome
  const { data: searchResults, isLoading: searchLoading } = useQuery<SearchResult[]>({
    queryKey: ["/api/search/cloud", { query: searchQuery }],
    enabled: searchQuery.length > 2,
  });

  // Estatísticas rápidas
  const { data: stats } = useQuery<{
    totalLogs: number;
    recentActivity: number;
    activeUsers: number;
    uploadsToday: number;
  }>({
    queryKey: ["/api/audit/stats"],
    refetchInterval: 30000, // Atualizar a cada 30 segundos
  });

  const getActionIcon = (action: string) => {
    switch (action.toLowerCase()) {
      case "upload_pdf":
      case "upload": return <Upload className="w-4 h-4 text-green-600" />;
      case "download_pdf":
      case "download": return <Download className="w-4 h-4 text-blue-600" />;
      case "delete_pdf":
      case "delete": return <Trash2 className="w-4 h-4 text-red-600" />;
      case "edit_pdf":
      case "edit": return <Edit className="w-4 h-4 text-orange-600" />;
      case "login": return <User className="w-4 h-4 text-purple-600" />;
      default: return <Activity className="w-4 h-4 text-gray-600" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action.toLowerCase()) {
      case "upload_pdf":
      case "upload": return "bg-green-100 text-green-800";
      case "download_pdf":
      case "download": return "bg-blue-100 text-blue-800";
      case "delete_pdf":
      case "delete": return "bg-red-100 text-red-800";
      case "edit_pdf":
      case "edit": return "bg-orange-100 text-orange-800";
      case "login": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatFileSize = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const filteredLogs = auditLogs?.filter(log => {
    const matchesAction = !filterAction || log.action.includes(filterAction);
    const matchesSector = !filterSector || log.sector.includes(filterSector);
    return matchesAction && matchesSector;
  });

  const sectors = ["ti", "rh", "financeiro", "comercial", "marketing", "operacional", "juridico", "diretoria"];
  const actions = ["upload", "download", "delete", "edit", "login"];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Monitoramento em Tempo Real</h1>
          <p className="text-gray-600">
            Acompanhe todas as atividades do sistema em tempo real - apenas visualização
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-green-50 text-green-700">
            <Eye className="w-4 h-4 mr-1" />
            Supervisor
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsRealtime(!isRealtime)}
            className={isRealtime ? "bg-green-50 text-green-700" : ""}
          >
            {isRealtime ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
            {isRealtime ? "Pausar" : "Iniciar"} Tempo Real
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetchLogs()}
          >
            <RefreshCw className="w-4 h-4 mr-1" />
            Atualizar
          </Button>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total de Logs</p>
                <p className="text-2xl font-bold">{stats?.totalLogs || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Atividade Recente</p>
                <p className="text-2xl font-bold">{stats?.recentActivity || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <User className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Usuários Ativos</p>
                <p className="text-2xl font-bold">{stats?.activeUsers || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Upload className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Uploads Hoje</p>
                <p className="text-2xl font-bold">{stats?.uploadsToday || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Busca de PDFs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="w-5 h-5" />
            <span>Buscar PDFs</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Digite o nome do PDF para buscar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {searchLoading && (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
              <p className="text-gray-600 mt-2">Buscando...</p>
            </div>
          )}

          {searchResults && searchResults.length > 0 && (
            <div className="space-y-2">
              {searchResults.map((pdf) => (
                <div key={pdf.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-medium">{pdf.name}</p>
                      <p className="text-sm text-gray-600">
                        {pdf.setor} • {pdf.uploadedBy} • {formatFileSize(pdf.fileSize)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="capitalize">
                      {pdf.setor}
                    </Badge>
                    <Button size="sm" variant="outline" disabled>
                      <Eye className="w-4 h-4 mr-1" />
                      Visualizar
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {searchQuery.length > 2 && searchResults?.length === 0 && !searchLoading && (
            <p className="text-center text-gray-600 py-4">
              Nenhum PDF encontrado para "{searchQuery}"
            </p>
          )}
        </CardContent>
      </Card>

      {/* Filtros */}
      <div className="flex items-center space-x-4 bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium">Filtros:</span>
        </div>
        
        <select
          value={filterAction}
          onChange={(e) => setFilterAction(e.target.value)}
          className="px-3 py-1 border border-gray-300 rounded-md text-sm"
        >
          <option value="">Todas as ações</option>
          {actions.map(action => (
            <option key={action} value={action} className="capitalize">
              {action}
            </option>
          ))}
        </select>

        <select
          value={filterSector}
          onChange={(e) => setFilterSector(e.target.value)}
          className="px-3 py-1 border border-gray-300 rounded-md text-sm"
        >
          <option value="">Todos os setores</option>
          {sectors.map(sector => (
            <option key={sector} value={sector} className="capitalize">
              {sector}
            </option>
          ))}
        </select>

        {(filterAction || filterSector) && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setFilterAction("");
              setFilterSector("");
            }}
          >
            Limpar Filtros
          </Button>
        )}
      </div>

      {/* Logs de Auditoria */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5" />
              <span>Logs de Atividade</span>
              {isRealtime && (
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></div>
                  Tempo Real
                </Badge>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {logsLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              <p className="text-gray-600 mt-2">Carregando logs...</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ação</TableHead>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Setor</TableHead>
                  <TableHead>Arquivo</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs?.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <Badge className={getActionColor(log.action)}>
                        {getActionIcon(log.action)}
                        <span className="ml-1 capitalize">{log.action}</span>
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{log.user}</TableCell>
                    <TableCell className="capitalize">{log.sector}</TableCell>
                    <TableCell className="text-sm text-gray-600 max-w-xs truncate">
                      {log.file || "-"}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {formatTime(log.timestamp)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={log.success !== false ? "default" : "destructive"}>
                        {log.success !== false ? "Sucesso" : "Falha"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Aviso de Permissões */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Eye className="w-5 h-5 text-yellow-600" />
            <div>
              <p className="text-sm font-medium text-yellow-800">Modo Somente Leitura</p>
              <p className="text-sm text-yellow-600">
                Como supervisor, você pode visualizar e monitorar todas as atividades, 
                mas não pode adicionar, editar ou remover arquivos.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}