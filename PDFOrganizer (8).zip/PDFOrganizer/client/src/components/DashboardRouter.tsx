import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import DirectorDashboard from "./DirectorDashboard";
import SupervisorDashboard from "./SupervisorDashboard";
import ExternalUserDashboard from "./ExternalUserDashboard";
import EmployeeDashboard from "./EmployeeDashboard";
import { Card, CardContent } from "@/components/ui/card";

interface User {
  id: string;
  email: string;
  name: string;
  setor: string;
  isAdmin: boolean;
  isActive: boolean;
  userType: string;
  canAddFiles: boolean;
  canEditFiles: boolean;
  canDeleteFiles: boolean;
  canViewAllSectorFiles: boolean;
  accessibleSectors: string[];
}

export default function DashboardRouter() {
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <p className="text-red-600">Erro ao carregar informações do usuário</p>
            <p className="text-sm text-gray-500 mt-2">
              Tente recarregar a página ou faça login novamente
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <p className="text-gray-600">Usuário não encontrado</p>
            <p className="text-sm text-gray-500 mt-2">
              Faça login para acessar o sistema
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Usuário pendente
  if (user.userType === "pending") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 className="w-8 h-8 text-yellow-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">
              Conta Aguardando Aprovação
            </h2>
            <p className="text-gray-600 mb-4">
              Sua conta foi criada com sucesso e está aguardando aprovação do administrador.
            </p>
            <div className="text-sm text-gray-500 space-y-1">
              <p><strong>Nome:</strong> {user.name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Setor:</strong> {user.setor}</p>
            </div>
            <p className="text-sm text-gray-500 mt-4">
              Você receberá um email assim que sua conta for aprovada.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Usuário inativo
  if (!user.isActive) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-red-600 text-2xl">⚠️</span>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">
              Conta Desativada
            </h2>
            <p className="text-gray-600 mb-4">
              Sua conta foi desativada. Entre em contato com o administrador para mais informações.
            </p>
            <div className="text-sm text-gray-500 space-y-1">
              <p><strong>Nome:</strong> {user.name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Setor:</strong> {user.setor}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Roteamento baseado no tipo de usuário
  switch (user.userType) {
    case "admin":
      // Administradores da diretoria têm acesso ao painel diretor
      if (user.setor === "diretoria" || user.isAdmin) {
        return <DirectorDashboard />;
      }
      // Admins de outros setores têm interface de funcionário com permissões extras
      return <EmployeeDashboard />;
    
    case "supervisor":
      return <SupervisorDashboard />;
    
    case "external":
      return <ExternalUserDashboard />;
    
    case "employee":
    default:
      return <EmployeeDashboard />;
  }
}