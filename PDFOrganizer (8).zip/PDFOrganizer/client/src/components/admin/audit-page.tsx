import { AuditDashboard } from "../audit-dashboard";

export function AuditPage() {
  return (
    <div className="container mx-auto p-6">
      <AuditDashboard />
    </div>
  );
}