import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { 
  Eye, 
  FileText, 
  Users, 
  Building, 
  TrendingUp, 
  AlertCircle,
  Clock,
  Download,
  UserCheck,
  UserX
} from "lucide-react";

interface DirectorStats {
  totalFiles: number;
  totalUsers: number;
  pendingApprovals: number;
  storageUsed: string;
  recentActivity: number;
}

interface SectorSummary {
  sector: string;
  fileCount: number;
  userCount: number;
  recentUploads: number;
  status: "active" | "warning" | "inactive";
}

interface RecentActivity {
  id: string;
  action: string;
  user: string;
  sector: string;
  timestamp: Date;
  file?: string;
}

export default function DirectorDashboard() {
  const [selectedSector, setSelectedSector] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [userType, setUserType] = useState("employee");
  const [setor, setSetor] = useState("");
  const [canAddFiles, setCanAddFiles] = useState(false);
  const [canEditFiles, setCanEditFiles] = useState(false);
  const [canDeleteFiles, setCanDeleteFiles] = useState(false);
  const [canViewAllSectorFiles, setCanViewAllSectorFiles] = useState(false);
  const [accessibleSectors, setAccessibleSectors] = useState<string[]>([]);
  
  const queryClient = useQueryClient();

  // Buscar estatísticas da diretoria
  const { data: stats } = useQuery<DirectorStats>({
    queryKey: ["/api/director/stats"],
  });

  // Buscar resumo por setor
  const { data: sectorSummaries } = useQuery<SectorSummary[]>({
    queryKey: ["/api/director/sectors"],
  });

  // Buscar atividades recentes
  const { data: recentActivities } = useQuery<RecentActivity[]>({
    queryKey: ["/api/director/activities"],
  });

  // Buscar usuários pendentes
  const { data: pendingUsers } = useQuery({
    queryKey: ["/api/admin/users/pending"],
  });

  // Mutação para aprovar usuário
  const approveUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      return await apiRequest("/api/admin/users/approve", {
        method: "POST",
        body: JSON.stringify(userData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Usuário aprovado com sucesso",
        description: "O usuário foi aprovado e suas permissões foram configuradas.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users/pending"] });
      setSelectedUser(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao aprovar usuário",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      });
    },
  });

  // Mutação para rejeitar usuário
  const rejectUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("/api/admin/users/reject", {
        method: "POST",
        body: JSON.stringify({ userId }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Usuário rejeitado",
        description: "O usuário foi rejeitado e removido da lista de pendentes.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users/pending"] });
      setSelectedUser(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao rejeitar usuário",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      });
    },
  });

  const getSectorStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "warning": return "bg-yellow-100 text-yellow-800";
      case "inactive": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleUserSelection = (user: any) => {
    setSelectedUser(user);
    setSetor(user.setor || "");
    setUserType("employee");
    setCanAddFiles(false);
    setCanEditFiles(false);
    setCanDeleteFiles(false);
    setCanViewAllSectorFiles(false);
    setAccessibleSectors([user.setor || ""]);
  };

  const handleApproveUser = () => {
    if (!selectedUser) return;
    
    const userData = {
      userId: selectedUser.id,
      userType,
      setor,
      canAddFiles,
      canEditFiles,
      canDeleteFiles,
      canViewAllSectorFiles,
      accessibleSectors,
    };
    
    approveUserMutation.mutate(userData);
  };

  const handleRejectUser = () => {
    if (!selectedUser) return;
    rejectUserMutation.mutate(selectedUser.id);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Painel da Diretoria</h1>
          <p className="text-gray-600">Visão geral dos setores e atividades</p>
        </div>
        <Badge variant="outline" className="bg-blue-50 text-blue-700">
          <Building className="w-4 h-4 mr-1" />
          Diretoria
        </Badge>
      </div>

      {/* Estatísticas Gerais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total de Arquivos</p>
                <p className="text-2xl font-bold">{stats?.totalFiles || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Total de Usuários</p>
                <p className="text-2xl font-bold">{stats?.totalUsers || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Aprovações Pendentes</p>
                <p className="text-2xl font-bold">{stats?.pendingApprovals || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Armazenamento</p>
                <p className="text-2xl font-bold">{stats?.storageUsed || "0 GB"}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-red-600" />
              <div>
                <p className="text-sm text-gray-600">Atividade Recente</p>
                <p className="text-2xl font-bold">{stats?.recentActivity || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sectors" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="sectors">Setores</TabsTrigger>
          <TabsTrigger value="activity">Atividades</TabsTrigger>
          <TabsTrigger value="approvals">Aprovações</TabsTrigger>
        </TabsList>

        {/* Aba Setores */}
        <TabsContent value="sectors" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sectorSummaries?.map((sector) => (
              <Card key={sector.sector} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg capitalize">{sector.sector}</CardTitle>
                    <Badge className={getSectorStatusColor(sector.status)}>
                      {sector.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Arquivos:</span>
                      <span className="font-medium">{sector.fileCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Usuários:</span>
                      <span className="font-medium">{sector.userCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Uploads Recentes:</span>
                      <span className="font-medium">{sector.recentUploads}</span>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                    onClick={() => setSelectedSector(sector.sector)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Ver Detalhes
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Aba Atividades */}
        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Atividades Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivities?.map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm">
                        <span className="font-medium">{activity.user}</span> {activity.action}
                        {activity.file && <span className="text-blue-600"> "{activity.file}"</span>}
                      </p>
                      <p className="text-xs text-gray-500">
                        {activity.sector} • {formatDate(activity.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba Aprovações */}
        <TabsContent value="approvals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Usuários Aguardando Aprovação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingUsers?.map((user: any) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-600">{user.email}</p>
                      <p className="text-xs text-gray-500">
                        Setor: {user.setor} • {formatDate(user.createdAt)}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleUserSelection(user)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Revisar
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal de Detalhes do Setor */}
      {selectedSector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold capitalize">Detalhes - {selectedSector}</h2>
              <Button variant="ghost" onClick={() => setSelectedSector(null)}>
                ×
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Arquivos por Tipo</h3>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>PDFs Ativos:</span>
                      <span>45</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Arquivados:</span>
                      <span>12</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Favoritos:</span>
                      <span>8</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Usuários Ativos</h3>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Funcionários:</span>
                      <span>15</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Supervisores:</span>
                      <span>3</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Externos:</span>
                      <span>2</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setSelectedSector(null)}>
                Fechar
              </Button>
              <Button>
                <Download className="w-4 h-4 mr-2" />
                Exportar Relatório
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Revisão de Usuário */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Revisar Usuário</h2>
              <Button variant="ghost" onClick={() => setSelectedUser(null)}>
                ×
              </Button>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium">{selectedUser.name}</h3>
                <p className="text-sm text-gray-600">{selectedUser.email}</p>
                <p className="text-xs text-gray-500">
                  Setor solicitado: {selectedUser.setor}
                </p>
                <p className="text-xs text-gray-500">
                  Cadastrado em: {formatDate(selectedUser.createdAt)}
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="userType">Tipo de Usuário</Label>
                  <Select value={userType} onValueChange={setUserType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="employee">Funcionário</SelectItem>
                      <SelectItem value="supervisor">Supervisor</SelectItem>
                      <SelectItem value="external">Externo</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="setor">Setor</Label>
                  <Select value={setor} onValueChange={setSetor}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o setor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="diretoria">Diretoria</SelectItem>
                      <SelectItem value="ti">TI</SelectItem>
                      <SelectItem value="rh">RH</SelectItem>
                      <SelectItem value="financeiro">Financeiro</SelectItem>
                      <SelectItem value="comercial">Comercial</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="operacional">Operacional</SelectItem>
                      <SelectItem value="juridico">Jurídico</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Permissões</Label>
                  <div className="space-y-1">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={canAddFiles}
                        onChange={(e) => setCanAddFiles(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Pode adicionar arquivos</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={canEditFiles}
                        onChange={(e) => setCanEditFiles(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Pode editar arquivos</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={canDeleteFiles}
                        onChange={(e) => setCanDeleteFiles(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Pode deletar arquivos</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={canViewAllSectorFiles}
                        onChange={(e) => setCanViewAllSectorFiles(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Visualizar todos os arquivos do setor</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={handleRejectUser}
                  disabled={rejectUserMutation.isPending}
                >
                  <UserX className="w-4 h-4 mr-1" />
                  Rejeitar
                </Button>
                <Button
                  onClick={handleApproveUser}
                  disabled={approveUserMutation.isPending}
                >
                  <UserCheck className="w-4 h-4 mr-1" />
                  Aprovar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}