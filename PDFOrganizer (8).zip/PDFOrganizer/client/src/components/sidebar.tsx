import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Folder, Star, Clock, Trash2, Plus, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Folder as FolderType } from "@shared/schema";

interface SidebarProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function Sidebar({ selectedCategory, onCategoryChange }: SidebarProps) {
  const [showAddFolder, setShowAddFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: folders = [] } = useQuery<FolderType[]>({
    queryKey: ["/api/folders"],
  });

  const { data: allPdfs = [] } = useQuery({
    queryKey: ["/api/pdfs"],
  });

  const { data: recentPdfs = [] } = useQuery({
    queryKey: ["/api/pdfs/recent"],
  });

  const { data: favoritePdfs = [] } = useQuery({
    queryKey: ["/api/pdfs/favorites"],
  });

  const { data: deletedPdfs = [] } = useQuery({
    queryKey: ["/api/pdfs/deleted"],
  });

  const createFolderMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await apiRequest("POST", "/api/folders", { name });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setShowAddFolder(false);
      setNewFolderName("");
      toast({
        title: "Pasta criada",
        description: "A pasta foi criada com sucesso.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar a pasta.",
        variant: "destructive",
      });
    },
  });

  const handleAddFolder = () => {
    if (newFolderName.trim()) {
      createFolderMutation.mutate(newFolderName.trim());
    }
  };

  const getFolderCount = (folderId: number) => {
    return allPdfs.filter((pdf: any) => pdf.folderId === folderId && !pdf.isDeleted).length;
  };

  const categoryItems = [
    {
      key: "all",
      icon: FolderOpen,
      label: "Todos os PDFs",
      count: allPdfs.filter((pdf: any) => !pdf.isDeleted).length,
      active: true,
    },
    {
      key: "favorites",
      icon: Star,
      label: "Favoritos",
      count: favoritePdfs.length,
      active: false,
    },
    {
      key: "recent",
      icon: Clock,
      label: "Recentes",
      count: recentPdfs.length,
      active: false,
    },
    {
      key: "trash",
      icon: Trash2,
      label: "Lixeira",
      count: deletedPdfs.length,
      active: false,
    },
  ];

  return (
    <Card className="w-64 h-fit">
      <CardContent className="p-6">
        <h2 className="text-lg font-semibold text-neutral-800 mb-4">Organização</h2>
        
        <div className="space-y-2">
          {categoryItems.map((item) => {
            const Icon = item.icon;
            const isSelected = selectedCategory === item.key;
            
            return (
              <button
                key={item.key}
                onClick={() => onCategoryChange(item.key)}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                  isSelected 
                    ? "bg-primary/10 text-primary" 
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="flex-1 text-left font-medium">{item.label}</span>
                <Badge 
                  variant={isSelected ? "default" : "secondary"}
                  className={isSelected ? "bg-primary text-white" : ""}
                >
                  {item.count}
                </Badge>
              </button>
            );
          })}
        </div>

        <hr className="border-gray-200 my-6" />

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-800">Pastas</h3>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowAddFolder(true)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {showAddFolder && (
            <div className="flex gap-2 mb-4">
              <Input
                placeholder="Nome da pasta"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleAddFolder()}
                className="text-sm"
              />
              <Button size="sm" onClick={handleAddFolder}>
                OK
              </Button>
            </div>
          )}

          <div className="space-y-2">
            {folders.map((folder) => {
              const isSelected = selectedCategory === `folder-${folder.id}`;
              
              return (
                <button
                  key={folder.id}
                  onClick={() => onCategoryChange(`folder-${folder.id}`)}
                  className={`w-full flex items-center space-x-3 p-2 rounded-lg transition-colors ${
                    isSelected 
                      ? "bg-primary/10 text-primary" 
                      : "text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <Folder className="h-4 w-4 text-accent" />
                  <span className="flex-1 text-left text-sm">{folder.name}</span>
                  <span className="text-xs text-gray-500">
                    {getFolderCount(folder.id)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
