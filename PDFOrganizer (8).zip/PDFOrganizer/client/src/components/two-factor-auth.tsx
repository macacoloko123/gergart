import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Shield, ShieldCheck, Copy, Eye, EyeOff } from "lucide-react";

interface TwoFactorSetup {
  secret: string;
  qrCodeUrl: string;
  backupCodes: string[];
}

interface TwoFactorAuthProps {
  isEnabled: boolean;
  onStatusChange: (enabled: boolean) => void;
}

export function TwoFactorAuth({ isEnabled, onStatusChange }: TwoFactorAuthProps) {
  const [setupData, setSetupData] = useState<TwoFactorSetup | null>(null);
  const [verificationCode, setVerificationCode] = useState("");
  const [disableCode, setDisableCode] = useState("");
  const [isSettingUp, setIsSettingUp] = useState(false);
  const [isDisabling, setIsDisabling] = useState(false);
  const [showBackupCodes, setShowBackupCodes] = useState(false);
  const { toast } = useToast();

  const startSetup = async () => {
    setIsSettingUp(true);
    try {
      const response = await fetch("/api/auth/2fa/setup", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`,
          "Content-Type": "application/json"
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSetupData(data);
      } else {
        const error = await response.json();
        toast({
          title: "Erro",
          description: error.error || "Falha ao configurar 2FA",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro de conexão",
        variant: "destructive",
      });
    } finally {
      setIsSettingUp(false);
    }
  };

  const enableTwoFactor = async () => {
    if (!setupData || !verificationCode) return;

    try {
      const response = await fetch("/api/auth/2fa/enable", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          token: verificationCode,
          secret: setupData.secret,
          backupCodes: setupData.backupCodes
        })
      });

      if (response.ok) {
        toast({
          title: "Sucesso",
          description: "Autenticação de dois fatores ativada com sucesso",
        });
        onStatusChange(true);
        setSetupData(null);
        setVerificationCode("");
      } else {
        const error = await response.json();
        toast({
          title: "Erro",
          description: error.error || "Código inválido",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro de conexão",
        variant: "destructive",
      });
    }
  };

  const disableTwoFactor = async () => {
    if (!disableCode) return;

    setIsDisabling(true);
    try {
      const response = await fetch("/api/auth/2fa/disable", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          token: disableCode
        })
      });

      if (response.ok) {
        toast({
          title: "Sucesso",
          description: "Autenticação de dois fatores desativada",
        });
        onStatusChange(false);
        setDisableCode("");
      } else {
        const error = await response.json();
        toast({
          title: "Erro",
          description: error.error || "Código inválido",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro de conexão",
        variant: "destructive",
      });
    } finally {
      setIsDisabling(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado",
      description: "Código copiado para a área de transferência",
    });
  };

  const copyBackupCodes = () => {
    if (setupData) {
      const codes = setupData.backupCodes.join('\n');
      navigator.clipboard.writeText(codes);
      toast({
        title: "Copiado",
        description: "Códigos de backup copiados para a área de transferência",
      });
    }
  };

  if (!isEnabled && !setupData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Autenticação de Dois Fatores
          </CardTitle>
          <CardDescription>
            Adicione uma camada extra de segurança à sua conta
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4">
            <Shield className="h-4 w-4" />
            <AlertDescription>
              A autenticação de dois fatores protege sua conta mesmo se sua senha for comprometida.
            </AlertDescription>
          </Alert>
          <Button onClick={startSetup} disabled={isSettingUp}>
            {isSettingUp ? "Configurando..." : "Configurar 2FA"}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (setupData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Configurar Autenticação de Dois Fatores</CardTitle>
          <CardDescription>
            Escaneie o código QR com seu aplicativo autenticador
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <img 
              src={setupData.qrCodeUrl} 
              alt="QR Code for 2FA setup" 
              className="mx-auto mb-2"
            />
            <p className="text-sm text-gray-600">
              Ou digite manualmente o código:
            </p>
            <div className="flex items-center gap-2 justify-center mt-2">
              <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm">
                {setupData.secret}
              </code>
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(setupData.secret)}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="verification-code">Código de Verificação</Label>
            <Input
              id="verification-code"
              type="text"
              placeholder="Digite o código de 6 dígitos"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              maxLength={6}
            />
          </div>

          <div className="space-y-2">
            <Label>Códigos de Backup</Label>
            <Alert>
              <AlertDescription>
                Salve estes códigos em um local seguro. Você pode usá-los para acessar sua conta se perder seu dispositivo.
              </AlertDescription>
            </Alert>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBackupCodes(!showBackupCodes)}
              >
                {showBackupCodes ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {showBackupCodes ? "Ocultar" : "Mostrar"} Códigos
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={copyBackupCodes}
              >
                <Copy className="h-4 w-4" />
                Copiar
              </Button>
            </div>
            {showBackupCodes && (
              <div className="grid grid-cols-2 gap-2 mt-2">
                {setupData.backupCodes.map((code, index) => (
                  <Badge key={index} variant="secondary" className="font-mono">
                    {code}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <Button onClick={enableTwoFactor} disabled={!verificationCode}>
              Ativar 2FA
            </Button>
            <Button 
              variant="outline" 
              onClick={() => {
                setSetupData(null);
                setVerificationCode("");
              }}
            >
              Cancelar
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-green-600" />
          Autenticação de Dois Fatores
        </CardTitle>
        <CardDescription>
          Sua conta está protegida com autenticação de dois fatores
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <ShieldCheck className="h-4 w-4" />
          <AlertDescription>
            A autenticação de dois fatores está ativa. Sua conta está mais segura.
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <Label htmlFor="disable-code">Código de Verificação</Label>
          <Input
            id="disable-code"
            type="text"
            placeholder="Digite o código de 6 dígitos para desativar"
            value={disableCode}
            onChange={(e) => setDisableCode(e.target.value)}
            maxLength={6}
          />
        </div>

        <Button 
          variant="destructive" 
          onClick={disableTwoFactor}
          disabled={!disableCode || isDisabling}
        >
          {isDisabling ? "Desativando..." : "Desativar 2FA"}
        </Button>
      </CardContent>
    </Card>
  );
}