import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Cloud, CloudOff, ExternalLink, RefreshCw } from 'lucide-react';

interface CloudStatus {
  google_drive: {
    connected: boolean;
    expires_at?: string;
  };
  dropbox: {
    connected: boolean;
    expires_at?: string;
  };
}

export function CloudStorage() {
  const [status, setStatus] = useState<CloudStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/cloud/status', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem("auth-token")}`
        }
      });
      const data = await response.json();
      setStatus(data);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao carregar status do armazenamento em nuvem",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleConnect = async (provider: string) => {
    setConnecting(provider);
    try {
      // Use correct provider name mapping
      const providerMap: { [key: string]: string } = {
        'google_drive': 'google',
        'dropbox': 'dropbox'
      };
      
      const mappedProvider = providerMap[provider] || provider;
      
      const response = await fetch(`/api/cloud/auth/${mappedProvider}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem("auth-token")}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Open auth URL in new window
        const authWindow = window.open(data.authUrl, '_blank', 'width=600,height=600');
        
        // Listen for auth completion
        const checkAuth = setInterval(() => {
          if (authWindow?.closed) {
            clearInterval(checkAuth);
            setConnecting(null);
            fetchStatus(); // Refresh status
          }
        }, 1000);
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to get auth URL');
      }
      
    } catch (error) {
      setConnecting(null);
      toast({
        title: "Erro",
        description: "Falha ao iniciar autenticação",
        variant: "destructive",
      });
    }
  };

  const handleDisconnect = async (provider: string) => {
    try {
      await apiRequest(`/api/cloud/disconnect/${provider}`, 'DELETE');
      
      toast({
        title: "Sucesso",
        description: `${provider === 'google_drive' ? 'Google Drive' : 'Dropbox'} desconectado com sucesso`,
      });
      
      fetchStatus();
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao desconectar armazenamento em nuvem",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-6 w-6 animate-spin mr-2" />
        <span>Carregando status...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Armazenamento em Nuvem</h2>
        <p className="text-muted-foreground">
          Conecte suas contas de armazenamento em nuvem para sincronizar automaticamente seus PDFs
        </p>
      </div>

      <Alert>
        <Cloud className="h-4 w-4" />
        <AlertDescription>
          Seus PDFs serão sincronizados automaticamente após o upload quando o armazenamento em nuvem estiver configurado.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Google Drive */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <Cloud className="h-4 w-4 text-white" />
              </div>
              Google Drive
            </CardTitle>
            <CardDescription>
              Sincronize seus PDFs com o Google Drive
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status:</span>
                <Badge variant={status?.google_drive.connected ? "default" : "secondary"}>
                  {status?.google_drive.connected ? "Conectado" : "Desconectado"}
                </Badge>
              </div>
              
              {status?.google_drive.expires_at && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Expira em:</span>
                  <span className="text-sm text-muted-foreground">
                    {new Date(status.google_drive.expires_at).toLocaleDateString()}
                  </span>
                </div>
              )}
              
              <div className="flex gap-2">
                {status?.google_drive.connected ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleDisconnect('google_drive')}
                  >
                    <CloudOff className="h-4 w-4 mr-2" />
                    Desconectar
                  </Button>
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => handleConnect('google_drive')}
                    disabled={connecting === 'google_drive'}
                  >
                    {connecting === 'google_drive' ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <ExternalLink className="h-4 w-4 mr-2" />
                    )}
                    Conectar
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dropbox */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Cloud className="h-4 w-4 text-white" />
              </div>
              Dropbox
            </CardTitle>
            <CardDescription>
              Sincronize seus PDFs com o Dropbox
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status:</span>
                <Badge variant={status?.dropbox.connected ? "default" : "secondary"}>
                  {status?.dropbox.connected ? "Conectado" : "Desconectado"}
                </Badge>
              </div>
              
              {status?.dropbox.expires_at && (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Expira em:</span>
                  <span className="text-sm text-muted-foreground">
                    {new Date(status.dropbox.expires_at).toLocaleDateString()}
                  </span>
                </div>
              )}
              
              <div className="flex gap-2">
                {status?.dropbox.connected ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleDisconnect('dropbox')}
                  >
                    <CloudOff className="h-4 w-4 mr-2" />
                    Desconectar
                  </Button>
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => handleConnect('dropbox')}
                    disabled={connecting === 'dropbox'}
                  >
                    {connecting === 'dropbox' ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <ExternalLink className="h-4 w-4 mr-2" />
                    )}
                    Conectar
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}