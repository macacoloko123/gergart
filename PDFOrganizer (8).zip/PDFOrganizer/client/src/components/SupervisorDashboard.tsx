import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Filter, 
  Eye, 
  FileText, 
  Clock,
  Users,
  Building,
  Download,
  ExternalLink
} from "lucide-react";

interface SupervisorUser {
  id: string;
  name: string;
  email: string;
  setor: string;
  accessibleSectors: string[];
  canViewAllSectorFiles: boolean;
}

interface FileItem {
  id: number;
  name: string;
  setor: string;
  uploadedBy: string;
  uploadedAt: Date;
  fileSize: number;
  provider?: string;
  downloadUrl?: string;
}

export default function SupervisorDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSector, setSelectedSector] = useState<string>("all");
  const [activeTab, setActiveTab] = useState("files");

  // Buscar informações do usuário supervisor
  const { data: currentUser } = useQuery<SupervisorUser>({
    queryKey: ["/api/auth/me"],
  });

  // Buscar arquivos dos setores acessíveis
  const { data: files } = useQuery<FileItem[]>({
    queryKey: ["/api/supervisor/files", selectedSector],
    enabled: !!currentUser,
  });

  // Buscar arquivos da nuvem
  const { data: cloudFiles } = useQuery<FileItem[]>({
    queryKey: ["/api/search/cloud", searchQuery],
    enabled: searchQuery.length > 2,
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const filteredFiles = files?.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedSector === "all" || file.setor === selectedSector)
  );

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Painel do Supervisor</h1>
          <p className="text-gray-600">
            Visualização de arquivos - Setores acessíveis: {" "}
            {currentUser?.accessibleSectors?.join(", ") || "Carregando..."}
          </p>
        </div>
        <Badge variant="outline" className="bg-green-50 text-green-700">
          <Users className="w-4 h-4 mr-1" />
          Supervisor
        </Badge>
      </div>

      {/* Barra de Busca */}
      <div className="flex space-x-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar arquivos..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={selectedSector}
          onChange={(e) => setSelectedSector(e.target.value)}
          className="px-4 py-2 border rounded-lg bg-white"
        >
          <option value="all">Todos os Setores</option>
          {currentUser?.accessibleSectors?.map(sector => (
            <option key={sector} value={sector} className="capitalize">
              {sector}
            </option>
          ))}
        </select>
      </div>

      {/* Estatísticas Rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Arquivos Acessíveis</p>
                <p className="text-2xl font-bold">{filteredFiles?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Building className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Setores</p>
                <p className="text-2xl font-bold">{currentUser?.accessibleSectors?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Nuvem</p>
                <p className="text-2xl font-bold">{cloudFiles?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Eye className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Visualizações</p>
                <p className="text-2xl font-bold">Apenas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="files">Arquivos Locais</TabsTrigger>
          <TabsTrigger value="cloud">Arquivos na Nuvem</TabsTrigger>
        </TabsList>

        {/* Aba Arquivos Locais */}
        <TabsContent value="files" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {filteredFiles?.map((file) => (
              <Card key={file.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{file.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Setor: {file.setor}</span>
                          <span>Por: {file.uploadedBy}</span>
                          <span>{formatDate(file.uploadedAt)}</span>
                          <span>{formatFileSize(file.fileSize)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="capitalize">
                        {file.setor}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-1" />
                        Visualizar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Aba Arquivos na Nuvem */}
        <TabsContent value="cloud" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {cloudFiles?.map((file) => (
              <Card key={file.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <ExternalLink className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{file.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Setor: {file.setor}</span>
                          <span>Provedor: {file.provider}</span>
                          <span>{formatFileSize(file.fileSize)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700">
                        {file.provider}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-1" />
                        Visualizar
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Mensagem de Permissão */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Eye className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium text-blue-800">Modo Supervisor</p>
              <p className="text-sm text-blue-600">
                Você tem acesso apenas para visualização. Não é possível adicionar, editar ou remover arquivos.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}