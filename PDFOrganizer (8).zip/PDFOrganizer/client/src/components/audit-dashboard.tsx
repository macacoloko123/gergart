import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Activity, 
  Shield, 
  Download, 
  Upload, 
  Trash2, 
  Eye, 
  AlertTriangle,
  Calendar,
  Users,
  FileText
} from "lucide-react";

interface AuditLog {
  id: string;
  userId: string;
  action: string;
  resourceType: string;
  resourceId: string | null;
  ipAddress: string;
  userAgent: string;
  success: boolean;
  errorMessage: string | null;
  timestamp: string;
}

interface AuditStats {
  totalLogs: number;
  loginAttempts: number;
  successfulLogins: number;
  failedLogins: number;
  passwordResets: number;
  fileUploads: number;
  fileDownloads: number;
  fileDeletions: number;
  twoFactorEvents: number;
}

export function AuditDashboard() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<AuditStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    userId: "",
    action: "",
    resourceType: "",
    startDate: "",
    endDate: "",
    limit: 50
  });
  const { toast } = useToast();

  const fetchAuditLogs = async () => {
    try {
      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) queryParams.append(key, value.toString());
      });

      const response = await fetch(`/api/admin/audit/logs?${queryParams}`, {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setLogs(data);
      } else {
        toast({
          title: "Erro",
          description: "Falha ao carregar logs de auditoria",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro de conexão",
        variant: "destructive",
      });
    }
  };

  const fetchAuditStats = async () => {
    try {
      const queryParams = new URLSearchParams();
      if (filters.startDate) queryParams.append("startDate", filters.startDate);
      if (filters.endDate) queryParams.append("endDate", filters.endDate);

      const response = await fetch(`/api/admin/audit/stats?${queryParams}`, {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("auth-token")}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error("Error fetching audit stats:", error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchAuditLogs(), fetchAuditStats()]);
      setLoading(false);
    };

    loadData();
  }, [filters]);

  const getActionIcon = (action: string) => {
    switch (action) {
      case "login":
        return <Shield className="h-4 w-4" />;
      case "upload_pdf":
        return <Upload className="h-4 w-4" />;
      case "download_pdf":
        return <Download className="h-4 w-4" />;
      case "delete_pdf":
        return <Trash2 className="h-4 w-4" />;
      case "view_pdf":
        return <Eye className="h-4 w-4" />;
      case "password_reset":
        return <Shield className="h-4 w-4" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };

  const getActionColor = (action: string, success: boolean) => {
    if (!success) return "destructive";
    
    switch (action) {
      case "login":
        return "default";
      case "upload_pdf":
        return "secondary";
      case "download_pdf":
        return "outline";
      case "delete_pdf":
        return "destructive";
      default:
        return "default";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("pt-BR");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Carregando dados de auditoria...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Painel de Auditoria</h1>
        <Button onClick={() => window.location.reload()}>
          Atualizar
        </Button>
      </div>

      {/* Statistics Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total de Logs</p>
                  <p className="text-2xl font-bold">{stats.totalLogs}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Tentativas de Login</p>
                  <p className="text-2xl font-bold">{stats.loginAttempts}</p>
                  <p className="text-xs text-green-600">
                    {stats.successfulLogins} sucessos
                  </p>
                </div>
                <Shield className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Uploads</p>
                  <p className="text-2xl font-bold">{stats.fileUploads}</p>
                </div>
                <Upload className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Downloads</p>
                  <p className="text-2xl font-bold">{stats.fileDownloads}</p>
                </div>
                <Download className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          {stats.failedLogins > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Logins Falhados</p>
                    <p className="text-2xl font-bold text-red-600">{stats.failedLogins}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
          <CardDescription>
            Filtre os logs de auditoria por diferentes critérios
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="space-y-2">
              <Label htmlFor="userId">ID do Usuário</Label>
              <Input
                id="userId"
                placeholder="ID do usuário"
                value={filters.userId}
                onChange={(e) => setFilters({...filters, userId: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="action">Ação</Label>
              <Select value={filters.action} onValueChange={(value) => setFilters({...filters, action: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma ação" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas</SelectItem>
                  <SelectItem value="login">Login</SelectItem>
                  <SelectItem value="upload_pdf">Upload PDF</SelectItem>
                  <SelectItem value="download_pdf">Download PDF</SelectItem>
                  <SelectItem value="delete_pdf">Deletar PDF</SelectItem>
                  <SelectItem value="password_reset">Reset de Senha</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="resourceType">Tipo de Recurso</Label>
              <Select value={filters.resourceType} onValueChange={(value) => setFilters({...filters, resourceType: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  <SelectItem value="auth">Autenticação</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="folder">Pasta</SelectItem>
                  <SelectItem value="security">Segurança</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="startDate">Data Inicial</Label>
              <Input
                id="startDate"
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({...filters, startDate: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">Data Final</Label>
              <Input
                id="endDate"
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({...filters, endDate: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="limit">Limite</Label>
              <Select value={filters.limit.toString()} onValueChange={(value) => setFilters({...filters, limit: parseInt(value)})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                  <SelectItem value="250">250</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Logs de Auditoria</CardTitle>
          <CardDescription>
            Histórico completo de atividades do sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Hora</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Ação</TableHead>
                <TableHead>Recurso</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-mono text-sm">
                    {formatDate(log.timestamp)}
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {log.userId.substring(0, 8)}...
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getActionIcon(log.action)}
                      <Badge variant={getActionColor(log.action, log.success)}>
                        {log.action}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{log.resourceType}</div>
                      {log.resourceId && (
                        <div className="text-gray-500 font-mono">
                          {log.resourceId.substring(0, 8)}...
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {log.ipAddress}
                  </TableCell>
                  <TableCell>
                    <Badge variant={log.success ? "default" : "destructive"}>
                      {log.success ? "Sucesso" : "Falha"}
                    </Badge>
                    {log.errorMessage && (
                      <div className="text-xs text-red-600 mt-1">
                        {log.errorMessage}
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {logs.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Nenhum log encontrado com os filtros aplicados
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}