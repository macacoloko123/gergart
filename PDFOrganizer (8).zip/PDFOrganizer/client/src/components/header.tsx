import { useState } from "react";
import { Search, Upload, Settings, FileText, LogOut } from "lucide-react";
import { useAuth } from "@/components/auth/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

interface HeaderProps {
  onSearch: (query: string) => void;
  onUpload: () => void;
}

export function Header({ onSearch, onUpload }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { logout, user } = useAuth();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    onSearch(value);
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <FileText className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-semibold text-neutral-800">PDFOrganizerPro</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Buscar PDFs..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-64 pl-10"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            </div>
            
            <Button onClick={onUpload} className="bg-primary hover:bg-blue-700">
              <Upload className="h-4 w-4 mr-2" />
              Upload PDF
            </Button>
            
            <Link href="/settings">
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5" />
              </Button>
            </Link>
            
            <Button 
              variant="ghost" 
              size="icon"
              onClick={logout}
              title={`Logout (${user?.email})`}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
