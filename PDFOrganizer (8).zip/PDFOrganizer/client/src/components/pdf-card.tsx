import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Star, MoreVertical, Eye, Download, Edit, FolderOpen, Trash2, FileText, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Pdf } from "@shared/schema";

interface PdfCardProps {
  pdf: Pdf;
  onPreview?: (pdf: Pdf) => void;
}

export function PdfCard({ pdf, onPreview }: PdfCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/pdfs/${pdf.id}/favorite`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs/favorites"] });
      toast({
        title: pdf.isFavorite ? "Removido dos favoritos" : "Adicionado aos favoritos",
        description: `${pdf.name} foi ${pdf.isFavorite ? "removido dos" : "adicionado aos"} favoritos.`,
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível alterar o status de favorito.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/pdfs/${pdf.id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pdfs/deleted"] });
      toast({
        title: "PDF enviado para lixeira",
        description: `${pdf.name} foi enviado para a lixeira.`,
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível excluir o PDF.",
        variant: "destructive",
      });
    },
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return "há poucos minutos";
    } else if (diffInHours < 24) {
      return `há ${Math.floor(diffInHours)} horas`;
    } else if (diffInHours < 48) {
      return "ontem";
    } else if (diffInHours < 168) {
      return `há ${Math.floor(diffInHours / 24)} dias`;
    } else {
      return `há ${Math.floor(diffInHours / 168)} semanas`;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer">
      <div className="aspect-[3/4] bg-gray-100 flex items-center justify-center relative">
        <div className="text-center">
          <FileText className="h-16 w-16 text-red-500 mb-2" />
          <p className="text-xs text-gray-500">Miniatura do PDF</p>
        </div>
        
        <div className="absolute top-2 right-2 flex space-x-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 bg-white rounded-full shadow-sm hover:shadow-md"
            onClick={(e) => {
              e.stopPropagation();
              toggleFavoriteMutation.mutate();
            }}
          >
            <Star className={`h-4 w-4 ${pdf.isFavorite ? "text-yellow-400 fill-yellow-400" : "text-gray-400"}`} />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 bg-white rounded-full shadow-sm hover:shadow-md"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="h-4 w-4 text-gray-600" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onPreview?.(pdf)}>
                <Eye className="h-4 w-4 mr-2" />
                Visualizar
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="h-4 w-4 mr-2" />
                Download
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Edit className="h-4 w-4 mr-2" />
                Renomear
              </DropdownMenuItem>
              <DropdownMenuItem>
                <FolderOpen className="h-4 w-4 mr-2" />
                Mover para pasta
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => deleteMutation.mutate()}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-gray-800 mb-2 truncate">{pdf.name}</h3>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>{formatFileSize(pdf.size)}</span>
          <span>{pdf.pages} pág.</span>
        </div>
        <div className="flex items-center mt-2 text-xs text-gray-400">
          <Clock className="h-3 w-3 mr-1" />
          <span>{formatDate(pdf.updatedAt)}</span>
        </div>
      </CardContent>
    </Card>
  );
}
