import { PdfCard } from "./pdf-card";
import type { Pdf } from "@shared/schema";

interface PdfGridProps {
  pdfs: Pdf[];
  viewMode: "grid" | "list";
  onPreview?: (pdf: Pdf) => void;
}

export function PdfGrid({ pdfs, viewMode, onPreview }: PdfGridProps) {
  if (pdfs.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">Nenhum PDF encontrado</p>
        <p className="text-gray-400 text-sm mt-2">Faça upload de seus primeiros PDFs para começar</p>
      </div>
    );
  }

  return (
    <div className={viewMode === "grid" 
      ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" 
      : "space-y-4"
    }>
      {pdfs.map((pdf) => (
        <PdfCard key={pdf.id} pdf={pdf} onPreview={onPreview} />
      ))}
    </div>
  );
}
