import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, X, ZoomIn, ZoomOut, RotateCw } from "lucide-react";
import type { Pdf } from "@shared/schema";

interface PdfViewerProps {
  pdf: Pdf | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PdfViewer({ pdf, isOpen, onClose }: PdfViewerProps) {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  if (!pdf) return null;

  const handleDownload = () => {
    // Create download link
    const link = document.createElement('a');
    link.href = `/api/pdfs/${pdf.id}/download`;
    link.download = pdf.originalName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.25, 3));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.25, 0.25));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="truncate">{pdf.name}</DialogTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-sm text-gray-500 min-w-[3rem] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <Button variant="outline" size="sm" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleRotate}>
              <RotateCw className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-auto bg-gray-100 rounded-lg p-4">
          <div className="flex items-center justify-center h-full">
            <div 
              className="bg-white shadow-lg rounded-lg p-8 max-w-4xl w-full"
              style={{ 
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
                transformOrigin: 'center center'
              }}
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">📄</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-800">
                  Visualização de PDF
                </h3>
                <p className="text-gray-600">
                  {pdf.originalName}
                </p>
                <div className="grid grid-cols-2 gap-4 text-sm text-gray-500">
                  <div>
                    <strong>Tamanho:</strong> {(pdf.size / 1024 / 1024).toFixed(2)} MB
                  </div>
                  <div>
                    <strong>Páginas:</strong> {pdf.pages}
                  </div>
                  <div>
                    <strong>Criado:</strong> {new Date(pdf.createdAt).toLocaleDateString()}
                  </div>
                  <div>
                    <strong>Modificado:</strong> {new Date(pdf.updatedAt).toLocaleDateString()}
                  </div>
                </div>
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <p className="text-blue-800 text-sm">
                    <strong>Próxima atualização:</strong> Visualizador de PDF integrado com react-pdf
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}