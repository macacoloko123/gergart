import { CloudStorage } from '@/components/cloud-storage';
import { Settings as SettingsIcon } from 'lucide-react';

export default function Settings() {
  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-2 mb-6">
        <SettingsIcon className="h-6 w-6" />
        <h1 className="text-3xl font-bold">Configurações</h1>
      </div>
      
      <div className="max-w-4xl">
        <CloudStorage />
      </div>
    </div>
  );
}