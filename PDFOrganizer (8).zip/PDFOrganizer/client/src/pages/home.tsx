import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { Sidebar } from "@/components/sidebar";
import { UploadZone } from "@/components/upload-zone";
import { ActionBar } from "@/components/action-bar";
import { PdfGrid } from "@/components/pdf-grid";
import { PdfViewer } from "@/components/pdf-viewer";
import { PdfSearchEngine } from "@/lib/search";
import type { Pdf } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState("name");
  const [showUpload, setShowUpload] = useState(false);
  const [selectedPdf, setSelectedPdf] = useState<Pdf | null>(null);

  const { data: allPdfs = [], isLoading } = useQuery<Pdf[]>({
    queryKey: ["/api/pdfs"],
  });

  // Initialize search engine
  const searchEngine = useMemo(() => {
    return new PdfSearchEngine(allPdfs);
  }, [allPdfs]);

  // Client-side search with Fuse.js
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return searchEngine.search(searchQuery);
  }, [searchQuery, searchEngine]);

  const { data: recentPdfs = [] } = useQuery<Pdf[]>({
    queryKey: ["/api/pdfs/recent"],
  });

  const { data: favoritePdfs = [] } = useQuery<Pdf[]>({
    queryKey: ["/api/pdfs/favorites"],
  });

  const { data: deletedPdfs = [] } = useQuery<Pdf[]>({
    queryKey: ["/api/pdfs/deleted"],
  });

  const getPdfsForCategory = () => {
    if (searchQuery) {
      return searchResults;
    }

    switch (selectedCategory) {
      case "all":
        return allPdfs.filter(pdf => !pdf.isDeleted);
      case "favorites":
        return favoritePdfs;
      case "recent":
        return recentPdfs;
      case "trash":
        return deletedPdfs;
      default:
        if (selectedCategory.startsWith("folder-")) {
          const folderId = parseInt(selectedCategory.replace("folder-", ""));
          return allPdfs.filter(pdf => pdf.folderId === folderId && !pdf.isDeleted);
        }
        return [];
    }
  };

  const sortPdfs = (pdfs: Pdf[]) => {
    switch (sortBy) {
      case "name":
        return [...pdfs].sort((a, b) => a.name.localeCompare(b.name));
      case "date":
        return [...pdfs].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      case "size":
        return [...pdfs].sort((a, b) => b.size - a.size);
      default:
        return pdfs;
    }
  };

  const displayedPdfs = sortPdfs(getPdfsForCategory());

  const handlePreview = (pdf: Pdf) => {
    setSelectedPdf(pdf);
  };

  const getCurrentFolderId = () => {
    if (selectedCategory.startsWith("folder-")) {
      return parseInt(selectedCategory.replace("folder-", ""));
    }
    return undefined;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header onSearch={setSearchQuery} onUpload={() => setShowUpload(true)} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="text-gray-500 mt-4">Carregando...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header onSearch={setSearchQuery} onUpload={() => setShowUpload(true)} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          <Sidebar
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
          
          <main className="flex-1">
            <ActionBar
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              sortBy={sortBy}
              onSortChange={setSortBy}
            />
            
            {showUpload && (
              <UploadZone
                folderId={getCurrentFolderId()}
                onUploadComplete={() => setShowUpload(false)}
              />
            )}
            
            <PdfGrid
              pdfs={displayedPdfs}
              viewMode={viewMode}
              onPreview={handlePreview}
            />
          </main>
        </div>
      </div>

      <PdfViewer
        pdf={selectedPdf}
        isOpen={!!selectedPdf}
        onClose={() => setSelectedPdf(null)}
      />
    </div>
  );
}
